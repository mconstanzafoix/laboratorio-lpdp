---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-249"
enunciado: "El responsable debe realizar antes del tratamiento una evaluación de impacto cuando sea probable un alto riesgo para derechos de titulares, y siempre en los cuatro casos del inciso segundo."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Realizar evaluación de impacto de protección de datos."
condicion_de_aplicacion: "Probable alto riesgo por naturaleza, alcance, contexto, tecnología o fines O cualquiera de cuatro casos obligatorios."
plazo: "antes del inicio de operaciones"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-01.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 3, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-03.md, orientaciones mínimas de Agencia"
cita_textual_de_respaldo: "Art. 15 ter, inc. 01: «deberá realizar, previo al inicio de las operaciones del tratamiento, una evaluación del impacto»"
estado_de_determinacion: "Delegada"
enumeracion_contenida: "evaluación automatizada con efectos jurídicos significativos; tratamiento masivo o gran escala; monitoreo sistemático de espacio público; datos sensibles en excepción de consentimiento"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El alto riesgo requiere valoración; la Agencia establece orientaciones mínimas de contenido según inciso tercero, delegando componente metodológico.

## Alcance de la regla

La regla se aplica a: Probable alto riesgo por naturaleza, alcance, contexto, tecnología o fines O cualquiera de cuatro casos obligatorios. Estado `Delegada`; carácter `Condicional`. Plazo o momento: antes del inicio de operaciones.

## Anclajes y función

- [Art. 15 ter, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-01.md): principal: regla expresada.
- [Art. 15 ter, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-03.md): delegación de orientaciones mínimas a Agencia.

## Límites del análisis

El vínculo sancionador con art. 34 quáter letra k y demás tipos requiere conciliación individual; `sancion` permanece vacío sin implicar ausencia.
