---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-026"
enunciado: "Oponerse a un tratamiento determinado de sus datos personales en los supuestos de las letras a, b o c."
destinatario: "Titular"
modalidad: "Derecho del titular"
conducta_exigida: "Oponerse a un tratamiento determinado de sus datos personales en los supuestos de las letras a, b o c."
condicion_de_aplicacion: "Interés legítimo del responsable O marketing directo O datos de fuente pública sin otra base legal; salvo investigación científica, histórica o estadística necesaria para función pública o interés público."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/inciso-01.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 reproducido de Ley 19.628, lit. a, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/letra-a-fragmento-01.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 reproducido de Ley 19.628, lit. b, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/letra-b.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 reproducido de Ley 19.628, lit. c, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/letra-c.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/inciso-02.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 13 reproducido de Ley 19.628, lit. d, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-13/letra-d-fragmento-01.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md, incorporación; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 10 reproducido de Ley 19.628, inc. 4, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-10/inciso-04.md, gratuidad del ejercicio"
cita_textual_de_respaldo: "Art. primero, num. 7, art. 8 reproducido de Ley 19.628, inc. 1: «El titular de datos tiene derecho a oponerse ante el responsable»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "SUPUESTOS: a) Cuando la base de licitud del tratamiento sea la satisfacción de intereses legítimos del responsable. En dicho caso podrá ejercer su derecho de oposición en cualquier momento.; b) Si el tratamiento se realiza exclusivamente con fines de mercadotecnia o marketing directo de bienes, productos o servicios, incluida la elaboración de perfiles, de conformidad con el artículo 8° bis.; c) Si el tratamiento se realiza respecto de datos obtenidos de una fuente de acceso público y no existe otro fundamento legal para su tratamiento.; EXCLUSIÓN: No procederá la oposición al tratamiento cuando éste se realice con fines de investigación científica o histórica o fines estadísticos, y siempre que fueran necesarios para el cumplimiento de una función pública o para el ejercicio de una actividad de interés público."
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Disposición principal dice «El titular de datos tiene derecho a oponerse ante el responsable». El artículo atribuye un derecho al titular; las tres letras son alternativas de ejercicio y el inciso segundo establece una exclusión de procedencia. La facultad de oponerse en cualquier momento en la letra a permanece en esta misma regla.

## Alcance de la regla

La ponderación de intereses legítimos y la necesidad de investigación pueden requerir valoración. No hay plazo cuantificado; para el caso de la letra a el ejercicio es en cualquier momento. La oposición es siempre gratuita para el titular. El estado de determinación es `Indeterminada` y el carácter `Condicional` por el alcance descrito.

## Anclajes y función

- Art. primero, num. 7, art. 8 reproducido de Ley 19.628, inc. 1: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 reproducido de Ley 19.628, lit. a, frag. 1: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/letra-a-fragmento-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 reproducido de Ley 19.628, lit. b: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/letra-b.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 reproducido de Ley 19.628, lit. c: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/letra-c.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 reproducido de Ley 19.628, inc. 2: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08/inciso-02.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 8, art. 13 reproducido de Ley 19.628, lit. d, frag. 1: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-13/letra-d-fragmento-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, instrucción modificatoria: [incorporación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

- Art. primero, num. 7, art. 10 reproducido de Ley 19.628, inc. 4: [gratuidad del ejercicio](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-10/inciso-04.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
