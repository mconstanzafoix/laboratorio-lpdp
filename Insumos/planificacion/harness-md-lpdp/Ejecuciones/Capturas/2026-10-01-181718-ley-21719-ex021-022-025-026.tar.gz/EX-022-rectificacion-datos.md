---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-022"
enunciado: "Solicitar y obtener la rectificación de datos propios inexactos, desactualizados o incompletos tratados por el responsable."
destinatario: "Titular"
modalidad: "Derecho del titular"
conducta_exigida: "Solicitar y obtener la rectificación de datos propios inexactos, desactualizados o incompletos tratados por el responsable."
condicion_de_aplicacion: "Datos personales concernientes al titular tratados por el responsable Y (inexactitud O desactualización O incompletitud)."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 6 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-06/inciso-01.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 4 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-04/inciso-01.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md, incorporación; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 10 reproducido de Ley 19.628, inc. 4, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-10/inciso-04.md, gratuidad del ejercicio"
cita_textual_de_respaldo: "Art. primero, num. 7, art. 6 reproducido de Ley 19.628, inc. 1: «tiene derecho a solicitar y obtener del responsable, la rectificación»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "inexactos; desactualizados; incompletos"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Disposición principal dice «tiene derecho a solicitar y obtener del responsable, la rectificación». El inciso atribuye directamente al titular el derecho a rectificar sus datos. Las tres cualidades alternativas delimitan una misma posición normativa, no tres derechos separados.

## Alcance de la regla

La inexactitud o desactualización de datos exige evaluación respecto de su contexto y fines. El derecho es condicional a alguno de esos defectos y no fija plazo en esta Disposición. La rectificación es siempre gratuita para el titular. El estado de determinación es `Indeterminada` y el carácter `Condicional` por el alcance descrito.

## Anclajes y función

- Art. primero, num. 7, art. 6 reproducido de Ley 19.628, inc. 1: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-06/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 4 reproducido de Ley 19.628, inc. 1: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-04/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, instrucción modificatoria: [incorporación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

- Art. primero, num. 7, art. 10 reproducido de Ley 19.628, inc. 4: [gratuidad del ejercicio](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-10/inciso-04.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
