---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-073"
enunciado: "El responsable solo puede tratar datos de niños, niñas y adolescentes atendiendo a su interés superior y autonomía progresiva."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Tratar datos personales de niños, niñas y adolescentes atendiendo a su interés superior y autonomía progresiva."
condicion_de_aplicacion: "Datos personales de niños, niñas o adolescentes."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quáter, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-01.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quáter, inc. 5, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-05.md, definiciones etarias con frontera abierta de catorce años"
cita_textual_de_respaldo: "Art. 16 quáter, inc. 1: «sólo puede realizarse atendiendo al interés superior de éstos y al respeto de su autonomía progresiva»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso primero condiciona todo tratamiento de datos de menores a interés superior y respeto de autonomía progresiva. Ambas cualidades actúan conjuntamente y son una misma posición habilitante general.

## Alcance de la regla

Interés superior y autonomía progresiva requieren valoración según la persona y tratamiento. La definición etaria del inciso quinto delimita la clase, con duda localizada sobre quien cumple exactamente catorce años. No hay plazo ni delegación. El carácter es `Condicional` por el supuesto de datos de menores. Se registra `Indeterminada` por la valoración y límite señalados.

## Anclajes y función

- [Art. 16 quáter, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-01.md): principal: regla expresada.
- [Art. 16 quáter, inc. 5](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-05.md): definiciones etarias con frontera abierta de catorce años.

## Límites del análisis

La definición del art. 16 quáter, inc. 5 dice «menores de catorce» y «mayores de catorce»; no clasifica literalmente la edad exactamente catorce. Su aplicación requiere examen humano si ese caso resulta relevante. La calificación de `sancion` queda pendiente del régimen infraccional; el vacío no significa ausencia de tipificación.

**Conciliación sancionadora individual (01-10-2026):** En [Art. 16 quáter, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-01.md), la conducta habilitada es «Tratar datos personales de niños, niñas y adolescentes atendiendo a su interés superior y autonomía progresiva». Se cotejó con [Art. 34 quáter, inc. 1, lit. e](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-quáter/inciso-01-letra-e.md). El tratamiento fuera de las condiciones sensibles o de niñez puede ser grave conforme a art. 34 ter, letra g, o gravísimo si ocurre «a sabiendas» conforme a art. 34 quáter, letra e. El permiso lícito no selecciona un grado y no se presume conocimiento. `sancion` permanece vacío para esta habilitación.
