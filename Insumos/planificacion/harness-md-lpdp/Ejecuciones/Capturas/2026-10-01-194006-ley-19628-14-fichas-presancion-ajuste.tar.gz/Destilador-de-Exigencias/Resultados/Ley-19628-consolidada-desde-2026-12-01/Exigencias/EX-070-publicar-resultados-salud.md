---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-070"
enunciado: "El responsable puede publicar resultados de estudios de salud o perfil biológico si anonimiza previamente los datos publicados."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Publicar o difundir resultados de estudios científicos que usaron datos de salud o perfil biológico, previa anonimización de los datos publicados."
condicion_de_aplicacion: "Resultados de estudios o investigaciones científicas que utilizaron datos de salud o perfil biológico Y anonimización previa de los datos a publicar."
plazo: "anonimización previa a publicación"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 bis, inc. 2, lit. c, frag. 2, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02-letra-c-fragmento-02-fragmento-01.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 bis, inc. 2, lit. c, frag. 2, frag. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02-letra-c-fragmento-02-fragmento-02.md, anonimización previa"
cita_textual_de_respaldo: "Art. 16 bis, inc. 2, lit. c, frag. 2, frag. 1: «Los resultados de los estudios e investigaciones científicas que utilicen datos personales relativos a la salud o al perfil biológico pueden ser publicados o difundidos libremente.»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El primer fragmento permite publicar o difundir resultados libremente; el segundo impone anonimizar previamente los datos que se publiquen. La anonimización es condición de ejercicio del mismo permiso, no una publicación adicional.

## Alcance de la regla

El permiso se refiere a resultados de estudios o investigaciones que utilizaron datos de salud o perfil biológico. La anonimización debe anteceder a la publicación; no hay plazo posterior ni delegación. El carácter es `Condicional` por el supuesto expreso. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 16 bis, inc. 2, lit. c, frag. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02-letra-c-fragmento-02-fragmento-01.md): principal: regla expresada.
- [Art. 16 bis, inc. 2, lit. c, frag. 2, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02-letra-c-fragmento-02-fragmento-02.md): anonimización previa.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente. El vacío no significa ausencia de tipificación.

**Conciliación sancionadora individual (01-10-2026):** En [Art. 16 bis, inc. 2, lit. c, frag. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02-letra-c-fragmento-02-fragmento-01.md), la conducta habilitada es «Publicar o difundir resultados de estudios científicos que usaron datos de salud o perfil biológico, previa anonimización de los datos publicados». Se cotejó con [Art. 34 quáter, inc. 1, lit. e](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-quáter/inciso-01-letra-e.md). El tratamiento fuera de las condiciones sensibles o de niñez puede ser grave conforme a art. 34 ter, letra g, o gravísimo si ocurre «a sabiendas» conforme a art. 34 quáter, letra e. El permiso lícito no selecciona un grado y no se presume conocimiento. `sancion` permanece vacío para esta habilitación.
