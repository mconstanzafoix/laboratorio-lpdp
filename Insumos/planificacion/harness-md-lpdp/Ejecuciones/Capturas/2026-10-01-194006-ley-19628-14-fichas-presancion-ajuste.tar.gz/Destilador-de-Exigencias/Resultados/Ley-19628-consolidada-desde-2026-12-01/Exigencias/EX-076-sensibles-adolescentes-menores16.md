---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-076"
enunciado: "Los datos sensibles de adolescentes menores de dieciséis años requieren consentimiento representativo, salvo ley expresa."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Tratar datos sensibles de adolescentes menores de dieciséis años con consentimiento representativo, salvo ley expresa."
condicion_de_aplicacion: "Adolescente mayor de catorce y menor de dieciséis años Y consentimiento de padre, representante o cuidador personal O autorización/mandato legal expreso."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quáter, inc. 4, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-04.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quáter, inc. 5, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-05.md, definiciones etarias con frontera abierta de catorce años; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quáter, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-01.md, interés superior y autonomía progresiva"
cita_textual_de_respaldo: "Art. 16 quáter, inc. 4: «sólo se podrán tratar con el consentimiento otorgado por sus padres o representantes legales»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso cuarto crea una condición más estricta para datos sensibles de adolescentes menores de dieciséis años; se diferencia de la autorización general de adultos del inciso tercero.

## Alcance de la regla

Rigen consentimiento representativo o autorización legal expresa, junto al interés superior. La frontera de catorce años sigue abierta en la definición legal; no se infiere su clasificación. No hay plazo. El carácter es `Condicional` por el supuesto de datos de menores. Se registra `Indeterminada` por la valoración y límite señalados.

## Anclajes y función

- [Art. 16 quáter, inc. 4](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-04.md): principal: regla expresada.
- [Art. 16 quáter, inc. 5](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-05.md): definiciones etarias con frontera abierta de catorce años.
- [Art. 16 quáter, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-01.md): interés superior y autonomía progresiva.

## Límites del análisis

La definición del art. 16 quáter, inc. 5 dice «menores de catorce» y «mayores de catorce»; no clasifica literalmente la edad exactamente catorce. Su aplicación requiere examen humano si ese caso resulta relevante. La calificación de `sancion` queda pendiente del régimen infraccional; el vacío no significa ausencia de tipificación.

**Conciliación sancionadora individual (01-10-2026):** En [Art. 16 quáter, inc. 4](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-04.md), la conducta habilitada es «Tratar datos sensibles de adolescentes menores de dieciséis años con consentimiento representativo, salvo ley expresa». Se cotejó con [Art. 34 quáter, inc. 1, lit. e](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-quáter/inciso-01-letra-e.md). El tratamiento fuera de las condiciones sensibles o de niñez puede ser grave conforme a art. 34 ter, letra g, o gravísimo si ocurre «a sabiendas» conforme a art. 34 quáter, letra e. El permiso lícito no selecciona un grado y no se presume conocimiento. `sancion` permanece vacío para esta habilitación.
