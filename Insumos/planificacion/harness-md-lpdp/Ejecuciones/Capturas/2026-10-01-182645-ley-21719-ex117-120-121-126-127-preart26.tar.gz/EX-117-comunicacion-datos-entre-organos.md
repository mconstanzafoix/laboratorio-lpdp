---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-117"
enunciado: "Un órgano público puede comunicar o ceder datos a otro órgano público para funciones legales competentes o para beneficios al titular y simplificación de trámites, bajo finalidad específica."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Comunicar o ceder datos personales o bases de datos a otro órgano público para tratamiento específico."
condicion_de_aplicacion: "(Necesidad para funciones legales Y ambos órganos dentro de competencia) O (necesidad para otorgar beneficios al titular O evitar duplicidad de trámites O reiteración de requerimientos); tratamiento específico."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 1, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-01-fragmento-01.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 1, frag. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-01-fragmento-02.md, finalidad específica; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-02.md, alternativa de beneficios o simplificación"
cita_textual_de_respaldo: "Art. 22 reproducido, inc. 1 frag. 1: «están facultados para comunicar o ceder ... a otros órganos públicos»; inc. 2: «Asimismo, se podrá ... exclusivamente cuando»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "otorgar beneficios al titular; evitar duplicidad de trámites; evitar reiteración de requerimientos de información o documentos"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso primero faculta la comunicación o cesión entre órganos para funciones legales competentes. El segundo añade fines específicos de beneficio y simplificación. Ambos habilitan la misma operación interorgánica bajo rutas alternativas; el fragmento segundo del primer inciso exige un tratamiento específico en la operación.

## Alcance de la regla

La primera ruta requiere necesidad funcional **Y** competencia de ambos. La segunda requiere datos necesarios para alguno de tres fines listados (**O**), siempre vinculados a tratamiento específico. Comunicar **O** ceder son alternativas. Necesidad y competencia concreta exigen valoración: `Indeterminada`; carácter `Condicional`.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 1, frag. 1: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-01-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 1, frag. 2: [finalidad específica](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-01-fragmento-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 2: [alternativa de beneficios o simplificación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-02.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
