---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-120"
enunciado: "Concluido el tiempo necesario para el tratamiento específico, el órgano público receptor debe suprimir o anonimizar los datos recibidos, salvo conservación mayor habilitada."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Suprimir o anonimizar datos recibidos tras el tratamiento específico."
condicion_de_aplicacion: "Fin del tiempo necesario para tratamiento específico; excepción de conservación mayor para reclamaciones, control o garantía de decisiones."
plazo: "Luego del tiempo necesario para el tratamiento específico; sin cantidad de días."
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 3, frag. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-03-fragmento-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 3, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-03-fragmento-01.md, duración normal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 3, frag. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-03-fragmento-03.md, excepción de extensión"
cita_textual_de_respaldo: "Art. 22 reproducido, inc. 3 frag. 2: «luego de lo cual deberán ser suprimidos o anonimizados»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El segundo fragmento impone al receptor suprimir o anonimizar datos al concluir la necesidad de tratamiento. Son alternativas de cumplimiento (**O**), no dos deberes acumulativos. El fragmento siguiente admite conservación mayor en casos expresos y limita el momento de esta conducta.

## Alcance de la regla

Se activa al cesar el tiempo necesario, salvo la extensión justificada por reclamaciones, control o garantía de decisiones. No hay días definidos; juzgar necesidad exige valoración: `Indeterminada`. Carácter `Condicional`.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 3, frag. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-03-fragmento-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 3, frag. 1: [duración normal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-03-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 3, frag. 3: [excepción de extensión](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-03-fragmento-03.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
