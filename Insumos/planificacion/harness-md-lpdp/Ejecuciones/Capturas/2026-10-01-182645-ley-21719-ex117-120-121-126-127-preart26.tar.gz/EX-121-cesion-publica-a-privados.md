---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-121"
enunciado: "El órgano público debe contar con consentimiento del titular para comunicar o ceder datos a privados, salvo necesidad para fiscalización o inspección legal."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Obtener consentimiento del titular antes de comunicar o ceder datos a privados."
condicion_de_aplicacion: "Comunicación o cesión a persona o entidad privada; excepción si necesaria para funciones públicas de fiscalización o inspección."
plazo: "Antes de comunicar o ceder; sin cantidad de días."
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 4, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-04.md, principal"
cita_textual_de_respaldo: "Art. 22 reproducido, inc. 4: «deberán contar con el consentimiento del titular, salvo que ... sea necesaria ... en materia de fiscalización o inspección»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso cuarto obliga a contar con consentimiento para transferir datos desde órgano público a privado, salvo operación necesaria para fiscalización o inspección. La obligación se evalúa por la autorización del titular; no se confunde con la facultad interorgánica.

## Alcance de la regla

La excepción exige necesidad **Y** función de fiscalización o inspección. No hay plazo cuantificado; el consentimiento ha de existir para efectuar la comunicación o cesión. La necesidad funcional exige valoración: `Indeterminada`, carácter `Condicional`.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 22 reproducido de Ley 19.628, inc. 4: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-22/inciso-04.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
