---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-067"
enunciado: "El encargado debe aplicar medidas técnicas y organizativas apropiadas para garantizar un nivel de seguridad adecuado al riesgo del tratamiento."
destinatario: "Encargado del tratamiento"
modalidad: "Obligación"
conducta_exigida: "Aplicar medidas técnicas y organizativas apropiadas al nivel de riesgo del tratamiento."
condicion_de_aplicacion: "Tratamiento de datos personales por cuenta del responsable; ponderación de técnica, costos, naturaleza, alcance, contexto, fines y riesgos."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/inciso-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. a, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-a.md, medida posible; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. b, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-b.md, medida posible; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. c, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-c.md, medida posible; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. d, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-d.md, medida posible"
cita_textual_de_respaldo: "Art. 14 quinquies reproducido, inc. 2: «el responsable y el encargado del tratamiento aplicarán medidas técnicas y organizativas apropiadas para garantizar un nivel de seguridad adecuado al riesgo»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El inciso segundo atribuye expresamente al encargado, además del responsable, el deber de aplicar medidas de seguridad. Esta ficha recoge la posición del encargado; la del responsable continúa en la Exigencia de seguridad ya abierta. «Aplicarán» sostiene la obligación, aunque la clasificación recibida no registra un marcador expreso.

## Alcance de la regla

La idoneidad de medidas se valora según técnica, costos, características del tratamiento y riesgo para derechos y libertades. Las letras a a d ofrecen medidas «entre otros» y, «en su caso», no una lista cerrada de acciones universalmente acumulativas: seudonimización/cifrado, continuidad de seguridad, restauración y evaluación regular. La adecuación al riesgo exige valoración jurídica y técnica; `Indeterminada`. No se fija plazo expreso.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, inc. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/inciso-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. a: [medida posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-a.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. b: [medida posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-b.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. c: [medida posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-c.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. d: [medida posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-d.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y las remisiones pertinentes; no implica ausencia de tipificación.
