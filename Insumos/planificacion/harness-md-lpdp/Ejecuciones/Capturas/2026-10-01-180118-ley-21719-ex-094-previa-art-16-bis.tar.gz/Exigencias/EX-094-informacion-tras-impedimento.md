---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-094"
enunciado: "Al cesar el impedimento de consentir, el responsable debe informar detalladamente al titular los datos tratados y operaciones realizadas bajo la excepción del artículo 16 letra c."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Informar al titular los datos tratados y operaciones específicas efectuadas."
condicion_de_aplicacion: "Tratamiento excepcional por impedimento físico o jurídico del titular para consentir Y cese de ese impedimento."
plazo: "Una vez que cese el impedimento; sin cantidad de días expresamente fijada."
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 reproducido de Ley 19.628, lit. c, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16/letra-c.md, principal"
cita_textual_de_respaldo: "Art. 16 reproducido, letra c: «Una vez que cese el impedimento, el responsable debe informar detalladamente al titular los datos que fueron tratados»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "datos que fueron tratados; operaciones específicas de tratamiento realizadas"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La segunda oración de la letra c impone un deber informativo después de tratar datos cuando el titular estaba impedido de consentir. Su conducta posterior es autónoma del permiso excepcional de tratamiento de la primera oración.

## Alcance de la regla

Se exige impedimento físico **O** jurídico, uso de esa causal y cese del impedimento. Debe informarse de datos **Y** operaciones específicas. No hay cantidad de días. La suficiencia del detalle requiere valoración: `Indeterminada`, carácter `Condicional`.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 reproducido de Ley 19.628, lit. c: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16/letra-c.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
