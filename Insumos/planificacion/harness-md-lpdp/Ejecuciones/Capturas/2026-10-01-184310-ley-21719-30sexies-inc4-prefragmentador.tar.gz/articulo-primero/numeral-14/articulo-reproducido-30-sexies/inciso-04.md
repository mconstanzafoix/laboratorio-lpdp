---
identificador: "Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 4"
fuente: "Ley 21.719 modificatoria, vigencia diferida desde 01-12-2026 (PDF BCN, última modificación impresa Ley 21.806, 05-02-2026)"
localizacion_y_version: "Fuentes-primarias/Ley-21719-2024/Ley-21719_13-DIC-2024.pdf, pág. 34; vigencia diferida desde 01-12-2026"
tipo_de_norma: "Constitutiva"
clasificacion_normativa_deontica: "No aplica — norma no regulativa"
control_ingreso: "PDF primario, columna normativa, pág. 34; literal y localizador cotejados: conforme"
remisiones: "artículo 30 quáter"
---

# Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 4

- **Contexto:** [artículo del nivel inmediato](articulo.md); [instrucción modificatoria](../instruccion.md).

## Texto literal (bloque espejo)

> Si el consejero que cesare en el cargo en virtud del presente artículo invistiere la condición de presidente o vicepresidente del Consejo Directivo de la Agencia, su reemplazante será designado en la forma prevista en el artículo 30 quáter, por el tiempo que faltare al que produjo la vacante.

## Análisis breve
Cuando quien cesa era presidente o vicepresidente del Consejo, ese cargo directivo se cubre conforme al artículo 30 quáter por el plazo restante del titular saliente. El inciso atiende a la vacancia de la presidencia o vicepresidencia, además de la de consejero.

## Comprobación
Se cotejó esta unidad contra el PDF primario en la(s) página(s) 34: palabras, puntuación, comillas y localizador coinciden tras normalizar sólo espacios y saltos de maquetación. Se comprobó su posición en la secuencia completa del artículo y su enlace de contexto. No queda duda de cotejo textual en esta unidad.

## Tipo de norma
Constitutiva: «su reemplazante será designado» fija la sustitución en la presidencia o vicepresidencia y su plazo.

## Clasificación deóntica
No aplica: el tipo asignado es Constitutiva; se define un impedimento, causal, reemplazo o suplencia del cargo, sin fuerza deóntica local independiente.
