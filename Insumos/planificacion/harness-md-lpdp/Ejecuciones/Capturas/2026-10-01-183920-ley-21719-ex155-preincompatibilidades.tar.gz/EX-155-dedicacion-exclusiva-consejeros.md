---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-155"
enunciado: "El consejero de la Agencia debe ejercer su cargo con dedicación exclusiva."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Mantener dedicación exclusiva al cargo de consejero."
condicion_de_aplicacion: "Ejercicio del cargo de consejero del Consejo Directivo."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 6, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-06.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 6: «El cargo de consejero del Consejo Directivo de la Agencia exige dedicación exclusiva.»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El texto principal expresa «El cargo de consejero del Consejo Directivo de la Agencia exige dedicación exclusiva.». El sujeto específico es Consejo Directivo o consejero; se codifica `Tercero` porque no es uno de los otros cinco destinatarios cerrados de este producto. Esta ficha aísla la conducta mantener dedicación exclusiva al cargo de consejero. de las restantes posiciones del artículo.

## Alcance de la regla

Ejercicio del cargo de consejero del Consejo Directivo. El texto no define exhaustivamente los actos incompatibles con dedicación exclusiva; su aplicación requiere valoración. El carácter es Condicional. No se expresa plazo cuantitativo para esta conducta.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 6: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-06.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, instrucción modificatoria: [incorporación del Título VI](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacío hasta revisar el régimen sancionador aplicable de esta Fuente y sus remisiones; el vacío no equivale a no tipificada.
