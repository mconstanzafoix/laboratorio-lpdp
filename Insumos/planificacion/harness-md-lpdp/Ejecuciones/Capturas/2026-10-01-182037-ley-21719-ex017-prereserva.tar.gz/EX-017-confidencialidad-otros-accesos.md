---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-017"
enunciado: "Guardar secreto o confidencialidad sobre los datos personales a los que accede."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Guardar secreto o confidencialidad sobre los datos personales a los que accede."
condicion_de_aplicacion: "Persona distinta del responsable con acceso a los datos, incluidas las personas, instituciones y dependientes del art. 24 respecto del requerimiento y remisión de información; subsiste tras concluir la relación con el titular."
plazo: "Subsiste después de concluida la relación con el titular; duración final No determinada."
disposicion_de_anclaje: "Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. h, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-h.md, principal; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md, incorporación y contexto de principios; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md, incorporación y contexto de principios; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 bis reproducido de Ley 19.628, inc. 4, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-bis/inciso-04.md, delimitación del secreto o identificación del sujeto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 24 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-24/inciso-01.md, delimitación del secreto o identificación del sujeto"
cita_textual_de_respaldo: "Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. h: «quienes tengan acceso a ellos deberán guardar secreto o confidencialidad»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El texto principal dice «quienes tengan acceso a ellos deberán guardar secreto o confidencialidad». La misma oración también atribuye el deber a quienes tengan acceso a los datos. Como no los identifica por uno de los cinco roles específicos, se usa el valor residual Tercero para este grupo; la ficha separa destinatarios, no inventa una conducta distinta.

## Alcance de la regla

El art. 14 bis reproducido, inciso cuarto, extiende expresamente el deber a personas, instituciones y dependientes del régimen especial del art. 24 en cuanto al requerimiento y la remisión de información. El deber persiste tras la relación con el titular y no tiene término final expreso. El alcance del acceso es concreto al caso, por lo que la determinación exige valoración. La clasificación de la ficha es `Indeterminada` y el carácter es `Transversal` por las razones anteriores.

## Anclajes y función

- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. h: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-h.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, instrucción modificatoria: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

- Art. primero, num. 8, art. 14 bis reproducido de Ley 19.628, inc. 4: [delimitación del secreto o sujeto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-bis/inciso-04.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 12, art. 24 reproducido de Ley 19.628, inc. 1: [delimitación del secreto o sujeto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-24/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` permanece vacío hasta comprobar el régimen sancionador pertinente de esta Fuente y sus remisiones expresas; no equivale a `0 No tipificada`.
