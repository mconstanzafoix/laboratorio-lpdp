---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-181"
enunciado: "La Agencia debe consignar en el Registro Nacional a responsables que adopten modelos certificados de prevención de infracciones vigentes."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Registrar responsables con modelos certificados vigentes."
condicion_de_aplicacion: "Responsable adopta modelo certificado de prevención de infracciones con carácter vigente."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 39 reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-39/inciso-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 39 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-39/inciso-01.md, condición, consecuencia o elemento de lista; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 39 reproducido de Ley 19.628, inc. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-39/inciso-03.md, condición, consecuencia o elemento de lista"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 39 reproducido de Ley 19.628, inc. 2: «También se deberán consignar los responsables que adopten modelos certificados de prevención de infracciones, con carácter vigente»."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El anclaje principal dispone «En él se deberán consignar a los responsables de datos que hayan sido sancionados por infringir los derechos y obligaciones establecidos en esta ley. Deberá distinguirse según la gravedad de la infracción. Adicionalmente, se deberá consignar la conducta infraccionada, las circunstancias atenuantes y agravantes de responsabilidad y la sanción impuesta. También se deberán consignar los responsables que adopten modelos certificados de prevención de infracciones, con carácter vigente.». El sujeto de esta ficha es agencia; la conducta registrar responsables con modelos certificados vigentes. se distingue de los otros deberes o efectos del artículo.

## Alcance de la regla

Responsable adopta modelo certificado de prevención de infracciones con carácter vigente. La condición de modelo certificado vigente y la conducta registral están explícitas. El carácter es `Condicional` por su supuesto específico. No consta plazo cuantitativo para esta conducta.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 39 reproducido de Ley 19.628, inc. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-39/inciso-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 39 reproducido de Ley 19.628, inc. 1: [condición, consecuencia o elemento de lista](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-39/inciso-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 39 reproducido de Ley 19.628, inc. 3: [condición, consecuencia o elemento de lista](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-39/inciso-03.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, instrucción modificatoria: [incorporación del Título VII](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` permanece vacía hasta conciliar tipificaciones del Título VII y sus remisiones; el vacío no significa que no exista consecuencia.
