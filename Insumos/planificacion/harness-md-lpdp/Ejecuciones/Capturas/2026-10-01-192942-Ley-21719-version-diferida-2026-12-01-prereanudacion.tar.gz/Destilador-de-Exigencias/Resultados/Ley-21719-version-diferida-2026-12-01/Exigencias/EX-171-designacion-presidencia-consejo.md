---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-171"
enunciado: "El Consejo Directivo debe designar entre sus miembros a su presidente y vicepresidente conforme a sus estatutos, también para reemplazar a quienes cesen."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Designar presidente y vicepresidente del Consejo entre sus miembros."
condicion_de_aplicacion: "Integración del Consejo Directivo O vacante de presidencia/vicepresidencia por cesación; designación conforme a estatutos."
plazo: ""
cita_textual_de_respaldo: "Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 4: «El Consejo Directivo de la Agencia designará a su presidente y vicepresidente, de entre sus miembros, de conformidad con lo establecido en los estatutos de la Agencia»."
estado_de_determinacion: "Delegada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 4, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-04.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 4, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-sexies/inciso-04.md, reemplazo por vacancia; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 octies reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-octies/inciso-01.md, estatutos como instrumento de procedimiento"
---

## Fundamento textual e interpretación

El inciso cuarto usa «designará» para imponer al Consejo la designación de presidente y vicepresidente entre los consejeros. El inciso cuarto del artículo 30 sexies extiende la misma forma al reemplazo cuando quien cesa presidía o ejercía la vicepresidencia. El Consejo es `Tercero` según el vocabulario cerrado.

## Alcance de la regla

La designación inicial y el reemplazo por vacante son supuestos de la misma conducta. Los cargos duran tres años o el tiempo restante como consejero; el reemplazo dura el tiempo que faltaba al reemplazado. Esas duraciones no son plazo para ejecutar la designación. El procedimiento se encomienda expresamente a los estatutos de la Agencia, cuya regulación general prevé el art. 30 octies; por ello la regla es `Delegada`. El carácter es `Condicional` al nombramiento o vacancia.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 4: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-04.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 4: [reemplazo por vacancia](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-sexies/inciso-04.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 octies reproducido de Ley 19.628, inc. 1: [estatutos como instrumento de procedimiento](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-octies/inciso-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, instrucción modificatoria: [incorporación del Título VI](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta cotejar el régimen sancionador pertinente; no equivale a no tipificada.
