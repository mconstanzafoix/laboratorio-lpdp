# Cobertura de destilación — Ley N° 21.719 modificatoria, versión diferida 01-12-2026

Fuente y árbol: [FUENTE.md](../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/FUENTE.md) · [ARBOL.md](../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/ARBOL.md).
Nivel de autoridad humana recibido: Vinculante nacional — MCF, 01-10-2026, registro del Orquestador en Ejecuciones/2026-10-01-orquestador-destilacion-tres-fuentes.md.
Estado de esta salida: Propuesta sin visar.
Último EX asignado: EX-195

| Artículo | Esperadas | Cerradas | Incompletas | Pendientes | Estado |
| --- | ---: | ---: | ---: | ---: | --- |
| [articulo-primero](Articulos/articulo-primero/RESULTADO.md) | 674 | 502 | 22 | 150 | Parcial |
| [articulo-segundo](Articulos/articulo-segundo/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [articulo-tercero](Articulos/articulo-tercero/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [articulo-transitorio-primero](Articulos/articulo-transitorio-primero/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [articulo-transitorio-segundo](Articulos/articulo-transitorio-segundo/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [articulo-transitorio-tercero](Articulos/articulo-transitorio-tercero/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [articulo-transitorio-cuarto](Articulos/articulo-transitorio-cuarto/RESULTADO.md) | 5 | 0 | 0 | 5 | Pendiente |
| [articulo-transitorio-quinto](Articulos/articulo-transitorio-quinto/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [articulo-transitorio-sexto](Articulos/articulo-transitorio-sexto/RESULTADO.md) | 2 | 0 | 0 | 2 | Pendiente |
| [articulo-transitorio-septimo](Articulos/articulo-transitorio-septimo/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [articulo-transitorio-octavo](Articulos/articulo-transitorio-octavo/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |

Total esperado: 689 Disposiciones en 11 artículos.
Verificación de cobertura: pendiente de examen y conciliación final. Avance recuperable: instrucción general y numerales 1 a 7 del artículo primero recorridos; numeral 8 numerales 8 a 11 recorridos; numeral 12 recorrido hasta art. 26; numeral 13 recorrido completo; numeral 14 recorrido hasta art. 41, salvo letra i pendiente de art. 43, con arts. 33–34 quáter por conciliar, con remisiones internas y externas por conciliar, salvo el art. 16 quáter inc. 5. Hay 502 filas cerradas, 22 incompletas y 165 pendientes en la Fuente. Tres incompletas del art. 10 reproducido derivan de la remisión al art. 28 inc. 4, comunicada al Orquestador y conservada en el informe de Opciones como antecedente sin decisión. La clasificación de ingreso del art. 14 quáter inc. 1 reproducido fue corregida por el Fragmentador y la fila quedó cerrada con EX-072. Una nueva incompleta en art. 16 quáter inc. 5 corresponde al umbral omitido de exactamente catorce años y afecta la aplicación de incs. 2 a 4; remitida al Orquestador para antecedentes. La remisión del art. 13 al Título III se leyó como contexto en la versión consolidada de la Ley 19.628; la ficha de esta modificatoria conserva su propio anclaje principal. Las relaciones posteriores y las sanciones de las 135 fichas requieren conciliación transversal.
