---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-148"
enunciado: "La Agencia debe emitir sus instrucciones y normas generales después de consulta pública web, con medios para observaciones, limitadas a lo estrictamente relacionado y necesario para cumplir la ley."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Emitir instrucciones y normas generales previa consulta pública web, habilitando observaciones y guardando conexión estricta con tratamiento de datos."
condicion_de_aplicacion: "Agencia dicta instrucciones o normas generales obligatorias."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 bis reproducido de Ley 19.628, lit. a, frag. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-bis/letra-a-fragmento-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 bis reproducido de Ley 19.628, lit. a, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-bis/letra-a-fragmento-01.md, contexto de atribución"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 30 bis reproducido de Ley 19.628, lit. a, frag. 2: «Las instrucciones y normas generales que dicte la Agencia deberán ser emitidas previa consulta pública efectuada a través de la página web institucional y deberán estar relaci»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El anclaje principal establece: «Las instrucciones y normas generales que dicte la Agencia deberán ser emitidas previa consulta pública efectuada a través de la página web institucional y deberán estar relacionadas estrictamente con la regulación de tratamiento de datos personales y que sea necesaria para el fiel cumplimiento de la presente ley, disponiéndose los mecanismos necesarios para que los interesados puedan formular observaciones a ésta.». La Agencia es el sujeto de la facultad o deber. Esta ficha aísla emitir instrucciones y normas generales previa consulta pública web, habilitando observaciones y guardando conexión estricta con tratamiento de datos. de las restantes funciones enumeradas en el artículo 30 bis.

## Alcance de la regla

Agencia dicta instrucciones o normas generales obligatorias. La necesidad y relación estricta con la regulación requieren valoración jurídica; el procedimiento de consulta es expreso. Su carácter es Condicional por el supuesto descrito. No existe plazo cuantitativo expreso.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 bis reproducido de Ley 19.628, lit. a, frag. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-bis/letra-a-fragmento-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 bis reproducido de Ley 19.628, lit. a, frag. 1: [contexto de atribución](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-bis/letra-a-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, instrucción modificatoria: [incorporación del Título VI](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no significa ausencia de tipificación.
