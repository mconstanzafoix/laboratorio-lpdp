---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-012"
enunciado: "Garantizar seguridad adecuada y adoptar medidas apropiadas para proteger los datos personales durante el tratamiento."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Garantizar seguridad adecuada y adoptar medidas apropiadas para proteger los datos personales durante el tratamiento."
condicion_de_aplicacion: "Tratamiento de datos personales por el responsable; medidas acordes con el tratamiento y naturaleza de los datos."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. f, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-f.md, principal; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md, incorporación y contexto de principios; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md, incorporación y contexto de principios; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 septies reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-septies/inciso-01.md, criterios de diferenciación de estándares; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 septies reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-septies/inciso-02.md, delegación expresa de estándares mínimos a la Agencia; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/inciso-01.md, contenido del deber del responsable; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/inciso-02.md, proporcionalidad y medidas apropiadas; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. a, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-a.md, medida posible; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. b, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-b.md, medida posible; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. c, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-c.md, medida posible; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. d, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-d.md, medida posible"
cita_textual_de_respaldo: "Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. f: «el responsable debe garantizar estándares adecuados de seguridad»"
estado_de_determinacion: "Delegada"
enumeracion_contenida: "tratamiento no autorizado o ilícito; pérdida; filtración; daño accidental; destrucción"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El texto principal dice «el responsable debe garantizar estándares adecuados de seguridad». La letra f nombra al responsable y expresa un deber de seguridad. La segunda oración concreta cómo deben ser las medidas para cumplir el mismo deber; se conserva una ficha.

## Alcance de la regla

La adecuación de estándares y medidas depende del tratamiento y naturaleza de los datos y exige valoración. No hay plazo expreso. La regla atraviesa todo tratamiento del responsable. La clasificación de la ficha es `Delegada`: el artículo 14 septies, inciso segundo, encarga expresamente a la Agencia fijar mediante instrucción general los estándares o condiciones mínimas de seguridad del responsable; el inciso primero fija los criterios de diferenciación. El carácter es `Transversal`. La adecuación al riesgo conserva elementos valorativos.

## Anclajes y función

- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. f: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-f.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, instrucción modificatoria: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 septies reproducido de Ley 19.628, inc. 1: [criterios de diferenciación de estándares](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-septies/inciso-01.md).

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 septies reproducido de Ley 19.628, inc. 2: [delegación expresa de estándares mínimos a la Agencia](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-septies/inciso-02.md).


- El artículo 14 quinquies, incisos primero y segundo, concreta la obligación de seguridad del responsable: medidas necesarias, apropiadas al riesgo, y orientadas a confidencialidad, integridad, disponibilidad y resiliencia. Sus letras a a d son ejemplos no cerrados de medidas posibles.

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, inc. 1: [contenido del deber del responsable](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/inciso-01.md).

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, inc. 2: [proporcionalidad y medidas apropiadas](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/inciso-02.md).

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. a: [medida posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-a.md).

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. b: [medida posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-b.md).

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. c: [medida posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-c.md).

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quinquies reproducido de Ley 19.628, lit. d: [medida posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quinquies/letra-d.md).

## Límites del análisis

`sancion` permanece vacío hasta comprobar el régimen sancionador pertinente de esta Fuente y sus remisiones expresas; no equivale a `0 No tipificada`.
