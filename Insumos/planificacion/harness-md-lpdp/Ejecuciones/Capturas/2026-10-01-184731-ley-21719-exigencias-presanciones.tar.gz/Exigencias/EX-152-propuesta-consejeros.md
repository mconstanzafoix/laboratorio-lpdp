---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-152"
enunciado: "El Presidente de la República debe proponer la nómina para designar consejeros de la Agencia, incluida la vacante por cesación para el período restante."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Proponer al Senado la nómina de consejeros que corresponda."
condicion_de_aplicacion: "Designación inicial de consejero O provisión de vacante por cesación, esta última para el período restante."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-01.md, contexto o condición; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-03.md, contexto o condición; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-sexies/inciso-03.md, aplicación a vacante por cesación"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 2: «Para efectos de su designación, el Presidente de la República hará la proposición de la nómina que corresponda y el Senado deberá pronunciarse respecto de la propuesta.»."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El artículo 30 quáter inciso 2 atribuye al Presidente de la República el proposición de nómina. El artículo 30 sexies inciso 3 ordena usar el mismo procedimiento ante una vacante. El sujeto se codifica `Tercero` conforme al vocabulario cerrado; esta conducta se distingue de la posición del otro órgano.

## Alcance de la regla

El deber de propuesta opera tanto en designación inicial como ante una vacante por cesación. El artículo 30 sexies inciso 3 remite al mismo procedimiento y limita la duración del reemplazante al período restante. Sujeto y acto están fijados: `Determinada`; carácter `Condicional`. No hay plazo cuantitativo para presentar la nómina.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 1: [contexto o condición](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 3: [contexto o condición](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-03.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 3: [aplicación a vacante por cesación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-sexies/inciso-03.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, instrucción modificatoria: [incorporación del Título VI](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacío hasta revisar el régimen sancionador aplicable de esta Fuente y sus remisiones; el vacío no equivale a no tipificada.
