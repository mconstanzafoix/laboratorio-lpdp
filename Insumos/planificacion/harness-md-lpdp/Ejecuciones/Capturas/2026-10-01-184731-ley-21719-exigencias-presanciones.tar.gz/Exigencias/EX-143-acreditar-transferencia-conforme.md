---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-143"
enunciado: "El responsable que efectuó una transferencia internacional debe acreditar ante la Agencia que se practicó conforme a la ley."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Acreditar ante la Agencia la conformidad legal de la transferencia efectuada."
condicion_de_aplicacion: "Responsable que efectuó una transferencia internacional de datos."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 6, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-28/inciso-06.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 6: «Corresponderá al responsable de datos que efectuó la transferencia internacional de datos, acreditar ante la Agencia que ésta se practicó de conformidad a las reglas establecidas en est»."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El anclaje principal dispone: «Corresponderá al responsable de datos que efectuó la transferencia internacional de datos, acreditar ante la Agencia que ésta se practicó de conformidad a las reglas establecidas en esta ley.». El sujeto nombrado es responsable de datos; la fuerza de la regla resulta del verbo normativo de ese texto. Es una conducta autónoma respecto de las demás posiciones del artículo 28.

## Alcance de la regla

Responsable que efectuó una transferencia internacional de datos. Sujeto, conducta y estándar legal quedan identificados; la comprobación fáctica del caso no es delegación del contenido. El carácter es Condicional por el supuesto expresado. No hay plazo expreso para esta conducta.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 6: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-28/inciso-06.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, instrucción modificatoria: [incorporación del Título V](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/instruccion.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; el vacío no implica que no exista tipificación.
