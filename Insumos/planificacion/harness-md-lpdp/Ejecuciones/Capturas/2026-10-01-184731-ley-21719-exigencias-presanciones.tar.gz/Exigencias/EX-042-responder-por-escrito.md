---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-042"
enunciado: "Responder por escrito al titular en el domicilio o correo electrónico que éste fijó."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Responder por escrito al titular en el domicilio o correo electrónico que éste fijó."
condicion_de_aplicacion: "Respuesta a solicitud de ejercicio de derechos."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-03.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 2, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-02-fragmento-01.md, condición, excepción, procedimiento o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md, incorporación"
cita_textual_de_respaldo: "Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 3: «El responsable deberá responder por escrito al titular a su domicilio o la dirección de correo electrónico fijada por éste.»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "domicilio; dirección de correo electrónico"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Disposición principal dice «El responsable deberá responder por escrito al titular a su domicilio o la dirección de correo electrónico fijada por éste.». La primera oración prescribe la forma y destino de la respuesta. La segunda agrega un deber distinto de conservar respaldo probatorio, que se separa.

## Alcance de la regla

El medio y destino están fijados por el texto y la indicación del titular. El plazo de pronunciamiento consta en el inciso segundo, no se inventa otro aquí. El estado de determinación es `Determinada` y el carácter `Condicional` por el alcance descrito.

## Anclajes y función

- Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 3: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-03.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 2, frag. 1: [condición, excepción, procedimiento o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-02-fragmento-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, instrucción modificatoria: [incorporación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
