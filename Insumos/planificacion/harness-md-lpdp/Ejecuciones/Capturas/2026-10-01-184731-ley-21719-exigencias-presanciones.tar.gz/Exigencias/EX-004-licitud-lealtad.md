---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-004"
enunciado: "Tratar datos personales únicamente de manera lícita y leal."
destinatario: "Tercero"
modalidad: "Permiso condicionado"
conducta_exigida: "Tratar datos personales únicamente de manera lícita y leal."
condicion_de_aplicacion: "Tratamiento de datos personales Y licitud Y lealtad."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. a, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-a.md, principal; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md, incorporación y contexto de principios; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md, incorporación y contexto de principios"
cita_textual_de_respaldo: "Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. a: «Los datos personales sólo pueden tratarse de manera lícita y leal.»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El texto principal dice «Los datos personales sólo pueden tratarse de manera lícita y leal.». La letra a expresa una condición general para tratar datos. Su redacción pasiva no limita la posición a un rol particular, por lo que se emplea el valor residual Tercero. El deber distinto de acreditar la licitud se conserva en otra ficha.

## Alcance de la regla

Lícita y leal son conceptos abiertos que exigen valoración jurídica al aplicar la regla. La condición afecta transversalmente todo tratamiento; no hay plazo expreso. La clasificación de la ficha es `Indeterminada` y el carácter es `Transversal` por las razones anteriores.

## Anclajes y función

- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. a: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-a.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, instrucción modificatoria: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` permanece vacío hasta comprobar el régimen sancionador pertinente de esta Fuente y sus remisiones expresas; no equivale a `0 No tipificada`.
