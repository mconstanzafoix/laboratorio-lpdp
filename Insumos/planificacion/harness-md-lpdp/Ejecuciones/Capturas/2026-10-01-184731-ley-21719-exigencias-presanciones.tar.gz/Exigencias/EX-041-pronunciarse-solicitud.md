---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-041"
enunciado: "Pronunciarse sobre la solicitud del titular dentro de treinta días corridos desde su ingreso, con una única prórroga posible de hasta treinta días corridos."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Pronunciarse sobre la solicitud del titular dentro de treinta días corridos desde su ingreso, con una única prórroga posible de hasta treinta días corridos."
condicion_de_aplicacion: "Recepción de solicitud del titular."
plazo: "30 días corridos desde ingreso de solicitud; prorrogable una sola vez hasta por 30 días corridos."
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 2, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-02-fragmento-01.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 2, frag. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-02-fragmento-02.md, condición, excepción, procedimiento o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md, incorporación"
cita_textual_de_respaldo: "Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 2, frag. 1: «pronunciarse a más tardar dentro de los treinta días corridos siguientes a la fecha de ingreso de la solicitud»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Disposición principal dice «pronunciarse a más tardar dentro de los treinta días corridos siguientes a la fecha de ingreso de la solicitud». La misma oración exige pronunciarse en plazo; la facultad de prorrogar del fragmento siguiente modifica ese plazo y no crea una ficha de conducta separada.

## Alcance de la regla

El plazo inicial y la única prórroga están cuantificados expresamente en días corridos. No se exige causa fundada para prorrogar en este texto. El estado de determinación es `Determinada` y el carácter `Condicional` por el alcance descrito.

## Anclajes y función

- Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 2, frag. 1: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-02-fragmento-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 2, frag. 2: [condición, excepción, procedimiento o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-02-fragmento-02.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, instrucción modificatoria: [incorporación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
