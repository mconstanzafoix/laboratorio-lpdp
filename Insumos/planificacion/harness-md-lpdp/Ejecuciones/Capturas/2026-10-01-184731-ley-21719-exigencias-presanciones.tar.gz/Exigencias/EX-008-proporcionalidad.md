---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-008"
enunciado: "Limitar los datos tratados a los necesarios, adecuados y pertinentes para los fines del tratamiento."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Limitar los datos tratados a los necesarios, adecuados y pertinentes para los fines del tratamiento."
condicion_de_aplicacion: "Tratamiento de datos personales en relación con fines determinados."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. c, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-c.md, principal; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md, incorporación y contexto de principios; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md, incorporación y contexto de principios"
cita_textual_de_respaldo: "Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. c: «deben limitarse estrictamente a aquéllos que resulten necesarios, adecuados y pertinentes»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "necesarios; adecuados; pertinentes"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El texto principal dice «deben limitarse estrictamente a aquéllos que resulten necesarios, adecuados y pertinentes». La letra c establece una regla sobre la cantidad y clase de datos tratados, autónoma frente al plazo de conservación que aparece en su párrafo siguiente. La voz pasiva admite al sujeto general Tercero.

## Alcance de la regla

Necesidad, adecuación y pertinencia requieren valoración según los fines del tratamiento. No hay plazo expreso y la regla se aplica transversalmente. La clasificación de la ficha es `Indeterminada` y el carácter es `Transversal` por las razones anteriores.

## Anclajes y función

- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. c: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-c.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, instrucción modificatoria: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` permanece vacío hasta comprobar el régimen sancionador pertinente de esta Fuente y sus remisiones expresas; no equivale a `0 No tipificada`.
