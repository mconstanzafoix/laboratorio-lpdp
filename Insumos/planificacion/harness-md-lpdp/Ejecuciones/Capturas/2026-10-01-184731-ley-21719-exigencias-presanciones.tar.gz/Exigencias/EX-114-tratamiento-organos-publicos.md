---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-114"
enunciado: "Los órganos públicos pueden tratar datos personales sin consentimiento para cumplir sus funciones legales dentro de sus competencias y conforme a la ley y al Título IV."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Tratar datos personales en ejercicio de funciones legales sin requerir consentimiento del titular."
condicion_de_aplicacion: "Cumplimiento de funciones legales Y dentro de competencia Y conformidad con ley Y disposiciones del Título IV."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 20 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-20/inciso-01.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 21 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-21/inciso-01.md, principios aplicables; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/instruccion.md, reemplazo del Título IV"
cita_textual_de_respaldo: "Art. 20 reproducido, inc. 1: «Es lícito el tratamiento ... para el cumplimiento de sus funciones legales, dentro del ámbito de sus competencias» y «no requieren el consentimiento»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El artículo 20 permite tratamiento por órganos públicos sin consentimiento cuando actúan para funciones legales dentro de su competencia. La misma disposición los reconoce como responsables de datos en esas condiciones, de modo que la ficha usa ese rol.

## Alcance de la regla

Los requisitos son acumulativos (**Y**): función legal, competencia, ley y Título IV. La licitud depende del alcance concreto de atribuciones, que requiere valoración: `Indeterminada`; carácter `Condicional`. No hay plazo expreso. El artículo 21 hace aplicables principios y otras normas, cuya relación se sigue examinando.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 20 reproducido de Ley 19.628, inc. 1: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-20/inciso-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 21 reproducido de Ley 19.628, inc. 1: [principios aplicables](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-21/inciso-01.md).

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, instrucción modificatoria: [reemplazo del Título IV](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/instruccion.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
