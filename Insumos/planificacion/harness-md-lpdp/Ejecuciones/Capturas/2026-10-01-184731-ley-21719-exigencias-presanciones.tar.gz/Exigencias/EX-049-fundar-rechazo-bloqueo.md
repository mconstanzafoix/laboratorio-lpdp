---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-049"
enunciado: "Fundar la respuesta que rechaza el bloqueo temporal solicitado por el titular."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Fundar la respuesta que rechaza el bloqueo temporal solicitado por el titular."
condicion_de_aplicacion: "Rechazo del requerimiento de bloqueo temporal."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 6, frag. 5, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-06-fragmento-05.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md, incorporación"
cita_textual_de_respaldo: "Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 6, frag. 5: «En caso de rechazo el responsable deberá fundar su respuesta»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Disposición principal dice «En caso de rechazo el responsable deberá fundar su respuesta». El fragmento impone dos actos: fundar el rechazo y comunicar electrónicamente a la Agencia. Esta ficha se limita al fundamento; la comunicación se registra por separado.

## Alcance de la regla

La suficiencia del fundamento requiere valoración jurídica. El deber surge únicamente al rechazar el bloqueo. El estado de determinación es `Indeterminada` y el carácter `Condicional` por el alcance descrito.

## Anclajes y función

- Art. primero, num. 7, art. 11 reproducido de Ley 19.628, inc. 6, frag. 5: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-11/inciso-06-fragmento-05.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, instrucción modificatoria: [incorporación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
