---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-029"
enunciado: "Adoptar medidas necesarias para asegurar derechos y libertades del titular en decisiones basadas en tratamiento automatizado."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Adoptar medidas necesarias para asegurar derechos y libertades del titular en decisiones basadas en tratamiento automatizado."
condicion_de_aplicacion: "Toda decisión basada en tratamiento automatizado, incluidas las excepciones de las letras a, b y c."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-03.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-01.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-02.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md, incorporación"
cita_textual_de_respaldo: "Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 3: «el responsable deberá adoptar las medidas necesarias para asegurar los derechos y libertades del titular»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "información y transparencia; obtener una explicación; intervención humana; expresar su punto de vista; solicitar la revisión de la decisión"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La Disposición principal dice «el responsable deberá adoptar las medidas necesarias para asegurar los derechos y libertades del titular». El inciso impone un deber propio del responsable aun cuando proceda una excepción al derecho del inciso primero. La enumeración describe garantías que deben asegurar las medidas; se conserva la misma conducta de adoptar medidas.

## Alcance de la regla

La suficiencia de las medidas requiere valoración. La regla se extiende a todos los casos de decisión automatizada y no contiene plazo expreso. El estado de determinación es `Indeterminada` y el carácter `Transversal` por el alcance descrito.

## Anclajes y función

- Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 3: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-03.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 1: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 2: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-02.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, instrucción modificatoria: [incorporación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
