---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-134"
enunciado: "Se prohíbe el tratamiento masivo de datos personales de registros electrónicos públicos de infracciones penales, civiles, administrativas o disciplinarias."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "Abstenerse de tratar masivamente datos de esos registros electrónicos."
condicion_de_aplicacion: "Datos personales contenidos en registros electrónicos de infracciones llevados por organismos públicos."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 25 reproducido de Ley 19.628, inc. 5, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-25/inciso-05-fragmento-01.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 25 reproducido de Ley 19.628, inc. 5, frag. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-25/inciso-05-fragmento-02.md, tipificación gravísima"
cita_textual_de_respaldo: "Art. 25 reproducido, inc. 5 frag. 1: «Se prohíbe el tratamiento masivo de los datos personales contenidos en los registros electrónicos de infracciones»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "infracciones penales; civiles; administrativas; disciplinarias"
caracter: "Condicional"
sancion: "3 Gravísima"
---

## Fundamento textual e interpretación

El fragmento primero del inciso quinto prohíbe el tratamiento masivo de datos en registros públicos electrónicos de infracciones. Quien decide ese tratamiento ocupa el rol de responsable. El fragmento segundo tipifica expresamente el incumplimiento como infracción gravísima y sustenta `3 Gravísima`.

## Alcance de la regla

Abarca registros electrónicos públicos de cualquiera de las cuatro clases. «Masivo» requiere valoración del volumen y método de tratamiento: `Indeterminada`; carácter `Condicional`. La tipificación expresa no incluye aquí multa máxima ni consecuencia accesoria; no se infieren.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 25 reproducido de Ley 19.628, inc. 5, frag. 1: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-25/inciso-05-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 12, art. 25 reproducido de Ley 19.628, inc. 5, frag. 2: [tipificación gravísima](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-12/articulo-reproducido-25/inciso-05-fragmento-02.md).
