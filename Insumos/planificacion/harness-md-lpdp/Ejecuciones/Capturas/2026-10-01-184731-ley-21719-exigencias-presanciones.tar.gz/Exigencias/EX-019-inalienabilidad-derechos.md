---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-019"
enunciado: "No limitar por acto o convención los derechos personales, intransferibles e irrenunciables del titular."
destinatario: "Tercero"
modalidad: "Prohibición"
conducta_exigida: "No limitar por acto o convención los derechos personales, intransferibles e irrenunciables del titular."
condicion_de_aplicacion: "Acto o convención que pretenda limitar los derechos del titular reconocidos por la ley."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 4 reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-04/inciso-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 4 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-04/inciso-01.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md, incorporación"
cita_textual_de_respaldo: "Art. primero, num. 7, art. 4 reproducido de Ley 19.628, inc. 2: «no pueden limitarse por ningún acto o convención»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La Disposición principal dice «no pueden limitarse por ningún acto o convención». La prohibición recae en cualquier sujeto que celebre o aplique un acto o convención; por no designarse un rol especial, se usa Tercero. La naturaleza personal e irrenunciable de los derechos explica el objeto, sin crear fichas duplicadas de cada derecho.

## Alcance de la regla

El alcance exige identificar los derechos reconocidos en esta ley, lo que requiere lectura de sus reglas específicas. No hay plazo expreso; el límite atraviesa todos esos derechos. El estado de determinación es `Indeterminada` y el carácter `Transversal` por el alcance descrito.

## Anclajes y función

- Art. primero, num. 7, art. 4 reproducido de Ley 19.628, inc. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-04/inciso-02.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 4 reproducido de Ley 19.628, inc. 1: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-04/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, instrucción modificatoria: [incorporación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
