---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-166"
enunciado: "El Consejo para la Transparencia debe considerar la opinión de la Agencia y expresarla en la motivación de la instrucción general."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Considerar opinión de la Agencia y explicitarla en motivación de la instrucción general."
condicion_de_aplicacion: "Opinión de Agencia recibida en coordinación regulatoria."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 31 reproducido de Ley 19.628, inc. 4, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-31/inciso-04.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 31 reproducido de Ley 19.628, inc. 4: «El Consejo para la Transparencia considerará el contenido de la opinión de la Agencia expresándolo en la motivación»."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El artículo 31 dispone «El Consejo para la Transparencia considerará el contenido de la opinión de la Agencia expresándolo en la motivación». El sujeto es Consejo para la Transparencia; `Tercero` es la categoría residual cuando se trata del Consejo para la Transparencia. Esta conducta se puede cumplir y comprobar independientemente de las otras posiciones de coordinación regulatoria del artículo.

## Alcance de la regla

Opinión de Agencia recibida en coordinación regulatoria. La obligación respecto de la opinión recibida se fija directamente; la regla por falta de informe es otra rama remitida. El carácter es `Condicional` por ese supuesto. No se expresa plazo para esta conducta.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 31 reproducido de Ley 19.628, inc. 4: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-31/inciso-04.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, instrucción modificatoria: [incorporación del Título VI](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta cotejar el régimen sancionador. La rama por ausencia de informe del art. 31 incs. 3–4 remite al art. 38 inc. 2 de Ley 19.880, cuyo contenido no está disponible como Fuente autorizada; se localiza incompleta en las filas correspondientes y no altera esta obligación con informe recibido.
