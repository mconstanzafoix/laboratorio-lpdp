---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-164"
enunciado: "El Consejo para la Transparencia debe remitir antecedentes y pedir informe a la Agencia antes de una instrucción general con claros efectos en competencia de ésta."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Remitir antecedentes a la Agencia y requerirle informe."
condicion_de_aplicacion: "Consejo debe dictar instrucción general con claros efectos en ámbito de competencia de Agencia."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 31 reproducido de Ley 19.628, inc. 4, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-31/inciso-04.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 31 reproducido de Ley 19.628, inc. 4: «el Consejo para la Transparencia remitirá los antecedentes y requerirá informe a la Agencia»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El artículo 31 dispone «el Consejo para la Transparencia remitirá los antecedentes y requerirá informe a la Agencia». El sujeto es Consejo para la Transparencia; `Tercero` es la categoría residual cuando se trata del Consejo para la Transparencia. Esta conducta se puede cumplir y comprobar independientemente de las otras posiciones de coordinación regulatoria del artículo.

## Alcance de la regla

Consejo debe dictar instrucción general con claros efectos en ámbito de competencia de Agencia. La expresión «claros efectos» exige valoración de las competencias involucradas. El carácter es `Condicional` por ese supuesto. No se expresa plazo para esta conducta.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 31 reproducido de Ley 19.628, inc. 4: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-31/inciso-04.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, instrucción modificatoria: [incorporación del Título VI](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta cotejar el régimen sancionador. La rama por ausencia de informe del art. 31 incs. 3–4 remite al art. 38 inc. 2 de Ley 19.880, cuyo contenido no está disponible como Fuente autorizada; se localiza incompleta en las filas correspondientes y no altera esta obligación con informe recibido.
