---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-011"
enunciado: "Mantener los datos personales exactos, completos, actuales y pertinentes respecto de su procedencia y los fines del tratamiento."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Mantener los datos personales exactos, completos, actuales y pertinentes respecto de su procedencia y los fines del tratamiento."
condicion_de_aplicacion: "Tratamiento de datos personales."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. d, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-d.md, principal; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md, incorporación y contexto de principios; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md, incorporación y contexto de principios"
cita_textual_de_respaldo: "Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. d: «Los datos personales deben ser exactos, completos, actuales y pertinentes»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "exactos; completos; actuales; pertinentes"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El texto principal dice «Los datos personales deben ser exactos, completos, actuales y pertinentes». La letra d impone las cualidades del dato tratado como una sola posición de calidad, no cuatro fichas por cada adjetivo. Su redacción pasiva no identifica un rol especial único.

## Alcance de la regla

La pertinencia y actualidad se aprecian respecto de procedencia y finalidad en el caso concreto. No hay plazo expreso; la regla es transversal. La clasificación de la ficha es `Indeterminada` y el carácter es `Transversal` por las razones anteriores.

## Anclajes y función

- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. d: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-d.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, instrucción modificatoria: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` permanece vacío hasta comprobar el régimen sancionador pertinente de esta Fuente y sus remisiones expresas; no equivale a `0 No tipificada`.
