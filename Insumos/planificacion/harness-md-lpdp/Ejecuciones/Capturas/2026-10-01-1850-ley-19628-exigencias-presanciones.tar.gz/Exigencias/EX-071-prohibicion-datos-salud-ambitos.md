---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-071"
enunciado: "Se prohíbe tratar o ceder datos y muestras de salud o perfil biológico recolectados en ámbitos enumerados, salvo ley expresa en caso calificado."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "Tratar o ceder datos de salud, perfil biológico o muestras asociadas recolectados en los ámbitos enumerados."
condicion_de_aplicacion: "Recolección en ámbito laboral, educativo, deportivo, social, de seguros, de seguridad o identificación, salvo autorización legal expresa para caso calificado referido a alguno de los casos del art. 16 bis."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 bis, inc. 3, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 16 bis, inc. 3: «Se prohíbe el tratamiento y la cesión de los datos relativos a la salud y al perfil biológico»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "ámbito laboral; ámbito educativo; ámbito deportivo; ámbito social; ámbito de seguros; ámbito de seguridad; ámbito de identificación"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso tercero prohíbe tratamiento y cesión de las clases de datos y muestras indicadas cuando fueron recogidos en siete ámbitos. El almacenamiento del material biológico queda comprendido. La salvedad exige autorización legal expresa y relación con los casos del artículo.

## Alcance de la regla

La autorización excepcional debe provenir de ley en caso calificado; la fuente no individualiza aquí leyes aplicables. La calificación de casos y la relación con el artículo requieren valoración. No hay plazo ni delegación expresa a autoridad administrativa. El carácter es `Condicional` por el supuesto expreso. Se registra `Indeterminada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 16 bis, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente. La identificación de las leyes especiales y de autorizaciones aplicables a casos concretos puede modificar el alcance de la excepción; se requiere individualizarlas antes de dar por cerrado ese cotejo.
