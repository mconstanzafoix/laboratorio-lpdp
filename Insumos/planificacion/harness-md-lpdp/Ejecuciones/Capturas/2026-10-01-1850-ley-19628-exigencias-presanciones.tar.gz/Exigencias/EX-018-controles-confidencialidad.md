---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-018"
enunciado: "El responsable debe establecer controles y medidas adecuadas para preservar la confidencialidad de los datos personales."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Establecer controles y medidas adecuadas para preservar el secreto o confidencialidad de los datos personales."
condicion_de_aplicacion: "Tratamiento de datos personales bajo responsabilidad del sujeto."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. h, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-h.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. h: «El responsable establecerá controles y medidas adecuadas para preservar el secreto o confidencialidad»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La segunda frase impone al responsable una conducta de organización y protección distinguible del deber personal de guardar secreto. Su incumplimiento puede apreciarse aunque no se compruebe revelación de datos.

## Alcance de la regla

Los controles y medidas deben preservar el secreto o confidencialidad. Su adecuación requiere valoración según tratamiento y riesgo; no hay plazo cuantificado ni delegación. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. h](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-h.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.
