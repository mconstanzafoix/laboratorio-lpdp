---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-206"
enunciado: "La Corte debe dar preferencia a la vista del reclamo judicial al incluirla en tabla."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Dar preferencia a vista de causa en tabla."
condicion_de_aplicacion: "Autos en relación luego del término probatorio o trámite equivalente."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 43, inc. 01, lit. e, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-e.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 43, inc. 01, lit. e: «gozará de preferencia para su inclusión en la tabla»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Regla de prioridad judicial expresa; el texto no fija plazo numérico para tabla.

## Alcance de la regla

La regla se aplica a: Autos en relación luego del término probatorio o trámite equivalente. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 43, inc. 01, lit. e](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-e.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen negativo o positivo del régimen sancionador de esta Fuente; el campo vacío no significa ausencia de tipificación.
