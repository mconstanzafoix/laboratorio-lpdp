---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-146"
enunciado: "El Consejo para la Transparencia debe evacuar el informe requerido por la Agencia dentro de treinta días corridos desde su recepción."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Evacuar informe solicitado por la Agencia."
condicion_de_aplicacion: "Recepción del requerimiento de la Agencia conforme al inciso primero."
plazo: "treinta días corridos desde recepción"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 31, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-31/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 31, inc. 02: «deberá evacuar el informe solicitado dentro del plazo de treinta días corridos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Consejo es destinatario residual Tercero y el plazo se fija expresamente.

## Alcance de la regla

La regla se aplica a: Recepción del requerimiento de la Agencia conforme al inciso primero. Estado `Determinada`; carácter `Condicional`. Plazo o momento: treinta días corridos desde recepción.

## Anclajes y función

- [Art. 31, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-31/inciso-02.md): principal: regla expresada.

## Límites del análisis

La regla de silencio y prosecución del procedimiento por Ley 19.880 art. 38 inc. 2 no se determina sin esa Fuente; las obligaciones independientes aquí fichadas sí tienen texto suficiente. La calificación de `sancion` queda pendiente.
