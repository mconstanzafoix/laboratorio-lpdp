---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-263"
enunciado: "No puede designarse consejero a personas comprendidas en las cuatro inhabilidades adicionales del artículo 30 quinquies."
destinatario: "Tercero"
modalidad: "Prohibición"
conducta_exigida: "Designar consejero a persona incursa en inhabilidad de letras a–d."
condicion_de_aplicacion: "Condena penal indicada O dependencia de drogas no justificada O sanción grave/gravísima reciente O vínculo empresarial reciente."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 quinquies, inc. 04, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quinquies/inciso-04.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 quinquies, inc. 04: «no podrá ser designado consejero»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "condena penal indicada; dependencia de sustancias no médica; sanción grave o gravísima en cinco años; cargo o propiedad de empresa de datos en último año"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La comprobación de supuestos exige valoración de antecedentes; letras a–d delimitan lista cerrada.

## Alcance de la regla

La regla se aplica a: Condena penal indicada O dependencia de drogas no justificada O sanción grave/gravísima reciente O vínculo empresarial reciente. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 30 quinquies, inc. 04](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quinquies/inciso-04.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
