---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-125"
enunciado: "Los organismos públicos deben mantener accesible al público durante cinco años la información de infracciones civiles, administrativas y disciplinarias publicada por mandato legal sin plazo fijado."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Mantener accesible al público la información de infracciones civiles, administrativas y disciplinarias."
condicion_de_aplicacion: "Ley ordena publicación o registro de sanciones sin fijar duración de disponibilidad."
plazo: "cinco años"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 25, inc. 04, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-25/inciso-04-letra-b.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 25, inc. 04, lit. b: «permanecerán accesibles al público por el período de cinco años»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "civiles; administrativas; disciplinarias"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La letra b fija el período supletorio solo cuando la ley de publicidad no lo haya fijado.

## Alcance de la regla

La regla se aplica a: Ley ordena publicación o registro de sanciones sin fijar duración de disponibilidad. Estado `Determinada`; carácter `Condicional`. Plazo o momento: cinco años.

## Anclajes y función

- [Art. 25, inc. 04, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-25/inciso-04-letra-b.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
