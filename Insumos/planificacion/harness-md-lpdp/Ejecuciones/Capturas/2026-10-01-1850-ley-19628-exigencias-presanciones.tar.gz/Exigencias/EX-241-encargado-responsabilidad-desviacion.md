---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-241"
enunciado: "El encargado que se aparta del objeto o cede sin autorización debe responder personalmente por infracciones y solidariamente con el responsable por daños."
destinatario: "Encargado del tratamiento"
modalidad: "Obligación"
conducta_exigida: "Responder por infracciones propias y daños causados solidariamente."
condicion_de_aplicacion: "Desviación del objeto o cesión/entrega no autorizada; se le considera responsable para efectos legales."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 bis, inc. 02, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-02-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 bis, inc. 02, frag. 02: «debiendo responder personalmente por las infracciones»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "responsabilidad personal por infracciones; solidaridad por daños"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La responsabilidad civil y administrativa resulta de desviación definida por fragmento anterior.

## Alcance de la regla

La regla se aplica a: Desviación del objeto o cesión/entrega no autorizada; se le considera responsable para efectos legales. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 bis, inc. 02, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-02-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
