---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-100"
enunciado: "Quienes tratan datos de la fuente accesible al público deben actualizarlos al recibir noticia del pago o extinción, o dentro de tres días."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Modificar en igual sentido los datos obtenidos de la fuente pública tras noticia de pago o extinción."
condicion_de_aplicacion: "Tratamiento de datos de la fuente accesible al público y comunicación por ésta de pago o extinción."
plazo: "tan pronto se comunique o dentro de tres días siguientes"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 19, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-19/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 19, inc. 03: «deberán modificar los datos en el mismo sentido tan pronto aquélla comunique el pago o la extinción de la obligación, o dentro de los tres días siguientes»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Se identifica al responsable que trata los datos de la fuente pública; la alternativa temporal se conserva como expresa el texto.

## Alcance de la regla

La regla se aplica a: Tratamiento de datos de la fuente accesible al público y comunicación por ésta de pago o extinción. Estado `Determinada`; carácter `Condicional`. Plazo o momento: tan pronto se comunique o dentro de tres días siguientes.

## Anclajes y función

- [Art. 19, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-19/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
