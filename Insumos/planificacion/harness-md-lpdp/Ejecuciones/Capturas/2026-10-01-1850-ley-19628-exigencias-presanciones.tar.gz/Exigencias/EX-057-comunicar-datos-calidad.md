---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-057"
enunciado: "El responsable debe comunicar o ceder datos exactos, completos y actuales conforme a la ley."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Comunicar o ceder únicamente información exacta, completa y actual conforme a la ley."
condicion_de_aplicacion: "Comunicación o cesión de datos personales."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14, inc. 1, lit. c, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14/inciso-01-letra-c.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. d, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-d.md, principio de calidad"
cita_textual_de_respaldo: "Art. 14, inc. 1, lit. c: «Comunicar o ceder, en conformidad a las disposiciones de esta ley, información exacta, completa y actual»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La letra c concreta el principio de calidad en la operación de comunicación o cesión. Es una conducta situacional separable de mantener calidad general durante todo tratamiento.

## Alcance de la regla

Exactitud, completitud y actualidad son acumulativas; conformidad legal de la comunicación o cesión depende de otras reglas de la ley. No hay plazo expreso. El carácter es `Condicional` por el supuesto expreso. Se registra `Indeterminada` por el grado de concreción indicado.

## Anclajes y función

- [Art. 14, inc. 1, lit. c](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14/inciso-01-letra-c.md): principal: regla expresada.
- [Art. 3, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-d.md): principio de calidad.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
