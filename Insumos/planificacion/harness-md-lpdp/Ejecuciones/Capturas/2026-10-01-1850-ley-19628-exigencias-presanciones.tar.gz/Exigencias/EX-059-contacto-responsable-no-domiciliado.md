---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-059"
enunciado: "El responsable sin domicilio en Chile que trata datos de residentes debe señalar un contacto idóneo para titulares y Agencia."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Señalar un correo u otro contacto idóneo para comunicaciones de titulares y Agencia."
condicion_de_aplicacion: "Responsable sin domicilio en Chile que trata datos de personas residentes en Chile."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14/inciso-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 10, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-02.md, regla conexa de persona jurídica no constituida"
cita_textual_de_respaldo: "Art. 14, inc. 2: «deberá señalar y mantener actualizado y operativo, un correo electrónico u otro medio de contacto idóneo»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso segundo impone contacto para responsables sin domicilio en Chile que tratan datos de residentes. Se separa del deber de actualizar y mantener operativo el contacto porque esas conductas continúan tras señalarlo. La regla del art. 10, inc. 2 usa un supuesto subjetivo diferente y se conserva como relacionada.

## Alcance de la regla

El medio puede ser correo u otro contacto idóneo para titular y Agencia. La idoneidad exige valoración; no hay plazo expreso. El carácter es `Condicional` por el supuesto expreso. Se registra `Indeterminada` por el grado de concreción indicado.

## Anclajes y función

- [Art. 14, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14/inciso-02.md): principal: regla expresada.
- [Art. 10, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-02.md): regla conexa de persona jurídica no constituida.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
