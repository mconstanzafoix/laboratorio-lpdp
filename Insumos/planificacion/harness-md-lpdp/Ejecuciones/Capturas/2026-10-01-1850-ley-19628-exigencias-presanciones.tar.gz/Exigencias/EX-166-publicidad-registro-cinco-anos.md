---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-166"
enunciado: "La Agencia debe mantener accesibles al público las anotaciones del registro durante cinco años desde su práctica."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Mantener acceso público a anotaciones registrales."
condicion_de_aplicacion: "Anotación practicada en Registro Nacional de Sanciones y Cumplimiento."
plazo: "cinco años desde anotación"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 39, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-39/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 39, inc. 03: «serán de acceso público por el período de cinco años»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La duración expresa del acceso público no se extiende por inferencia al almacenamiento posterior.

## Alcance de la regla

La regla se aplica a: Anotación practicada en Registro Nacional de Sanciones y Cumplimiento. Estado `Determinada`; carácter `Condicional`. Plazo o momento: cinco años desde anotación.

## Anclajes y función

- [Art. 39, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-39/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
