---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-054"
enunciado: "El responsable debe informar al titular y poner a su disposición antecedentes que acrediten la licitud del tratamiento."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Informar al titular y poner a su disposición antecedentes que acrediten la licitud del tratamiento."
condicion_de_aplicacion: "Tratamiento de datos personales del titular por el responsable."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14, inc. 1, lit. a, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14/inciso-01-letra-a.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. a, párr. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-a-parrafo-02.md, deber de acreditación subyacente"
cita_textual_de_respaldo: "Art. 14, inc. 1, lit. a: «Informar y poner a disposición del titular los antecedentes que acrediten la licitud»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La primera oración exige informar y poner antecedentes a disposición del titular. Es distinta del deber interno de estar en condiciones de acreditar licitud: aquí existe una entrega informativa frente al titular.

## Alcance de la regla

Los antecedentes deben respaldar licitud del tratamiento. No hay plazo cuantificado ni delegación para la puesta a disposición. El carácter es `Transversal` por su aplicación general al tratamiento. Se registra `Determinada` por el grado de concreción indicado.

## Anclajes y función

- [Art. 14, inc. 1, lit. a](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14/inciso-01-letra-a.md): principal: regla expresada.
- [Art. 3, inc. 1, lit. a, párr. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-a-parrafo-02.md): deber de acreditación subyacente.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
