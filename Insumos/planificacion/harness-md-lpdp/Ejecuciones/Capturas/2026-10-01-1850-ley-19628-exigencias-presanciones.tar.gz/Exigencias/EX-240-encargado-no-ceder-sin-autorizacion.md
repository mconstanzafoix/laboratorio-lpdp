---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-240"
enunciado: "El encargado no puede ceder ni entregar datos sin autorización expresa y específica del responsable para cumplir el objeto del encargo."
destinatario: "Encargado del tratamiento"
modalidad: "Prohibición"
conducta_exigida: "Ceder o entregar datos a terceros sin autorización expresa y específica."
condicion_de_aplicacion: "Cesión o entrega por encargado fuera de autorización para objeto del encargo."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 bis, inc. 01, frag. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-01-fragmento-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 bis, inc. 01, frag. 03: «su cesión o entrega en los casos en que el responsable no lo haya autorizado»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La autorización debe ser expresa, específica y vinculada al objeto del encargo.

## Alcance de la regla

La regla se aplica a: Cesión o entrega por encargado fuera de autorización para objeto del encargo. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 bis, inc. 01, frag. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-01-fragmento-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
