---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-209"
enunciado: "El interesado puede reclamar de ilegalidad si transcurren más de seis meses desde la certificación del reclamo sin resolución de la Agencia."
destinatario: "Tercero"
modalidad: "Permiso condicionado"
conducta_exigida: "Presentar reclamo de ilegalidad por demora del procedimiento sancionador."
condicion_de_aplicacion: "Más de seis meses desde certificación del art. 42 letra b sin que Agencia resuelva reclamación."
plazo: "después de más de seis meses desde certificación"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 1, lit. l, frag. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-l-fragmento-02.md, principal: habilitación; Ley 19.628 consolidada desde 01-DIC-2026, Art. 43, inc. 1, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-fragmento-01.md, procedimiento judicial"
cita_textual_de_respaldo: "Art. 42, inc. 1, lit. l, frag. 2: «el interesado podrá presentar un reclamo de ilegalidad»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La letra l permite el reclamo de ilegalidad por demora, con presupuesto temporal distinto del reclamo contra resolución. La persona interesada puede ser titular o responsable, por lo que se usa el destinatario residual `Tercero`.

## Alcance de la regla

Se activa después de más de seis meses desde la certificación de recepción del reclamo sin resolución de Agencia. Carácter `Condicional` y estado `Determinada` porque el supuesto está fijado.

## Anclajes y función

- [Art. 42, inc. 1, lit. l, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-l-fragmento-02.md): habilitación principal.
- [Art. 43, inc. 1, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-fragmento-01.md): procedimiento judicial.

## Límites del análisis

La calificación de `sancion` sigue pendiente; el vacío no implica ausencia de tipificación.
