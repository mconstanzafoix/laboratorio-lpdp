---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-077"
enunciado: "Quienes traten o administren datos de menores deben velar especialmente por su uso lícito y protección."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Velar por uso lícito y protección de datos personales de niños, niñas y adolescentes."
condicion_de_aplicacion: "Establecimiento educacional o persona/entidad pública o privada que trate o administre datos de menores, incluido cuidador personal."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quáter, inc. 6, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-06.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quáter, inc. 5, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-05.md, definiciones etarias con frontera abierta de catorce años"
cita_textual_de_respaldo: "Art. 16 quáter, inc. 6: «velar por el uso lícito y la protección de la información personal»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso sexto atribuye una obligación especial a establecimientos educacionales y a todas las personas o entidades que tratan o administran datos de menores. El valor residual `Tercero` recoge ese sujeto plural explícito, sin excluir deberes propios de responsables cuando actúen como tales.

## Alcance de la regla

Uso lícito y protección de información son estándares abiertos. La condición es tratar o administrar datos de menores. No hay plazo ni delegación. El carácter es `Condicional` por el supuesto de datos de menores. Se registra `Indeterminada` por la valoración y límite señalados.

## Anclajes y función

- [Art. 16 quáter, inc. 6](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-06.md): principal: regla expresada.
- [Art. 16 quáter, inc. 5](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quáter/inciso-05.md): definiciones etarias con frontera abierta de catorce años.

## Límites del análisis

La definición del art. 16 quáter, inc. 5 dice «menores de catorce» y «mayores de catorce»; no clasifica literalmente la edad exactamente catorce. Su aplicación requiere examen humano si ese caso resulta relevante. La calificación de `sancion` queda pendiente del régimen infraccional; el vacío no significa ausencia de tipificación.
