---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-027"
enunciado: "El responsable debe cesar el tratamiento basado en intereses legítimos tras oposición, salvo motivo prevalente o reclamación."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Dejar de tratar los datos personales tras oposición fundada en intereses legítimos, salvo motivo prevalente o reclamación."
condicion_de_aplicacion: "Oposición del titular al tratamiento basado en intereses legítimos Y ausencia de motivos legítimos imperiosos prevalentes o necesidad de reclamación."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 8, inc. 1, lit. a, frag. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08/inciso-01-letra-a-fragmento-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 8, inc. 1, lit. a, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08/inciso-01-letra-a-fragmento-01.md, derecho que activa el cese"
cita_textual_de_respaldo: "Art. 8, inc. 1, lit. a, frag. 2: «El responsable del tratamiento deberá dejar de tratar los datos personales»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El fragmento segundo añade el deber de cesar el tratamiento tras la oposición del titular por intereses legítimos. Puede examinarse separadamente del ejercicio del derecho y conserva las salvedades textuales.

## Alcance de la regla

El responsable puede continuar si acredita motivos legítimos imperiosos que prevalezcan sobre intereses, derechos y libertades del titular, o para formular, ejercer o defender reclamaciones. La prevalencia es abierta; no hay plazo numérico ni delegación. El carácter es `Condicional` por el supuesto de ejercicio o cumplimiento. Se registra `Indeterminada` por las características del texto señaladas.

## Anclajes y función

- [Art. 8, inc. 1, lit. a, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08/inciso-01-letra-a-fragmento-02.md): principal: regla expresada.
- [Art. 8, inc. 1, lit. a, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08/inciso-01-letra-a-fragmento-01.md): derecho que activa el cese.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de los tipos infraccionales de esta Fuente y remisiones pertinentes. El vacío no significa ausencia de tipificación.
