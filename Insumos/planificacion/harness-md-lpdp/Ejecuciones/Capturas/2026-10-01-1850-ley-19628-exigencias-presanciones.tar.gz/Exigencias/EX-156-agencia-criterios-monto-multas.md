---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-156"
enunciado: "La Agencia debe aplicar prudencialmente los ocho criterios enumerados para determinar el monto de las multas."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Aplicar criterios legales para determinar monto de multa."
condicion_de_aplicacion: "Fijación de multa por infracción de esta ley."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 37, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-37/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 37, inc. 01: «la Agencia deberá aplicar prudencialmente los siguientes criterios»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "gravedad de conducta; diligencia; perjuicio y titulares afectados; beneficio económico; datos sensibles o de menores; capacidad económica; sanciones anteriores; atenuantes y agravantes"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La prudencia en ponderar criterios exige valoración; ocho numerales apoyan una sola decisión de cuantía.

## Alcance de la regla

La regla se aplica a: Fijación de multa por infracción de esta ley. Estado `Indeterminada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 37, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-37/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
