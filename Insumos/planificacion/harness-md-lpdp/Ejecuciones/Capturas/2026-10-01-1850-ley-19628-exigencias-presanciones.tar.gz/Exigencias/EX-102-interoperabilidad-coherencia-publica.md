---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-102"
enunciado: "Los organismos públicos deben alcanzar un alto grado de interoperabilidad y coherencia para evitar contradicciones y requerimientos reiterados al titular."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Alcanzar interoperabilidad y coherencia de la información y evitar contradicciones o reiteración de requerimientos."
condicion_de_aplicacion: "Tratamiento de datos personales por organismos públicos."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 21, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-21/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 21, inc. 02: «deben alcanzar un alto grado de interoperabilidad y coherencia»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El deber deriva del principio de coordinación; “alto grado” exige valoración jurídica, sin delegación expresa.

## Alcance de la regla

La regla se aplica a: Tratamiento de datos personales por organismos públicos. Estado `Indeterminada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 21, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-21/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
