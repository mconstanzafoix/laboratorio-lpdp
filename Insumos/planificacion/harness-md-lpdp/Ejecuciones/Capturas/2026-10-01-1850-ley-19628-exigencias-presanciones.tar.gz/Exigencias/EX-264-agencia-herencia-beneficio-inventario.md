---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-264"
enunciado: "La Agencia debe aceptar herencias y legados siempre con beneficio de inventario."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Aceptar herencias o legados con beneficio de inventario."
condicion_de_aplicacion: "Agencia acepta asignación testamentaria."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 32 bis, inc. 01, lit. d, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-32-bis/inciso-01-letra-d-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 32 bis, inc. 01, lit. d, frag. 02: «deberá hacer siempre con beneficio de inventario»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "herencias; legados"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Requisito patrimonial de aceptación, no deber de aceptar toda asignación.

## Alcance de la regla

La regla se aplica a: Agencia acepta asignación testamentaria. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 32 bis, inc. 01, lit. d, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-32-bis/inciso-01-letra-d-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
