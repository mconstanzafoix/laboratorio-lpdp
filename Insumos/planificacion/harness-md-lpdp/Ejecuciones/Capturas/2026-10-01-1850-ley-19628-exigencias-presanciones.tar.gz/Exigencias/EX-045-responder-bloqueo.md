---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-045"
enunciado: "El responsable debe responder al requerimiento de bloqueo dentro de los dos días hábiles siguientes a su recepción."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Responder al requerimiento de bloqueo temporal del titular."
condicion_de_aplicacion: "Recepción de solicitud fundada de bloqueo temporal."
plazo: "dos días hábiles siguientes a la recepción"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 11, inc. 6, frag. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-06-fragmento-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 11, inc. 6, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-06-fragmento-01.md, derecho que activa la respuesta"
cita_textual_de_respaldo: "Art. 11, inc. 6, frag. 2: «el responsable deberá responder al requerimiento dentro de los dos días hábiles»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El fragmento segundo atribuye al responsable la respuesta al bloqueo, separada del plazo general de pronunciarse sobre rectificación, supresión u oposición.

## Alcance de la regla

Debe responder dentro de los dos días hábiles siguientes a la recepción. El texto no dice que sea no prorrogable; no se añade tal calificación. El carácter es `Condicional` por el supuesto expreso. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 11, inc. 6, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-06-fragmento-02.md): principal: regla expresada.
- [Art. 11, inc. 6, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-06-fragmento-01.md): derecho que activa la respuesta.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
