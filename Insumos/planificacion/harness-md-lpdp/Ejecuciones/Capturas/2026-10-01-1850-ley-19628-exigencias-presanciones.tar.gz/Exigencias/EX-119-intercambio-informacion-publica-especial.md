---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-119"
enunciado: "Los órganos públicos y sus autoridades deben intercambiar información y proporcionar datos requeridos para las finalidades de prevención penal, seguridad o emergencia en los términos del artículo 24."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Intercambiar información y proporcionar datos personales requeridos."
condicion_de_aplicacion: "Finalidades de letras a–c; tratamiento para finalidad específica autorizada por ley o, si ello no es posible, requerimiento necesario y proporcional."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 24, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-24/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 24, inc. 03: «estarán obligadas a intercambiar información y proporcionar los datos personales»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "finalidades letras a, b y c"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La necesidad y proporcionalidad del requerimiento cuando no hay autorización específica son conceptos abiertos.

## Alcance de la regla

La regla se aplica a: Finalidades de letras a–c; tratamiento para finalidad específica autorizada por ley o, si ello no es posible, requerimiento necesario y proporcional. Estado `Indeterminada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 24, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-24/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
