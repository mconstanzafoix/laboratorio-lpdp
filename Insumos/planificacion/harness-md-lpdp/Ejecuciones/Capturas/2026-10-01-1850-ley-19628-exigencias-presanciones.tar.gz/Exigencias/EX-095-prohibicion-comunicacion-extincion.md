---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-095"
enunciado: "Los responsables no pueden seguir comunicando datos de una obligación después de su pago o extinción legal."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "Continuar comunicando datos de obligación pagada o legalmente extinguida."
condicion_de_aplicacion: "Pago o extinción por otro modo legal de obligación del artículo 17."
plazo: "desde el pago o extinción"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 18, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-18/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 18, inc. 02: «Tampoco se podrá continuar comunicando los datos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La prohibición opera aunque no hayan transcurrido los cinco años del inciso anterior.

## Alcance de la regla

La regla se aplica a: Pago o extinción por otro modo legal de obligación del artículo 17. Estado `Determinada`; carácter `Condicional`. Plazo o momento: desde el pago o extinción.

## Anclajes y función

- [Art. 18, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-18/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
