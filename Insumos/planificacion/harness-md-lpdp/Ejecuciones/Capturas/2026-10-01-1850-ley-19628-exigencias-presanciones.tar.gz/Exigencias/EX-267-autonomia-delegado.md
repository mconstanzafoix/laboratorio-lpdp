---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-267"
enunciado: "El responsable debe asegurar autonomía del delegado frente a la administración en materias de protección de datos."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Asegurar autonomía del delegado de protección de datos."
condicion_de_aplicacion: "Delegado designado y desempeño de funciones de esta ley."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 50, inc. 03, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-03-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 50, inc. 03, frag. 01: «deberá contar con autonomía respecto de la administración»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La autonomía se atribuye al delegado, pero el responsable que lo designa debe hacerla posible; su suficiencia requiere valoración.

## Alcance de la regla

La regla se aplica a: Delegado designado y desempeño de funciones de esta ley. Estado `Indeterminada`; carácter `Condicional`. No fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 50, inc. 03, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-03-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
