---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-142"
enunciado: "El responsable que transfirió datos internacionalmente debe acreditar ante la Agencia que la transferencia se ajustó a esta ley."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Acreditar ante la Agencia cumplimiento legal de transferencia internacional realizada."
condicion_de_aplicacion: "Responsable efectuó transferencia internacional de datos."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 28, inc. 06, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-06.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 28, inc. 06: «acreditar ante la Agencia que ésta se practicó de conformidad a las reglas establecidas en esta ley»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La suficiencia de la acreditación requiere valoración; el deber corresponde al transmisor que efectuó la operación.

## Alcance de la regla

La regla se aplica a: Responsable efectuó transferencia internacional de datos. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 28, inc. 06](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-06.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
