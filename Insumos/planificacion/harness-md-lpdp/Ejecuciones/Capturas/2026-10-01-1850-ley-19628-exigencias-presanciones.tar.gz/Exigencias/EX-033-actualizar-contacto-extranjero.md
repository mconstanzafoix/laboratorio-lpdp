---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-033"
enunciado: "El responsable persona jurídica no constituida en Chile debe mantener actualizado el contacto electrónico informado a la Agencia."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Mantener actualizada la información de contacto electrónico comunicada ante la Agencia."
condicion_de_aplicacion: "Responsable persona jurídica no constituida en Chile que informa un contacto ante la Agencia."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 10, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 10, inc. 2: «El responsable deberá mantener actualizada esta información.»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La última oración contiene un deber continuo distinto del registro inicial. El pronombre «esta información» remite al correo o medio equivalente señalado en el mismo inciso.

## Alcance de la regla

La actualización acompaña cambios en los datos informados. No se fija cantidad de días ni se delega componente necesario. El carácter es `Condicional` por el supuesto expreso. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 10, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y de sus remisiones pertinentes. El vacío no significa ausencia de tipificación.
