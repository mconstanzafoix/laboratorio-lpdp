---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-137"
enunciado: "La Agencia puede aprobar cláusulas modelo y otros instrumentos para transferencias transfronterizas solo si contienen garantías adecuadas."
destinatario: "Agencia"
modalidad: "Permiso condicionado"
conducta_exigida: "Aprobar cláusulas modelo y otros instrumentos jurídicos para flujo transfronterizo."
condicion_de_aplicacion: "Instrumentos contienen garantías adecuadas del fragmento primero."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 28, inc. 02, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-02-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 28, inc. 02, frag. 02: «podrá aprobar cláusulas modelo y otros instrumentos jurídicos»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La autorización se restringe a instrumentos con garantías adecuadas, estándar jurídico abierto.

## Alcance de la regla

La regla se aplica a: Instrumentos contienen garantías adecuadas del fragmento primero. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 28, inc. 02, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-02-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
