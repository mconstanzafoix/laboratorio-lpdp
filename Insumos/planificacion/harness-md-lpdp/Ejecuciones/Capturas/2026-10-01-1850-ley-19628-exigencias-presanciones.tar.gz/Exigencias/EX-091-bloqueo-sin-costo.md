---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-091"
enunciado: "El Boletín de Informaciones Comerciales debe bloquear los datos sin costo para el deudor."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Efectuar el bloqueo de datos sin cobrar al deudor."
condicion_de_aplicacion: "Bloqueo procedente conforme a los incisos anteriores."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 17, inc. 06, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-17/inciso-06.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 17, inc. 06: «El bloqueo de datos será sin costo para el deudor»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El sujeto que ejecuta el bloqueo se identifica por el contexto del inciso cuarto, aunque la formulación sea impersonal.

## Alcance de la regla

La regla se aplica a: Bloqueo procedente conforme a los incisos anteriores. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 17, inc. 06](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-17/inciso-06.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
