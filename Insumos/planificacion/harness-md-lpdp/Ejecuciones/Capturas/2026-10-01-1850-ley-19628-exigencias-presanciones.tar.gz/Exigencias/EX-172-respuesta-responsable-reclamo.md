---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-172"
enunciado: "El responsable puede responder el reclamo dentro de treinta días corridos, prorrogables por igual plazo, acompañando antecedentes."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Responder reclamación y acompañar antecedentes."
condicion_de_aplicacion: "Notificación del reclamo acogido a tramitación."
plazo: "treinta días corridos, prorrogables hasta por igual plazo"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 41, inc. 02, lit. d, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-41/inciso-02-letra-d-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 41, inc. 02, lit. d, frag. 02: «dispondrá de un plazo de treinta días corridos, prorrogables hasta por el mismo plazo»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La ley concede oportunidad de defensa con plazo expreso; no se infiere prórroga adicional.

## Alcance de la regla

La regla se aplica a: Notificación del reclamo acogido a tramitación. Estado `Determinada`; carácter `Condicional`. Plazo o momento: treinta días corridos, prorrogables hasta por igual plazo.

## Anclajes y función

- [Art. 41, inc. 02, lit. d, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-41/inciso-02-letra-d-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con las tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
