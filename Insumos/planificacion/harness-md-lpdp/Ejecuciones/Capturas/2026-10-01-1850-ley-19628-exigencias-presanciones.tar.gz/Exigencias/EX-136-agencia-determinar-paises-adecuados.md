---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-136"
enunciado: "La Agencia debe determinar fundadamente los países con protección adecuada considerando al menos los criterios del artículo 28."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Determinar fundadamente países con protección adecuada de datos."
condicion_de_aplicacion: "Evaluación de ordenamientos extranjeros según estándar similar o superior y criterios enumerados."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 28, inc. 01, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-01-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 28, inc. 01, frag. 02: «La Agencia determinará fundadamente los países que poseen niveles adecuados»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "principios de tratamiento; derechos y autoridad de tutela; obligaciones de información y seguridad; responsabilidades por infracciones"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Agencia valora estándares comparables y cuatro criterios mínimos; el juicio de adecuación es abierto.

## Alcance de la regla

La regla se aplica a: Evaluación de ordenamientos extranjeros según estándar similar o superior y criterios enumerados. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 28, inc. 01, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-01-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
