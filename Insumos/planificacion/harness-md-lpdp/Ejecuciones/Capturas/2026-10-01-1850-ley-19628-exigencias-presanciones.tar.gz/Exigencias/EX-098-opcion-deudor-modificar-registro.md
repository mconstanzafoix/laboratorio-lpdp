---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-098"
enunciado: "El deudor puede requerir directamente la modificación de la base y liberar al acreedor del aviso cuando éste le entregue constancia suficiente del pago."
destinatario: "Titular"
modalidad: "Permiso condicionado"
conducta_exigida: "Requerir modificación directa de la base y liberar al acreedor de avisar."
condicion_de_aplicacion: "Acreedor entrega constancia suficiente del pago; elección escrita según el fragmento siguiente."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 19, inc. 02, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-19/inciso-02-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 19, inc. 02, frag. 02: «El deudor podrá optar por requerir directamente la modificación»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Es facultad del deudor y excepción condicionada al aviso del acreedor.

## Alcance de la regla

La regla se aplica a: Acreedor entrega constancia suficiente del pago; elección escrita según el fragmento siguiente. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 19, inc. 02, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-19/inciso-02-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
