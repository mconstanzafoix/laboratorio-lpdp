---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-165"
enunciado: "La Agencia debe consignar en el registro a responsables con modelos certificados de prevención de infracciones vigentes."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Registrar responsables con modelos certificados vigentes."
condicion_de_aplicacion: "Modelo certificado de prevención de infracciones adoptado por responsable y vigente."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 39, inc. 02, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-39/inciso-02-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 39, inc. 02, frag. 02: «se deberán consignar los responsables que adopten modelos certificados»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Es otro supuesto de asiento registral, distinto de la sanción.

## Alcance de la regla

La regla se aplica a: Modelo certificado de prevención de infracciones adoptado por responsable y vigente. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 39, inc. 02, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-39/inciso-02-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
