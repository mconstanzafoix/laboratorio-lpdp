---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-060"
enunciado: "Ese responsable debe mantener actualizado y operativo el contacto señalado para titulares y Agencia."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Mantener actualizado y operativo el contacto para titulares y Agencia."
condicion_de_aplicacion: "Responsable sin domicilio en Chile que trata datos de personas residentes en Chile y ha señalado contacto."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14/inciso-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 10, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-02.md, regla conexa de actualización"
cita_textual_de_respaldo: "Art. 14, inc. 2: «mantener actualizado y operativo, un correo electrónico u otro medio de contacto idóneo»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Mantener actualizado y operativo es una conducta continua distinta de señalar el medio por primera vez. La coincidencia con el art. 10, inc. 2 se somete a revisión transversal por sus diferentes condiciones de aplicación.

## Alcance de la regla

La vigencia y operatividad del contacto deben mantenerse mientras proceda el tratamiento y la comunicación. La idoneidad del medio exige valoración; no hay plazo numérico. El carácter es `Condicional` por el supuesto expreso. Se registra `Indeterminada` por el grado de concreción indicado.

## Anclajes y función

- [Art. 14, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14/inciso-02.md): principal: regla expresada.
- [Art. 10, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-02.md): regla conexa de actualización.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
