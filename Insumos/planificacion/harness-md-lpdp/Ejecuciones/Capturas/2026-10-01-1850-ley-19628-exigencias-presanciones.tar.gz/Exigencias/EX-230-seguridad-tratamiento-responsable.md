---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-230"
enunciado: "El responsable debe aplicar seguridad proporcional al riesgo que asegure confidencialidad, integridad, disponibilidad y resiliencia, y evite alteración, pérdida o acceso no autorizado."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Adoptar medidas de seguridad para tratamiento y sistemas."
condicion_de_aplicacion: "Tratamiento de datos con riesgos valorados según técnica, costos, naturaleza, alcance, contexto, fines y gravedad."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14 quinquies, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quinquies/inciso-01.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 14 septies, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-septies/inciso-02.md, delegación de estándares mínimos a Agencia"
cita_textual_de_respaldo: "Art. 14 quinquies, inc. 01: «debe adoptar las medidas necesarias para resguardar el cumplimiento del principio de seguridad»"
estado_de_determinacion: "Delegada"
enumeracion_contenida: "confidencialidad; integridad; disponibilidad; resiliencia; evitar alteración, destrucción, pérdida, tratamiento o acceso no autorizado"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El deber operacional desarrolla el principio de EX-012. Los estándares mínimos diferenciados de cumplimiento se determinarán por instrucción general de la Agencia, según art. 14 septies inc. 2.

## Alcance de la regla

La regla se aplica a: Tratamiento de datos con riesgos valorados según técnica, costos, naturaleza, alcance, contexto, fines y gravedad. Estado `Delegada`; carácter `Transversal`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 14 quinquies, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quinquies/inciso-01.md): principal: regla expresada.
- [Art. 14 septies, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-septies/inciso-02.md): delegación de estándares mínimos.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliar el art. 34 ter letra j y demás tipificaciones; el campo vacío no implica ausencia de tipificación.
