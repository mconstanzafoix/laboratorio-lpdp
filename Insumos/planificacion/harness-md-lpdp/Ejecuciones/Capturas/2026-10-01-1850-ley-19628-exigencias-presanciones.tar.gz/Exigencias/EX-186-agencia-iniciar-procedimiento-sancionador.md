---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-186"
enunciado: "La Agencia puede iniciar procedimiento sancionador de oficio o a petición de parte tras fiscalización o reclamo del titular."
destinatario: "Agencia"
modalidad: "Permiso condicionado"
conducta_exigida: "Iniciar procedimiento sancionador."
condicion_de_aplicacion: "Resultado de fiscalización o reclamación del titular conforme a arts. 23 y 41; iniciativa de oficio o a petición."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 01, lit. b, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-b-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 42, inc. 01, lit. b, frag. 01: «podrá iniciar un procedimiento sancionatorio»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "de oficio; a petición de parte"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La letra define vías de inicio y antecedentes habilitantes.

## Alcance de la regla

La regla se aplica a: Resultado de fiscalización o reclamación del titular conforme a arts. 23 y 41; iniciativa de oficio o a petición. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 42, inc. 01, lit. b, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-b-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
