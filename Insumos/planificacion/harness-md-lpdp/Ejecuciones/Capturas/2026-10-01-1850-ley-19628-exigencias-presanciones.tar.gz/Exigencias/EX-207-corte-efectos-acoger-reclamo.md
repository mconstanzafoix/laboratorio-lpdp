---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-207"
enunciado: "Si acoge el reclamo, la Corte debe decidir el agravio y ordenar rectificación del acto y resolución correspondiente cuando proceda."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Decidir agravio y ordenar medidas de rectificación/resolución."
condicion_de_aplicacion: "Corte da lugar al reclamo de ilegalidad."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 43, inc. 01, lit. f, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-f.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 43, inc. 01, lit. f: «Si la Corte da lugar al reclamo, en su sentencia decidirá si existió agravio»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La procedencia de cada orden requiere valoración judicial; las consecuencias se condicionan a acoger reclamo.

## Alcance de la regla

La regla se aplica a: Corte da lugar al reclamo de ilegalidad. Estado `Indeterminada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 43, inc. 01, lit. f](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-f.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen negativo o positivo del régimen sancionador de esta Fuente; el campo vacío no significa ausencia de tipificación.
