---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-140"
enunciado: "El responsable transmisor asume responsabilidad por infracciones de miembros del grupo a estándares y políticas corporativas vinculantes."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Asumir responsabilidad por infracciones de miembros del grupo a normas corporativas vinculantes."
condicion_de_aplicacion: "Transferencia intragrupo bajo normas corporativas vinculantes; excepción de exoneración del fragmento tercero."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 28, inc. 04, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-04-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 28, inc. 04, frag. 02: «asumirá la responsabilidad por cualquier infracción a los estándares y políticas corporativas vinculantes»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La regla imputa al transmisor las infracciones del grupo, con posibilidad de exoneración si acredita falta de imputabilidad del miembro.

## Alcance de la regla

La regla se aplica a: Transferencia intragrupo bajo normas corporativas vinculantes; excepción de exoneración del fragmento tercero. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 28, inc. 04, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-04-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
