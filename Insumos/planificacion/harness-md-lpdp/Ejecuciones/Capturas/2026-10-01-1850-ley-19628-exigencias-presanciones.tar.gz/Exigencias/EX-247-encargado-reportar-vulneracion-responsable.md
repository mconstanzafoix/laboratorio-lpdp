---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-247"
enunciado: "El encargado debe reportar al responsable toda vulneración de las medidas de seguridad del tratamiento encomendado."
destinatario: "Encargado del tratamiento"
modalidad: "Obligación"
conducta_exigida: "Reportar vulneración de seguridad al responsable."
condicion_de_aplicacion: "Vulneración de medidas de seguridad en tratamiento por tercero mandatario."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 bis, inc. 04, frag. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-04-fragmento-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 bis, inc. 04, frag. 03: «deberá reportar este hecho al responsable»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El reporte al responsable es distinto del reporte del responsable a Agencia del art. 14 sexies.

## Alcance de la regla

La regla se aplica a: Vulneración de medidas de seguridad en tratamiento por tercero mandatario. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 bis, inc. 04, frag. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-04-fragmento-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
