---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-249"
enunciado: "El responsable debe realizar antes del tratamiento una evaluación de impacto cuando sea probable un alto riesgo para derechos de titulares, y siempre en los cuatro casos del inciso segundo."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Realizar evaluación de impacto de protección de datos."
condicion_de_aplicacion: "Probable alto riesgo por naturaleza, alcance, contexto, tecnología o fines O cualquiera de cuatro casos obligatorios."
plazo: "antes del inicio de operaciones"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-01.md, principal: regla general; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02.md, casos siempre exigidos; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 2, lit. a, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02-letra-a.md, supuesto expreso; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 2, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02-letra-b.md, supuesto expreso; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 2, lit. c, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02-letra-c.md, supuesto expreso; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 2, lit. d, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02-letra-d.md, supuesto expreso; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 3, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-03.md, orientaciones mínimas de Agencia"
cita_textual_de_respaldo: "Art. 15 ter, inc. 01: «deberá realizar, previo al inicio de las operaciones del tratamiento, una evaluación del impacto»"
estado_de_determinacion: "Delegada"
enumeracion_contenida: "evaluación sistemática y exhaustiva de aspectos personales basada en tratamiento o decisiones automatizadas, con efectos jurídicos significativos; tratamiento masivo de datos o a gran escala; observación o monitoreo sistemático de zona de acceso público; tratamiento de datos sensibles y especialmente protegidos en hipótesis de excepción del consentimiento"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso primero exige evaluación previa cuando el tratamiento pueda producir alto riesgo para los derechos de los titulares. El inciso segundo añade cuatro casos en que la evaluación se requiere siempre, sin nueva evaluación de probabilidad. El alto riesgo requiere valoración; la Agencia establece orientaciones mínimas de contenido según inciso tercero, delegando componente metodológico.

## Alcance de la regla

La regla se aplica si hay probable alto riesgo por naturaleza, alcance, contexto, tecnología o fines O si concurre cualquiera de las cuatro clases literales del inciso segundo: evaluación sistemática y exhaustiva basada en tratamiento o decisiones automatizadas con efectos jurídicos significativos; tratamiento masivo o a gran escala; observación o monitoreo sistemático de zona de acceso público; tratamiento de datos sensibles y especialmente protegidos en hipótesis de excepción del consentimiento. Es `Condicional` por esos supuestos. La metodología queda `Delegada` a las orientaciones mínimas de la Agencia; la evaluación debe hacerse antes del inicio de operaciones.

## Anclajes y función

- [Art. 15 ter, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-01.md): principal: regla expresada.
- [Art. 15 ter, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02.md): establece que la evaluación siempre se requiere en los casos siguientes.
- [Art. 15 ter, inc. 2, lit. a](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02-letra-a.md): supuesto obligatorio a.
- [Art. 15 ter, inc. 2, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02-letra-b.md): supuesto obligatorio b.
- [Art. 15 ter, inc. 2, lit. c](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02-letra-c.md): supuesto obligatorio c.
- [Art. 15 ter, inc. 2, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-02-letra-d.md): supuesto obligatorio d.
- [Art. 15 ter, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-03.md): delegación de orientaciones mínimas a Agencia.

## Límites del análisis

El vínculo sancionador con art. 34 quáter letra k y demás tipos requiere conciliación individual; `sancion` permanece vacío sin implicar ausencia.
