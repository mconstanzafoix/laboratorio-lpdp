---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-032"
enunciado: "El responsable persona jurídica no constituida en Chile debe informar ante la Agencia un contacto electrónico operativo que actúe en su nombre."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Señalar por escrito ante la Agencia un correo o medio electrónico válido y operativo de una persona capaz de actuar en su nombre."
condicion_de_aplicacion: "Responsable persona jurídica no constituida en Chile."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 10, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 10, inc. 2: «el responsable deberá señalar por escrito, ante la Agencia, un correo electrónico»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El primer enunciado impone una designación de contacto para ejercicio de derechos, comunicaciones y notificaciones. Se separa de la obligación posterior de mantener la información actualizada, que puede incumplirse después de un registro correcto.

## Alcance de la regla

El contacto puede ser persona natural o jurídica y el medio debe ser válido y operativo. No se fija plazo inicial ni delegación. El carácter es `Condicional` por el supuesto expreso. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 10, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y de sus remisiones pertinentes. El vacío no significa ausencia de tipificación.
