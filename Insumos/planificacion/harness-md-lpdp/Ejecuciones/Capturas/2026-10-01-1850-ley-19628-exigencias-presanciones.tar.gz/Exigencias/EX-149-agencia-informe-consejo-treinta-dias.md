---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-149"
enunciado: "La Agencia debe evacuar el informe requerido por el Consejo para la Transparencia dentro de treinta días corridos desde recepción."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Evacuar informe requerido por el Consejo."
condicion_de_aplicacion: "Recepción del requerimiento recíproco del Consejo para la Transparencia."
plazo: "treinta días corridos desde recepción"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 31, inc. 04, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-31/inciso-04.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 31, inc. 04: «la cual deberá evacuarlo en el plazo de treinta días corridos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Obligación temporal de la Agencia en coordinación recíproca.

## Alcance de la regla

La regla se aplica a: Recepción del requerimiento recíproco del Consejo para la Transparencia. Estado `Determinada`; carácter `Condicional`. Plazo o momento: treinta días corridos desde recepción.

## Anclajes y función

- [Art. 31, inc. 04](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-31/inciso-04.md): principal: regla expresada.

## Límites del análisis

La regla de silencio y prosecución del procedimiento por Ley 19.880 art. 38 inc. 2 no se determina sin esa Fuente; las obligaciones independientes aquí fichadas sí tienen texto suficiente. La calificación de `sancion` queda pendiente.
