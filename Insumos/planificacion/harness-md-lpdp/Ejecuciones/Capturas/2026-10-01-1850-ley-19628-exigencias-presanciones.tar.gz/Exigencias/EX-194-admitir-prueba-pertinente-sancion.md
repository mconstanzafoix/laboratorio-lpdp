---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-194"
enunciado: "La Agencia debe admitir medidas probatorias pertinentes y necesarias solicitadas por el responsable y fundar su rechazo."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Dar lugar a pruebas pertinentes y necesarias o fundar rechazo."
condicion_de_aplicacion: "Solicitud probatoria del responsable en descargos."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 01, lit. g, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-g.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 42, inc. 01, lit. g: «dará lugar a las medidas o diligencias probatorias»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Pertinencia y necesidad requieren valoración; la motivación de rechazo es parte del mismo control.

## Alcance de la regla

La regla se aplica a: Solicitud probatoria del responsable en descargos. Estado `Indeterminada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 42, inc. 01, lit. g](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-g.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
