---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-261"
enunciado: "El Consejo Directivo debe celebrar la sesión requerida dentro de dos días hábiles desde el requerimiento."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Celebrar sesión extraordinaria requerida."
condicion_de_aplicacion: "Requerimiento escrito de dos consejeros."
plazo: "dos días hábiles siguientes al requerimiento"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 quáter, inc. 08, frag. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-08-fragmento-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 quáter, inc. 08, frag. 03: «debiendo la respectiva sesión tener lugar dentro de los dos días hábiles»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El límite temporal de realización es distinto del deber del presidente de citar.

## Alcance de la regla

La regla se aplica a: Requerimiento escrito de dos consejeros. Estado `Determinada`; carácter `Condicional`. Plazo o momento: dos días hábiles siguientes al requerimiento.

## Anclajes y función

- [Art. 30 quáter, inc. 08, frag. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-08-fragmento-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
