---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-234"
enunciado: "El responsable debe registrar sus comunicaciones de vulneraciones, describiendo naturaleza, efectos, categorías, titulares aproximados y medidas adoptadas."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Registrar comunicaciones de incidentes y sus elementos mínimos."
condicion_de_aplicacion: "Comunicación de vulneración de seguridad del inciso primero."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14 sexies, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-sexies/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 14 sexies, inc. 02: «deberá registrar estas comunicaciones»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "naturaleza; efectos; categorías de datos; número aproximado de titulares; medidas de gestión y prevención"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Un solo registro por comunicación con elementos enumerados.

## Alcance de la regla

La regla se aplica a: Comunicación de vulneración de seguridad del inciso primero. Estado `Determinada`; carácter `Condicional`. Plazo o momento: no cuantificado por esta disposición.

## Anclajes y función

- [Art. 14 sexies, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-sexies/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
