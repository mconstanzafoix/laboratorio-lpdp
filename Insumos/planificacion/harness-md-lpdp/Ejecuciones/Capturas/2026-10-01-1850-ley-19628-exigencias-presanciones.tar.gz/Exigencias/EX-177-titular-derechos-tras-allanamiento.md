---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-177"
enunciado: "El titular puede hacer valer sus derechos dentro de diez días después de ser notificado del allanamiento."
destinatario: "Titular"
modalidad: "Derecho del titular"
conducta_exigida: "Hacer valer derechos tras notificación de allanamiento."
condicion_de_aplicacion: "Titular notificado del allanamiento verificado."
plazo: "diez días; tipo de días no determinado"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 41, inc. 02, lit. f, frag. 03, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-41/inciso-02-letra-f-fragmento-03-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 41, inc. 02, lit. f, frag. 03, frag. 02: «tendrá diez días para hacer valer sus derechos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El texto no adjetiva los días como hábiles o corridos; se deja indeterminado su tipo.

## Alcance de la regla

La regla se aplica a: Titular notificado del allanamiento verificado. Estado `Determinada`; carácter `Condicional`. Plazo o momento: diez días; tipo de días no determinado.

## Anclajes y función

- [Art. 41, inc. 02, lit. f, frag. 03, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-41/inciso-02-letra-f-fragmento-03-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con las tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
