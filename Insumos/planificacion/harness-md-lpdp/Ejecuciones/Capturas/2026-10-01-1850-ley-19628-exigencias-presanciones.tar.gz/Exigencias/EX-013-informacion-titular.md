---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-013"
enunciado: "El responsable debe entregar al titular la información necesaria para ejercer sus derechos."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Entregar al titular la información necesaria para ejercer sus derechos, incluidas políticas y prácticas de tratamiento."
condicion_de_aplicacion: "Tratamiento de datos personales y ejercicio de derechos del titular."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. g, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-g.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. g: «El responsable debe entregar al titular toda la información que sea necesaria para el ejercicio de los derechos»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La primera oración de la letra g impone entrega de información al titular. La accesibilidad permanente de políticas y prácticas a cualquier interesado, contenida en la oración siguiente, constituye una posición adicional.

## Alcance de la regla

La información debe permitir el ejercicio de los derechos legales e incluir las políticas y prácticas. La necesidad informativa exige valoración; no se fija plazo cuantificado ni delegación. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. g](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-g.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.
