---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-238"
enunciado: "El encargado debe tratar datos conforme al encargo y a las instrucciones del responsable."
destinatario: "Encargado del tratamiento"
modalidad: "Obligación"
conducta_exigida: "Tratar datos de acuerdo al encargo y las instrucciones recibidas."
condicion_de_aplicacion: "Tratamiento por tercero mandatario o encargado del responsable."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 bis, inc. 01, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-01-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 bis, inc. 01, frag. 02: «realiza el tratamiento de datos personales conforme al encargo y a las instrucciones»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El texto subordina el tratamiento del encargado a instrucciones del responsable.

## Alcance de la regla

La regla se aplica a: Tratamiento por tercero mandatario o encargado del responsable. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 bis, inc. 01, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-01-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
