---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-180"
enunciado: "La Agencia puede convocar a las partes a audiencia e instarlas a alcanzar un acuerdo."
destinatario: "Agencia"
modalidad: "Permiso condicionado"
conducta_exigida: "Convocar audiencia e instar acuerdo."
condicion_de_aplicacion: "Procedimiento de tutela de derechos en curso."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 41, inc. 02, lit. g, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-41/inciso-02-letra-g-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 41, inc. 02, lit. g, frag. 02: «Podrá convocar a las partes a una audiencia e instarlas a alcanzar un acuerdo»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Ambas acciones integran una facultad de conciliación.

## Alcance de la regla

La regla se aplica a: Procedimiento de tutela de derechos en curso. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 41, inc. 02, lit. g, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-41/inciso-02-letra-g-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con las tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
