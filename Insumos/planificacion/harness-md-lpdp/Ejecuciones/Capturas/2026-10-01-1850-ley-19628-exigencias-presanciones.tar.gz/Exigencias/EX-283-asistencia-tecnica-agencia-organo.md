---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-283"
enunciado: "Autoridades de órganos internos pueden solicitar asistencia técnica de la Agencia para dictar políticas y estándares de datos."
destinatario: "Tercero"
modalidad: "Permiso condicionado"
conducta_exigida: "Requerir asistencia técnica de Agencia."
condicion_de_aplicacion: "Diseño de políticas e instrucciones internas del inciso anterior."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 54, inc. 02, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-54/inciso-02-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 54, inc. 02, frag. 02: «pudiendo requerir para ello la asistencia técnica de la Agencia»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La consulta técnica es facultativa y referida al cumplimiento interno.

## Alcance de la regla

La regla se aplica a: Diseño de políticas e instrucciones internas del inciso anterior. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 54, inc. 02, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-54/inciso-02-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
