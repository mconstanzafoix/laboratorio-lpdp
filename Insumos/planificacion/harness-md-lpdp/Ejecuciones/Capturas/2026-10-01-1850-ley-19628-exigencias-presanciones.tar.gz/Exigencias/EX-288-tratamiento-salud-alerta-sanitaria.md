---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-288"
enunciado: "Permite tratar sin consentimiento datos de salud o perfil biológico en casos de alerta sanitaria legalmente decretada."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Tratamiento sin consentimiento de datos de salud o perfil biológico en caso de alerta sanitaria."
condicion_de_aplicacion: "Alerta sanitaria legalmente decretada."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 bis, inc. 2, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02-letra-b.md, principal: supuesto autónomo; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 bis, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02.md, permiso marco; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 bis, inc. 4, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-04.md, extensión a datos no especiales"
cita_textual_de_respaldo: "Art. 16 bis, inc. 2, lit. b: «En casos de alerta sanitaria legalmente decretada»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El permiso marco del art. 16 bis inc. 2 dice «Sólo se podrán tratar» datos sensibles de salud o perfil biológico sin consentimiento en los casos enumerados. Art. 16 bis, inc. 2, lit. b define este supuesto autónomo. El destinatario operativo es el responsable que realiza el tratamiento. La letra f constituye otra alternativa y su ley habilitante no es condición de las letras a a e.

## Alcance de la regla

Se activa por: Alerta sanitaria legalmente decretada. La existencia del decreto de alerta es un hecho de aplicación; el texto fija la condición sin delegar el contenido normativo de este permiso. El permiso sigue sujeto a los principios y reglas de la ley; el inc. 4 extiende estas excepciones al tratamiento de datos que no revisten el carácter especial del precepto. No hay plazo numérico para ejercer este permiso. Es `Condicional` por su supuesto de aplicación y `Determinada` por los elementos señalados.

## Anclajes y función

- [Art. 16 bis, inc. 2, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02-letra-b.md): anclaje principal y supuesto autónomo.
- [Art. 16 bis, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-02.md): marco de tratamiento sin consentimiento sujeto a principios y reglas.
- [Art. 16 bis, inc. 4](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-bis/inciso-04.md): extensión a datos que no revisten carácter especial.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen tipificador. El campo vacío no implica ausencia de tipificación. La remisión legal de la letra f no determina este supuesto alternativo.
