---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-034"
enunciado: "El responsable debe implementar mecanismos tecnológicos sencillos para el ejercicio expedito y eficaz de los derechos del titular."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Implementar mecanismos y herramientas tecnológicas sencillos que permitan ejercer derechos de modo expedito, ágil y eficaz."
condicion_de_aplicacion: "Tratamiento de datos por un responsable y ejercicio de derechos del titular."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 10, inc. 3, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 10, inc. 3: «deberán implementar mecanismos y herramientas tecnológicas»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

Ambas oraciones del inciso describen una misma infraestructura de ejercicio de derechos: mecanismos tecnológicos y sencillez operativa. Separarlas crearía una segunda ficha sobre el mismo medio.

## Alcance de la regla

Los medios deben permitir ejercicio expedito, ágil y eficaz y ser sencillos. Esos estándares abiertos exigen valoración. No hay plazo expreso ni delegación. El carácter es `Transversal` por su función general. Se registra `Indeterminada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 10, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-10/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y de sus remisiones pertinentes. El vacío no significa ausencia de tipificación.
