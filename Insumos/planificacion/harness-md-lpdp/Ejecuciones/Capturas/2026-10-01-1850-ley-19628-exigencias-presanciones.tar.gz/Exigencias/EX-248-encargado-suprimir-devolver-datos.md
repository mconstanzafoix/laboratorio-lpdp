---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-248"
enunciado: "Al concluir el servicio, el encargado debe suprimir o devolver al responsable los datos que mantiene, según corresponda."
destinatario: "Encargado del tratamiento"
modalidad: "Obligación"
conducta_exigida: "Suprimir o devolver datos al responsable."
condicion_de_aplicacion: "Prestación del servicio de tratamiento cumplida."
plazo: "al cumplir prestación del servicio"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 bis, inc. 05, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-05.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 bis, inc. 05: «deben ser suprimidos o devueltos al responsable de datos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "supresión; devolución"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El texto da dos alternativas de cierre al terminar el servicio.

## Alcance de la regla

La regla se aplica a: Prestación del servicio de tratamiento cumplida. Estado `Determinada`; carácter `Condicional`. Plazo o momento: al cumplir prestación del servicio.

## Anclajes y función

- [Art. 15 bis, inc. 05](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-05.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
