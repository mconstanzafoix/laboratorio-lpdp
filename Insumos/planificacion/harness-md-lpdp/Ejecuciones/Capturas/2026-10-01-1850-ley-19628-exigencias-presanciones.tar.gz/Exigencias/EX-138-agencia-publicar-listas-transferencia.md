---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-138"
enunciado: "La Agencia debe poner en su sitio web una lista de países adecuados y modelos de cláusulas y otros instrumentos para transferencia internacional."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Publicar en página web lista de países adecuados y modelos de instrumentos jurídicos."
condicion_de_aplicacion: "Existencia de determinaciones de países y modelos de transferencia."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 28, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 28, inc. 03: «pondrá en su página web a disposición de los interesados un listado de países adecuados»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "países adecuados; cláusulas contractuales tipo; otros instrumentos jurídicos"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Agencia hace accesibles los resultados de sus determinaciones y modelos; el texto no fija periodicidad.

## Alcance de la regla

La regla se aplica a: Existencia de determinaciones de países y modelos de transferencia. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 28, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-28/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
