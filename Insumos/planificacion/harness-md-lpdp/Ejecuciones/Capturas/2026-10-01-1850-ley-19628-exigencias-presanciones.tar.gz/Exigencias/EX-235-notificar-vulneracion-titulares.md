---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-235"
enunciado: "El responsable debe notificar a cada titular, o publicar aviso nacional si ello no es posible, las vulneraciones de datos sensibles, de menores de catorce o de obligaciones económicas."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Comunicar vulneración a titulares afectados con información clara, datos, consecuencias y medidas."
condicion_de_aplicacion: "Vulneración de datos sensibles O de niños menores de catorce O de obligaciones económicas; notificación individual salvo imposibilidad."
plazo: "sin plazo numérico expreso en este inciso"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14 sexies, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-sexies/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 14 sexies, inc. 03: «deberá también efectuar esta comunicación a los titulares de estos datos»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "datos afectados; consecuencias posibles; medidas de solución o resguardo"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La imposibilidad de notificación individual habilita aviso masivo nacional; claridad y suficiencia requieren valoración.

## Alcance de la regla

La regla se aplica a: Vulneración de datos sensibles O de niños menores de catorce O de obligaciones económicas; notificación individual salvo imposibilidad. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: sin plazo numérico expreso en este inciso.

## Anclajes y función

- [Art. 14 sexies, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-sexies/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
