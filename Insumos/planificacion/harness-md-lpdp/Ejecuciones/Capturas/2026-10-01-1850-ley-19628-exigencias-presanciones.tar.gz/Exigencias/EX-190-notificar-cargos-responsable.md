---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-190"
enunciado: "La Agencia debe notificar los cargos al responsable en domicilio postal o medio electrónico indicado según artículo 14 ter letra c."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Notificar formulación de cargos al responsable."
condicion_de_aplicacion: "Cargos formulados contra responsable."
plazo: "tras formulación; término no numérico"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 01, lit. d, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-d.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 42, inc. 01, lit. d: «La formulación de cargos debe notificarse al responsable de datos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "domicilio postal; dirección de correo electrónico; otro medio equivalente"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La notificación activa plazo de descargos y usa medios de contacto de art. 14 ter.

## Alcance de la regla

La regla se aplica a: Cargos formulados contra responsable. Estado `Determinada`; carácter `Condicional`. Plazo o momento: tras formulación; término no numérico.

## Anclajes y función

- [Art. 42, inc. 01, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-d.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
