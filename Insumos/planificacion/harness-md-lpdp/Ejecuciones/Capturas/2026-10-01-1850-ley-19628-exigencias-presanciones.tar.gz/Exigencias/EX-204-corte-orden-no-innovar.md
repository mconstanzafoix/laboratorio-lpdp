---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-204"
enunciado: "La Corte puede decretar orden de no innovar si ejecutar el acto impugnado causaría daño irreparable al recurrente."
destinatario: "Tercero"
modalidad: "Permiso condicionado"
conducta_exigida: "Decretar orden de no innovar."
condicion_de_aplicacion: "Ejecución del acto impugnado produce daño irreparable al recurrente."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 43, inc. 01, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-b.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 43, inc. 01, lit. b: «podrá decretar orden de no innovar»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Daño irreparable es condición valorativa de medida judicial cautelar.

## Alcance de la regla

La regla se aplica a: Ejecución del acto impugnado produce daño irreparable al recurrente. Estado `Indeterminada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 43, inc. 01, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-b.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen negativo o positivo del régimen sancionador de esta Fuente; el campo vacío no significa ausencia de tipificación.
