---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-239"
enunciado: "El encargado no puede tratar datos para un objeto distinto del convenido con el responsable."
destinatario: "Encargado del tratamiento"
modalidad: "Prohibición"
conducta_exigida: "Tratar datos para objeto distinto del encargo."
condicion_de_aplicacion: "Tratamiento por encargado bajo convenio con responsable."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 bis, inc. 01, frag. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-01-fragmento-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 bis, inc. 01, frag. 03: «prohibido su tratamiento para un objeto distinto del convenido»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Es límite de finalidad del encargo, distinto de la prohibición de ceder sin autorización.

## Alcance de la regla

La regla se aplica a: Tratamiento por encargado bajo convenio con responsable. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 bis, inc. 01, frag. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-01-fragmento-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
