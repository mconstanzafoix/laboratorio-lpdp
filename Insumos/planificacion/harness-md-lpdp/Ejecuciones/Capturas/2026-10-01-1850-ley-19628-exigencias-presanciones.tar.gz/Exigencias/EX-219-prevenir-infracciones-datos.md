---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-219"
enunciado: "Los responsables deben adoptar acciones para prevenir infracciones leves, graves y gravísimas de los artículos 34 bis, ter y quáter."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Adoptar acciones de prevención de infracciones."
condicion_de_aplicacion: "Operaciones de tratamiento de responsable público o privado."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 48, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-48/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 48, inc. 01: «deberán adoptar acciones destinadas a prevenir la comisión de las infracciones»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "infracciones art. 34 bis; art. 34 ter; art. 34 quáter"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La idoneidad de acciones preventivas depende de riesgos del tratamiento; deber atraviesa regímenes público y privado.

## Alcance de la regla

La regla se aplica a: Operaciones de tratamiento de responsable público o privado. Estado `Indeterminada`; carácter `Transversal`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 48, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-48/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con el régimen de esta Fuente; el campo vacío no significa ausencia de tipificación.
