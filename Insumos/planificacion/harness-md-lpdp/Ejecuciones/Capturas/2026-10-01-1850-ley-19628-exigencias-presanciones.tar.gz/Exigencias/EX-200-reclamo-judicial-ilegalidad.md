---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-200"
enunciado: "La persona interesada puede reclamar ante la Corte de Apelaciones de Santiago o la de su domicilio contra acto paralizante o resolución final de la Agencia que estime ilegal."
destinatario: "Tercero"
modalidad: "Permiso condicionado"
conducta_exigida: "Deducir reclamo judicial de ilegalidad contra acto o resolución de Agencia."
condicion_de_aplicacion: "Persona natural o jurídica interesada estima ilegal acto que paraliza procedimiento o resolución final/de término."
plazo: "dentro de quince días hábiles del fragmento siguiente"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 43, inc. 01, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 43, inc. 01, frag. 01: «podrán deducir un reclamo de ilegalidad ante la Corte de Apelaciones de Santiago»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "Corte de Santiago; Corte del domicilio del reclamante"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La persona interesada puede ser titular, responsable u otra persona jurídica; se usa Tercero residual para el conjunto. Ilegalidad requiere valoración.

## Alcance de la regla

La regla se aplica a: Persona natural o jurídica interesada estima ilegal acto que paraliza procedimiento o resolución final/de término. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: dentro de quince días hábiles del fragmento siguiente.

## Anclajes y función

- [Art. 43, inc. 01, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen negativo o positivo del régimen sancionador de esta Fuente; el campo vacío no significa ausencia de tipificación.
