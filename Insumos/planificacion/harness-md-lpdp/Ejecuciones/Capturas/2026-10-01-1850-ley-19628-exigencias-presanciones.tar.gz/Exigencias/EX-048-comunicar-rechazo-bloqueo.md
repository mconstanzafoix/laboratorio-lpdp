---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-048"
enunciado: "El responsable debe comunicar electrónicamente a la Agencia su decisión de rechazar un bloqueo temporal."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Comunicar electrónicamente a la Agencia la decisión de rechazar el bloqueo temporal."
condicion_de_aplicacion: "Rechazo de solicitud de bloqueo temporal."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 11, inc. 6, frag. 4, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-06-fragmento-04.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 11, inc. 6, frag. 4: «comunicar en forma electrónica su decisión a la Agencia»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La comunicación a la Agencia se distingue de la fundamentación dirigida al titular. Puede verificarse separadamente y el medio electrónico consta expresamente.

## Alcance de la regla

Se comunica la decisión de rechazo a la Agencia. No se fija un plazo propio distinto del contexto de respuesta al bloqueo ni se delega componente necesario. El carácter es `Condicional` por el supuesto expreso. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 11, inc. 6, frag. 4](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-06-fragmento-04.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
