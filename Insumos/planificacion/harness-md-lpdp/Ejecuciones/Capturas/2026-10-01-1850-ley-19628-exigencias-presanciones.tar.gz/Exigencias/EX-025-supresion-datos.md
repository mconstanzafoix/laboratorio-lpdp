---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-025"
enunciado: "El titular puede solicitar la supresión de sus datos ante las causales legales, salvo las excepciones de necesidad del tratamiento."
destinatario: "Titular"
modalidad: "Derecho del titular"
conducta_exigida: "Solicitar y obtener la supresión de sus datos personales en alguno de los supuestos legales."
condicion_de_aplicacion: "Alguna causal del art. 7, inc. 1, letras a a f Y ausencia de excepción del inc. 2, ordinales i a vi."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 4, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-04/inciso-01.md, enumera supresión; Ley 19.628 consolidada desde 01-DIC-2026, Art. 2, inc. 1, lit. s, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-02/inciso-01-letra-s.md, define supresión; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 1, lit. a, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-a.md, causal de supresión a; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 1, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-b.md, causal de supresión b; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 1, lit. c, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-c.md, causal de supresión c; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 1, lit. d, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-d.md, causal de supresión d; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 1, lit. e, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-e.md, causal de supresión e; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 1, lit. f, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-f.md, causal de supresión f; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02.md, encabezado de excepciones; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 2, ord. i, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-i.md, excepción i; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 2, ord. ii, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-ii.md, excepción ii; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 2, ord. iii, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-iii.md, excepción iii; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 2, ord. iv, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-iv.md, excepción iv; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 2, ord. v, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-v.md, excepción v; Ley 19.628 consolidada desde 01-DIC-2026, Art. 7, inc. 2, ord. vi, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-vi.md, excepción vi"
cita_textual_de_respaldo: "Art. 7, inc. 1: «tiene derecho a solicitar y obtener del responsable, la eliminación de los datos personales»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "Cuando los datos no resulten necesarios en relación con los fines del tratamiento para el cual fueron recogidos; cuando el titular haya revocado su consentimiento para el tratamiento y éste no tenga otro fundamento legal; cuando los datos hayan sido obtenidos o tratados ilícitamente por el responsable; cuando se trate de datos caducos; cuando los datos deban suprimirse para el cumplimiento de una sentencia judicial, de una resolución de la autoridad de protección de datos o de una obligación legal; cuando el titular haya ejercido su derecho de oposición de conformidad al artículo siguiente y no exista otro fundamento legal para su tratamiento; para ejercer el derecho a las libertades de emitir opinión y de informar; para el cumplimiento de una obligación legal o la ejecución de un contrato suscrito entre el titular y el responsable; para el cumplimiento de una función pública o para el ejercicio de una actividad de interés público; por razones de interés público en el área de la salud pública, de conformidad con las condiciones y garantías establecidas en la ley; para tratamientos con fines históricos, estadísticos o científicos y para estudios o investigaciones que atiendan fines de interés público; para la formulación, ejercicio o defensa de una reclamación administrativa o judicial"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso primero reconoce una sola posición de supresión con seis causales alternativas. El inciso segundo limita su procedencia con seis supuestos de necesidad del tratamiento; las letras y ordinales son componentes de esta regla, no derechos separados.

## Alcance de la regla

El titular la ejerce frente al responsable respecto de datos propios. Las seis causales no son acumulativas; las exclusiones impiden supresión cuando concurre alguna necesidad indicada. La necesidad e interés público requieren valoración. No hay plazo cuantificado ni delegación expresa. El carácter es `Condicional` por el supuesto de ejercicio o cumplimiento. Se registra `Indeterminada` por las características del texto señaladas.

## Anclajes y función

- [Art. 7, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01.md): principal: regla expresada.
- [Art. 4, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-04/inciso-01.md): enumera supresión.
- [Art. 2, inc. 1, lit. s](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-02/inciso-01-letra-s.md): define supresión.
- [Art. 7, inc. 1, lit. a](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-a.md): causal de supresión a.
- [Art. 7, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-b.md): causal de supresión b.
- [Art. 7, inc. 1, lit. c](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-c.md): causal de supresión c.
- [Art. 7, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-d.md): causal de supresión d.
- [Art. 7, inc. 1, lit. e](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-e.md): causal de supresión e.
- [Art. 7, inc. 1, lit. f](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-01-letra-f.md): causal de supresión f.
- [Art. 7, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02.md): encabezado de excepciones.
- [Art. 7, inc. 2, ord. i](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-i.md): excepción i.
- [Art. 7, inc. 2, ord. ii](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-ii.md): excepción ii.
- [Art. 7, inc. 2, ord. iii](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-iii.md): excepción iii.
- [Art. 7, inc. 2, ord. iv](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-iv.md): excepción iv.
- [Art. 7, inc. 2, ord. v](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-v.md): excepción v.
- [Art. 7, inc. 2, ord. vi](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-07/inciso-02-ordinal-vi.md): excepción vi.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de los tipos infraccionales de esta Fuente y remisiones pertinentes. El vacío no significa ausencia de tipificación.
