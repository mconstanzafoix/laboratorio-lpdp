---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-038"
enunciado: "El responsable debe pronunciarse sobre la solicitud dentro de treinta días corridos, prorrogables una vez hasta por treinta días corridos."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Pronunciarse sobre la solicitud de ejercicio de derechos del titular."
condicion_de_aplicacion: "Solicitud recibida; prórroga por una sola vez hasta por treinta días corridos."
plazo: "30 días corridos desde el ingreso; prorrogable por una sola vez hasta por treinta días corridos"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 11, inc. 2, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-02-fragmento-01.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 11, inc. 2, frag. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-02-fragmento-02.md, prórroga única"
cita_textual_de_respaldo: "Art. 11, inc. 2, frag. 1: «pronunciarse a más tardar dentro de los treinta días corridos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El pronunciamiento sobre la solicitud es separable del acuse de recibo. El fragmento segundo amplía una sola vez el plazo de la misma posición y no crea otro deber.

## Alcance de la regla

Debe pronunciarse dentro de treinta días corridos desde el ingreso. El plazo puede prorrogarse una vez hasta por treinta días corridos; el texto no exige causas fundadas para ello. No hay delegación. El carácter es `Condicional` por el supuesto de ejercicio o respuesta. Se registra `Determinada` por el grado de concreción indicado.

## Anclajes y función

- [Art. 11, inc. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-02-fragmento-01.md): principal: regla expresada.
- [Art. 11, inc. 2, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-02-fragmento-02.md): prórroga única.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
