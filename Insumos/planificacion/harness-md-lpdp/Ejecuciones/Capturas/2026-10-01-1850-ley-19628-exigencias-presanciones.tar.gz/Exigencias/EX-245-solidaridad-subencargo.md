---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-245"
enunciado: "El encargado que subdelega sigue siendo solidariamente responsable del encargo."
destinatario: "Encargado del tratamiento"
modalidad: "Obligación"
conducta_exigida: "Responder solidariamente por encargo delegado."
condicion_de_aplicacion: "Delegación de parte o totalidad a otro encargado."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 bis, inc. 03, frag. 04, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-03-fragmento-04-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 bis, inc. 03, frag. 04, frag. 01: «continuará siendo solidariamente responsable sobre dicho encargo»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La delegación autorizada no extingue responsabilidad del encargado original.

## Alcance de la regla

La regla se aplica a: Delegación de parte o totalidad a otro encargado. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 bis, inc. 03, frag. 04, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-03-fragmento-04-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
