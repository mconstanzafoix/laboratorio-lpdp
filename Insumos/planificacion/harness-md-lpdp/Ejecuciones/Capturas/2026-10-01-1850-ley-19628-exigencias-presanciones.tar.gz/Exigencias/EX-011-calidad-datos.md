---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-011"
enunciado: "El responsable debe mantener datos personales exactos, completos, actuales y pertinentes respecto de su proveniencia y fines."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Mantener los datos personales exactos, completos, actuales y pertinentes respecto de su proveniencia y fines."
condicion_de_aplicacion: "Tratamiento de datos personales."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. d, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-d.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. d: «Los datos personales deben ser exactos, completos, actuales y pertinentes»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La letra d exige cuatro cualidades de los datos tratados que se evalúan en relación con su origen y fin. Son componentes acumulativos de una sola posición de calidad, no cuatro Exigencias independientes.

## Alcance de la regla

Exactitud, completitud, actualidad y pertinencia deben concurrir durante el tratamiento. La pertinencia y la actualidad requieren valoración contextual; no hay plazo cuantificado ni delegación. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-d.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.
