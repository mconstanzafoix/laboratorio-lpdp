---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-006"
enunciado: "El responsable debe recolectar datos personales con fines específicos, explícitos y lícitos."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Recolectar datos personales con fines específicos, explícitos y lícitos."
condicion_de_aplicacion: "Recolección de datos personales."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-b.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. b: «Los datos personales deben ser recolectados con fines específicos, explícitos y lícitos.»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La primera frase de la letra b impone requisitos acumulativos a la finalidad de recolección. Puede cumplirse o infringirse al definir esa finalidad, separadamente de la limitación del tratamiento posterior, que se registra en otra ficha.

## Alcance de la regla

La regla se activa al recolectar. Especificidad, explicitud y licitud son condiciones simultáneas; su aplicación exige valorar los fines concretos. No se fija plazo ni delegación. El carácter es `Condicional` porque la regla se activa bajo el supuesto indicado. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-b.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.
