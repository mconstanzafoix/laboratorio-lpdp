---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-160"
enunciado: "La Agencia no puede decretar suspensión accesoria del tratamiento si ello afecta los derechos de los titulares."
destinatario: "Agencia"
modalidad: "Prohibición"
conducta_exigida: "Decretar suspensión accesoria que afecte derechos de titulares."
condicion_de_aplicacion: "Consideración de suspensión parcial o total."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 38, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-38/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 38, inc. 02: «no podrá decretarse cuando con ello se afecten los derechos de los titulares»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La afectación de derechos es límite expreso a la facultad sancionadora y requiere valoración.

## Alcance de la regla

La regla se aplica a: Consideración de suspensión parcial o total. Estado `Indeterminada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 38, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-38/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
