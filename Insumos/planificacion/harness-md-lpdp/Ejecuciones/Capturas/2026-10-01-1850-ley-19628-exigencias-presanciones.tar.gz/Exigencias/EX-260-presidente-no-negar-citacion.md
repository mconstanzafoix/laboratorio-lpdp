---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-260"
enunciado: "El presidente del Consejo Directivo no puede negarse a citar la sesión extraordinaria requerida por dos consejeros."
destinatario: "Tercero"
modalidad: "Prohibición"
conducta_exigida: "Negarse a realizar citación de sesión requerida."
condicion_de_aplicacion: "Requerimiento escrito de dos consejeros para sesión extraordinaria."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 quáter, inc. 08, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-08-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 quáter, inc. 08, frag. 02: «El presidente no podrá negarse a realizar la citación»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Prohibición personal del presidente respecto de citación solicitada.

## Alcance de la regla

La regla se aplica a: Requerimiento escrito de dos consejeros para sesión extraordinaria. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 30 quáter, inc. 08, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-08-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
