---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-092"
enunciado: "Los responsables deben suprimir de oficio los datos personales relativos a obligaciones prescritas."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Suprimir de registros o bases de datos toda información personal sobre obligaciones prescritas."
condicion_de_aplicacion: "Obligación prescrita; no se exige solicitud ni orden."
plazo: "sin necesidad de solicitud, orden judicial o instrucción"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 17, inc. 08, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-17/inciso-08.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 17, inc. 08: «Los responsables deberán suprimir de sus registros o bases de datos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Deber autónomo de supresión activado por prescripción; no depende de solicitud del titular.

## Alcance de la regla

La regla se aplica a: Obligación prescrita; no se exige solicitud ni orden. Estado `Determinada`; carácter `Condicional`. Plazo o momento: sin necesidad de solicitud, orden judicial o instrucción.

## Anclajes y función

- [Art. 17, inc. 08](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-17/inciso-08.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
