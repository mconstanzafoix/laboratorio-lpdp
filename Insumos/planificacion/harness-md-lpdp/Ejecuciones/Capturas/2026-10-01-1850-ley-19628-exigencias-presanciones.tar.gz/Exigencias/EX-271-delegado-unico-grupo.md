---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-271"
enunciado: "Entidades de un mismo grupo pueden designar un delegado único si aplican los mismos estándares y éste es accesible para todas."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Designar delegado único para grupo empresarial."
condicion_de_aplicacion: "Mismo grupo, empresas relacionadas o controlador común; mismos estándares/políticas; delegado accesible."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 50, inc. 05, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-05.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 50, inc. 05: «podrán designar un único delegado de protección de datos»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Uniformidad de estándares y accesibilidad requieren comprobación; no altera remisión abierta art. 10/28.

## Alcance de la regla

La regla se aplica a: Mismo grupo, empresas relacionadas o controlador común; mismos estándares/políticas; delegado accesible. Estado `Indeterminada`; carácter `Condicional`. No fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 50, inc. 05](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-05.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
