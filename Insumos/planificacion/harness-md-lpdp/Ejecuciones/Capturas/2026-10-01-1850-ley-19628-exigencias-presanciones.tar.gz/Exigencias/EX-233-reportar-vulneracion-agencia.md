---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-233"
enunciado: "El responsable debe reportar a la Agencia sin dilaciones indebidas las vulneraciones de seguridad que generan riesgo razonable para derechos y libertades del titular."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Reportar vulneración de medidas de seguridad a Agencia."
condicion_de_aplicacion: "Incidente con destrucción, filtración, pérdida, alteración o acceso/comunicación no autorizados Y riesgo razonable para titulares."
plazo: "por medios más expeditos y sin dilaciones indebidas"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14 sexies, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-sexies/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 14 sexies, inc. 01: «El responsable deberá reportar a la Agencia»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "destrucción; filtración; pérdida; alteración; comunicación o acceso no autorizados"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Riesgo razonable y dilación indebida son estándares abiertos.

## Alcance de la regla

La regla se aplica a: Incidente con destrucción, filtración, pérdida, alteración o acceso/comunicación no autorizados Y riesgo razonable para titulares. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: por medios más expeditos y sin dilaciones indebidas.

## Anclajes y función

- [Art. 14 sexies, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-sexies/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
