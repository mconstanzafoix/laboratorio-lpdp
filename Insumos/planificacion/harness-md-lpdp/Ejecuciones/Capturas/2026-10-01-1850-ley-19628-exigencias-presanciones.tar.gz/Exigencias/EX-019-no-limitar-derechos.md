---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-019"
enunciado: "Ningún acto o convención puede limitar los derechos del titular reconocidos por la ley."
destinatario: "Tercero"
modalidad: "Prohibición"
conducta_exigida: "Limitar por acto o convención los derechos del titular reconocidos por la ley."
condicion_de_aplicacion: "Acto o convención que pretenda restringir derechos del titular."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 4, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-04/inciso-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 4, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-04/inciso-01.md, enumera los derechos protegidos"
cita_textual_de_respaldo: "Art. 4, inc. 2: «no pueden limitarse por ningún acto o convención»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La frase «no pueden limitarse por ningún acto o convención» impide una restricción convencional de los derechos. Sus cualidades de personales, intransferibles e irrenunciables delimitan el mismo límite; no son deberes de tratamiento autónomos. El sujeto de cualquier acto o convención se mapea a `Tercero` como categoría residual.

## Alcance de la regla

El límite cubre los derechos enumerados en el inciso primero. No hay plazo ni delegación; la prohibición y su objeto están fijados por el texto. El carácter es `Transversal` por su aplicación a todos los derechos comprendidos. Se registra `Determinada` por las características del texto indicadas.

## Anclajes y función

- [Art. 4, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-04/inciso-02.md): principal: regla expresada.
- [Art. 4, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-04/inciso-01.md): enumera los derechos protegidos.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones expresas relevantes; el campo vacío no significa ausencia de tipificación.
