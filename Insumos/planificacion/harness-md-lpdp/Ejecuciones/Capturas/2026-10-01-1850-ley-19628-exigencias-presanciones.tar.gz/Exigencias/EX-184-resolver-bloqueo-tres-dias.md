---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-184"
enunciado: "La Agencia debe resolver reclamos y solicitudes de suspensión por rechazo de bloqueo temporal dentro de tres días hábiles, sin oír previamente a las partes."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Resolver reclamación y solicitud de suspensión relacionadas con rechazo de bloqueo temporal."
condicion_de_aplicacion: "Rechazo de solicitud de bloqueo temporal del tratamiento."
plazo: "máximo tres días hábiles"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 41, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-41/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 41, inc. 03: «deberán ser resueltas por la Agencia en el plazo máximo de tres días hábiles»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "reclamación; solicitud de suspensión"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Es procedimiento acelerado especial, excepción a la audiencia previa ordinaria del inciso segundo.

## Alcance de la regla

La regla se aplica a: Rechazo de solicitud de bloqueo temporal del tratamiento. Estado `Determinada`; carácter `Condicional`. Plazo o momento: máximo tres días hábiles.

## Anclajes y función

- [Art. 41, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-41/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con las tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
