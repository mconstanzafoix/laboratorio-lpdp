---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-007"
enunciado: "El responsable debe limitar el tratamiento a los fines informados o a las excepciones expresas de la ley."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Limitar el tratamiento al cumplimiento de los fines de recolección informados, salvo los supuestos expresos."
condicion_de_aplicacion: "Tratamiento posterior a la recolección Y (fin informado O fin compatible con el autorizado originalmente O relación contractual o precontractual que justifique otro fin dentro del contrato o tratativas O nuevo consentimiento O disposición legal)."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-b.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. b, párr. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-b-parrafo-02.md, prohibición y excepciones a fines distintos"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. b: «El tratamiento de los datos personales debe limitarse al cumplimiento de estos fines.»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "compatible con los autorizados originalmente; relación contractual o precontractual que justifique finalidad distinta dentro del contrato o tratativas; nuevo consentimiento del titular; disposición de la ley"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La segunda frase de la letra b exige limitar el tratamiento a sus fines. El párrafo siguiente explicita que no se pueden usar fines distintos a los informados salvo sus excepciones. Ambos textos delimitan una misma posición sobre finalidad posterior, sin duplicarla como una prohibición correlativa.

## Alcance de la regla

Las alternativas de excepción son las cuatro previstas textualmente en el párrafo segundo. La compatibilidad y la justificación contractual o precontractual exigen valoración. No hay plazo ni delegación expresa. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-b.md): principal: regla expresada.
- [Art. 3, inc. 1, lit. b, párr. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-b-parrafo-02.md): prohibición y excepciones a fines distintos.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.
