---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-255"
enunciado: "El Presidente de la República debe proponer la nómina de candidatos a consejeros de la Agencia para su designación."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Proponer nómina de consejeros."
condicion_de_aplicacion: "Proceso de designación de miembros del Consejo Directivo."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 quáter, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 quáter, inc. 02: «hará la proposición de la nómina que corresponda»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Presidente de la República es destinatario residual; el Senado decide conforme al inciso primero.

## Alcance de la regla

La regla se aplica a: Proceso de designación de miembros del Consejo Directivo. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 30 quáter, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
