---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-229"
enunciado: "El responsable debe aplicar medidas técnicas y organizativas para que por defecto solo se traten datos específicos y estrictamente necesarios."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Configurar tratamiento por defecto limitado a datos específicos y necesarios."
condicion_de_aplicacion: "Tratamiento de datos; valoración del número recogido, extensión, plazo de conservación y accesibilidad."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14 quáter, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quáter/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 14 quáter, inc. 02: «deberá aplicar medidas técnicas y organizativas para garantizar que, por defecto»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "número de datos; extensión del tratamiento; plazo de conservación; accesibilidad"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La necesidad estricta y configuración adecuada requieren valoración; la regla es distinta del diseño previo.

## Alcance de la regla

La regla se aplica a: Tratamiento de datos; valoración del número recogido, extensión, plazo de conservación y accesibilidad. Estado `Indeterminada`; carácter `Transversal`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 14 quáter, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quáter/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliar el art. 34 ter letra j y demás tipificaciones; el campo vacío no implica ausencia de tipificación.
