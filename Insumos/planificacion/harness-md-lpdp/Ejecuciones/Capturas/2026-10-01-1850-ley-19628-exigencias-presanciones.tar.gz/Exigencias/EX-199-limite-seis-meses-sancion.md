---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-199"
enunciado: "La Agencia no puede prolongar el procedimiento administrativo sancionador más de seis meses."
destinatario: "Agencia"
modalidad: "Prohibición"
conducta_exigida: "Extender procedimiento sancionador más de seis meses."
condicion_de_aplicacion: "Procedimiento administrativo por infracción de ley."
plazo: "máximo seis meses"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 01, lit. l, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-l-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 42, inc. 01, lit. l, frag. 01: «no podrá superar los seis meses»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Límite temporal explícito del procedimiento sancionador.

## Alcance de la regla

La regla se aplica a: Procedimiento administrativo por infracción de ley. Estado `Determinada`; carácter `Condicional`. Plazo o momento: máximo seis meses.

## Anclajes y función

- [Art. 42, inc. 01, lit. l, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-l-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
