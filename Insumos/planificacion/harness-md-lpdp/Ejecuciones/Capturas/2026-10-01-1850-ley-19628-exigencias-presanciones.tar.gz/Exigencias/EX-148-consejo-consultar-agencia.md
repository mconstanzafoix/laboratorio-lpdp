---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-148"
enunciado: "El Consejo para la Transparencia debe remitir antecedentes y pedir informe a la Agencia antes de dictar una instrucción general con claros efectos en competencia de ésta."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Remitir antecedentes y requerir informe a la Agencia."
condicion_de_aplicacion: "Proyecto de instrucción general del Consejo con claros efectos en competencia de la Agencia."
plazo: "antes de dictar la instrucción general"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 31, inc. 04, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-31/inciso-04.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 31, inc. 04: «el Consejo para la Transparencia remitirá los antecedentes y requerirá informe a la Agencia»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Consejo es destinatario residual; la apreciación de efectos claros en competencia de Agencia es abierta.

## Alcance de la regla

La regla se aplica a: Proyecto de instrucción general del Consejo con claros efectos en competencia de la Agencia. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: antes de dictar la instrucción general.

## Anclajes y función

- [Art. 31, inc. 04](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-31/inciso-04.md): principal: regla expresada.

## Límites del análisis

La regla de silencio y prosecución del procedimiento por Ley 19.880 art. 38 inc. 2 no se determina sin esa Fuente; las obligaciones independientes aquí fichadas sí tienen texto suficiente. La calificación de `sancion` queda pendiente.
