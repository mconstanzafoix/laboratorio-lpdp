---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-265"
enunciado: "El responsable puede designar un delegado de protección de datos personales."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Designar delegado de protección de datos."
condicion_de_aplicacion: "Responsable opta por designación cumpliendo requisitos de este artículo."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 50, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 50, inc. 01: «podrá designar un delegado de protección de datos personales»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La designación es potestativa; de ocurrir, rigen requisitos de autonomía e idoneidad.

## Alcance de la regla

La regla se aplica a: Responsable opta por designación cumpliendo requisitos de este artículo. Estado `Determinada`; carácter `Condicional`. No fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 50, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
