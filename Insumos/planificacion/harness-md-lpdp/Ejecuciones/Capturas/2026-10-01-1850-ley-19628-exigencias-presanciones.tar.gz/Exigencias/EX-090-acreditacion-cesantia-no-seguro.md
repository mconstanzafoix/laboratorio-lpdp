---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-090"
enunciado: "Las personas fuera del seguro de cesantía deben acreditar su cesantía ante el Boletín con finiquito o acta para obtener el bloqueo por tres meses, renovable una vez con declaración jurada."
destinatario: "Titular"
modalidad: "Obligación"
conducta_exigida: "Acreditar cesantía y acompañar documentos indicados para impetrar bloqueo o renovación."
condicion_de_aplicacion: "Persona no incorporada al seguro de cesantía que pretende ejercer el bloqueo."
plazo: "tres meses, renovable hasta una vez; declaración jurada para renovación"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 17, inc. 05, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-17/inciso-05.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 17, inc. 05: «deberán acreditar dicha condición ante el Boletín de Informaciones Comerciales»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "finiquito legal o acta de comparecencia ante Inspección del Trabajo si hay controversia; declaración jurada para renovación"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Es carga para activar el derecho de bloqueo de quien no integra el seguro.

## Alcance de la regla

La regla se aplica a: Persona no incorporada al seguro de cesantía que pretende ejercer el bloqueo. Estado `Determinada`; carácter `Condicional`. Plazo o momento: tres meses, renovable hasta una vez; declaración jurada para renovación.

## Anclajes y función

- [Art. 17, inc. 05](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-17/inciso-05.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
