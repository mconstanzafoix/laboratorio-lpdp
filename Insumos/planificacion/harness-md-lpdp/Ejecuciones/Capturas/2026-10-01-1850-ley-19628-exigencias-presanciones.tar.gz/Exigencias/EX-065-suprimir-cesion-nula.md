---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-065"
enunciado: "El cesionario debe suprimir todos los datos recibidos cuando la cesión es nula por faltar consentimiento necesario."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Suprimir todos los datos recibidos mediante cesión nula por falta de consentimiento necesario."
condicion_de_aplicacion: "Cesión sin consentimiento del titular cuando ese consentimiento era necesario."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15, inc. 6, frag. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15/inciso-06-fragmento-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15, inc. 6, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15/inciso-06-fragmento-01.md, nulidad que activa supresión"
cita_textual_de_respaldo: "Art. 15, inc. 6, frag. 2: «debiendo el cesionario suprimir todos los datos recibidos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La nulidad por falta de consentimiento es la condición del deber del cesionario de suprimir todos los datos recibidos. La cláusula de responsabilidades legales no crea otro deber de tratamiento.

## Alcance de la regla

La supresión comprende todos los datos recibidos en la cesión nula. No se fija plazo cuantificado ni delegación. El carácter es `Condicional` por el supuesto de cesión. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 15, inc. 6, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15/inciso-06-fragmento-02.md): principal: regla expresada.
- [Art. 15, inc. 6, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15/inciso-06-fragmento-01.md): nulidad que activa supresión.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
