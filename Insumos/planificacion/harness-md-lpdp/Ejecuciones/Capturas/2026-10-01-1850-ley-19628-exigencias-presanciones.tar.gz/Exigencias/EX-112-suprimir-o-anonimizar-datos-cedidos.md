---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-112"
enunciado: "El órgano público receptor debe suprimir o anonimizar los datos al terminar el tiempo necesario para el tratamiento específico, salvo conservación justificada."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Suprimir o anonimizar los datos recibidos."
condicion_de_aplicacion: "Finaliza el tiempo necesario de tratamiento específico y no concurre excepción de conservación mayor del fragmento tercero."
plazo: "al concluir tiempo necesario"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 22, inc. 03, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-22/inciso-03-fragmento-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 26, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-26/inciso-01.md, delega componente reglamentario: reglamento fija los procedimientos de anonimización, incluidos datos sensibles"
cita_textual_de_respaldo: "Art. 22, inc. 03, frag. 02: «luego de lo cual deberán ser suprimidos o anonimizados»"
estado_de_determinacion: "Delegada"
enumeracion_contenida: "supresión; anonimización"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El deber ofrece alternativas de cierre; cuándo termina el tiempo necesario requiere valoración.

## Alcance de la regla

La ley encarga expresamente al reglamento expedido por el Ministerio Secretaría General de la Presidencia, suscrito por los ministros de Hacienda y Economía, previo informe de la Agencia, concretar el componente señalado: reglamento fija los procedimientos de anonimización, incluidos datos sensibles. No se identifica ni supone aquí el contenido del reglamento.

La regla se aplica a: Finaliza el tiempo necesario de tratamiento específico y no concurre excepción de conservación mayor del fragmento tercero. Estado `Delegada`; carácter `Condicional`. Plazo o momento: al concluir tiempo necesario.

## Anclajes y función

- [Art. 22, inc. 03, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-22/inciso-03-fragmento-02.md): principal: regla expresada.

- [Art. 26, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-26/inciso-01.md): delega componente reglamentario: reglamento fija los procedimientos de anonimización, incluidos datos sensibles.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
