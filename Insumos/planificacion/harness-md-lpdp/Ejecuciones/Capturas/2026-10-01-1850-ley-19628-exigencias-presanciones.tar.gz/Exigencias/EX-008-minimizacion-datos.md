---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-008"
enunciado: "El responsable debe limitar los datos tratados a los necesarios, adecuados y pertinentes para sus fines."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Limitar los datos tratados a los necesarios, adecuados y pertinentes para los fines del tratamiento."
condicion_de_aplicacion: "Tratamiento de datos personales."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. c, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-c.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. c: «Los datos personales que se traten deben limitarse estrictamente a aquéllos que resulten necesarios, adecuados y pertinentes.»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La letra c impone una limitación sobre el conjunto de datos tratados en relación con los fines. Es distinta del período de conservación tratado en el párrafo segundo de la misma letra.

## Alcance de la regla

Necesidad, adecuación y pertinencia son requisitos acumulativos que deben apreciarse frente a los fines concretos. No hay plazo cuantificado ni delegación expresa. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. c](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-c.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.
