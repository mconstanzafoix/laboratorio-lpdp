---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-016"
enunciado: "El responsable debe guardar secreto o confidencialidad sobre los datos personales a los que accede."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Guardar secreto o confidencialidad sobre los datos personales a los que accede."
condicion_de_aplicacion: "Acceso a datos personales en la relación con el titular, incluso después de concluida esta."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. h, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-h.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. h: «El responsable de datos personales y quienes tengan acceso a ellos deberán guardar secreto o confidencialidad»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La primera frase incluye expresamente al responsable y a otras personas con acceso. Esta ficha registra la posición del responsable; otra ficha registra el mismo deber para los otros sujetos porque el campo de destinatario admite un solo valor.

## Alcance de la regla

El deber subsiste tras la conclusión de la relación con el titular, según la última frase de la letra. El alcance concreto del secreto depende del acceso y del contexto; no hay plazo terminal ni delegación. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. h](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-h.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.
