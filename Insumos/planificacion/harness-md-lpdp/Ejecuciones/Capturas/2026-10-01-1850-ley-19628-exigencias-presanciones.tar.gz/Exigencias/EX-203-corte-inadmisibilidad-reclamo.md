---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-203"
enunciado: "La Corte puede declarar inadmisible el reclamo si el escrito no satisface los requisitos de la letra a."
destinatario: "Tercero"
modalidad: "Permiso condicionado"
conducta_exigida: "Declarar inadmisible reclamación judicial."
condicion_de_aplicacion: "Escrito incumple condiciones de letra a."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 43, inc. 01, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-b.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 43, inc. 01, lit. b: «La Corte podrá declarar inadmisible la reclamación»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Facultad judicial por defecto formal de reclamo.

## Alcance de la regla

La regla se aplica a: Escrito incumple condiciones de letra a. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 43, inc. 01, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-b.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen negativo o positivo del régimen sancionador de esta Fuente; el campo vacío no significa ausencia de tipificación.
