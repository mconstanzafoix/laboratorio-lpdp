---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-151"
enunciado: "La Agencia debe incluir en los contratos de su personal una cláusula que haga constar la aplicación de las normas de probidad señaladas."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Dejar constancia contractual de la aplicación de normas de probidad."
condicion_de_aplicacion: "Contratos de personal de la Agencia comprendido en el fragmento anterior."
plazo: "al celebrar contratos"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 32, inc. 02, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-32/inciso-02-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 32, inc. 02, frag. 02: «debiendo dejarse constancia en los contratos respectivos de una cláusula»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El fragmento exige constancia contractual; el contenido sustantivo de las leyes de probidad referidas no se infiere de esta Fuente.

## Alcance de la regla

La regla se aplica a: Contratos de personal de la Agencia comprendido en el fragmento anterior. Estado `Determinada`; carácter `Condicional`. Plazo o momento: al celebrar contratos.

## Anclajes y función

- [Art. 32, inc. 02, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-32/inciso-02-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no implica ausencia de tipificación.
