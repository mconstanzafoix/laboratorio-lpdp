---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-067"
enunciado: "Ante duda o controversia, el responsable debe acreditar las condiciones que habilitan a una entidad sin fines de lucro a tratar datos sensibles."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Acreditar la concurrencia de condiciones para tratar datos sensibles sin consentimiento como entidad sin fines de lucro."
condicion_de_aplicacion: "Duda o controversia administrativa o judicial sobre la concurrencia de las condiciones del art. 16 inc. 2 letra b."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16, inc. 2, lit. b, párr. 2, frag. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16/inciso-02-letra-b-parrafo-02-fragmento-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16, inc. 2, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16/inciso-02-letra-b.md, condiciones acreditadas"
cita_textual_de_respaldo: "Art. 16, inc. 2, lit. b, párr. 2, frag. 2: «el responsable de datos deberá acreditar su concurrencia»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El fragmento segundo impone acreditar la concurrencia de las condiciones de la letra b ante duda o controversia. Es un deber probatorio adicional a cumplirlas para usar el permiso de tratamiento.

## Alcance de la regla

Se activa en duda o controversia administrativa o judicial. La prueba versa sobre las condiciones de la entidad. No se fija plazo ni medio exclusivo. El carácter es `Condicional` por el supuesto expreso. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 16, inc. 2, lit. b, párr. 2, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16/inciso-02-letra-b-parrafo-02-fragmento-02.md): principal: regla expresada.
- [Art. 16, inc. 2, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16/inciso-02-letra-b.md): condiciones acreditadas.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
