---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-253"
enunciado: "La Agencia debe someter a consulta pública web sus instrucciones y normas generales, habilitando observaciones de interesados y limitándolas a regulación necesaria de tratamiento."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Efectuar consulta pública web antes de emitir instrucciones y normas generales."
condicion_de_aplicacion: "Agencia prepara instrucción o norma general y obligatoria de tratamiento."
plazo: "antes de emitir norma"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 bis, inc. 01, lit. a, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-bis/inciso-01-letra-a-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 bis, inc. 01, lit. a, frag. 02: «deberán ser emitidas previa consulta pública»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "consulta web; observaciones de interesados; relación estricta con tratamiento; necesidad para cumplimiento"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La necesidad y relación estricta requieren valoración; consulta y observaciones son requisitos de emisión.

## Alcance de la regla

La regla se aplica a: Agencia prepara instrucción o norma general y obligatoria de tratamiento. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: antes de emitir norma.

## Anclajes y función

- [Art. 30 bis, inc. 01, lit. a, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-bis/inciso-01-letra-a-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
