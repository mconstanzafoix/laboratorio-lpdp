---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-159"
enunciado: "La Agencia puede suspender hasta treinta días el tratamiento por multas de infracciones gravísimas reiteradas dentro de veinticuatro meses, sin afectar almacenamiento."
destinatario: "Agencia"
modalidad: "Permiso condicionado"
conducta_exigida: "Disponer suspensión parcial o total de operaciones y actividades de tratamiento."
condicion_de_aplicacion: "Multas por infracciones gravísimas reiteradas en veinticuatro meses; no afectar derechos de titulares."
plazo: "hasta treinta días"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 38, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-38/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 38, inc. 01: «la Agencia podrá disponer la suspensión de las operaciones y actividades»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La medida es discrecional y limitada; los incisos siguientes regulan modalidad, prohibición y prórroga.

## Alcance de la regla

La regla se aplica a: Multas por infracciones gravísimas reiteradas en veinticuatro meses; no afectar derechos de titulares. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: hasta treinta días.

## Anclajes y función

- [Art. 38, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-38/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
