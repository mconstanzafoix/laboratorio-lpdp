---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-094"
enunciado: "Los responsables no pueden comunicar datos de obligaciones económicas una vez transcurridos cinco años desde que la obligación se hizo exigible."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "Comunicar datos de obligaciones del artículo 17 luego de cinco años."
condicion_de_aplicacion: "Datos de persona identificada o identificable relativos a obligaciones del artículo 17."
plazo: "después de cinco años desde exigibilidad"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 18, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-18/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 18, inc. 01: «En ningún caso pueden comunicarse los datos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso fija límite temporal máximo absoluto a la comunicación de datos del artículo 17.

## Alcance de la regla

La regla se aplica a: Datos de persona identificada o identificable relativos a obligaciones del artículo 17. Estado `Determinada`; carácter `Condicional`. Plazo o momento: después de cinco años desde exigibilidad.

## Anclajes y función

- [Art. 18, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-18/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
