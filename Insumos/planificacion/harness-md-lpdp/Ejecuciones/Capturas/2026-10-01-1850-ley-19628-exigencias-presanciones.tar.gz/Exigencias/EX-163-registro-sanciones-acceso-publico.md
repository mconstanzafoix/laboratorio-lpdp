---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-163"
enunciado: "La Agencia debe mantener el Registro Nacional de Sanciones y Cumplimiento público, gratuito y consultable electrónicamente."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Mantener acceso público, gratuito y electrónico al registro."
condicion_de_aplicacion: "Administración del Registro Nacional de Sanciones y Cumplimiento por Agencia."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 39, inc. 01, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-39/inciso-01-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 39, inc. 01, frag. 02: «El registro será público y su acceso gratuito»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "público; gratuito; electrónico"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La regla de acceso del registro se atribuye a su administradora, la Agencia.

## Alcance de la regla

La regla se aplica a: Administración del Registro Nacional de Sanciones y Cumplimiento por Agencia. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 39, inc. 01, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-39/inciso-01-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
