---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-205"
enunciado: "La Corte debe requerir informe a la Agencia al recibir el reclamo y concederle diez días."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Requerir informe a la Agencia."
condicion_de_aplicacion: "Recepción de reclamación judicial de ilegalidad."
plazo: "diez días; tipo de días no determinado"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 43, inc. 01, lit. c, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-c.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 43, inc. 01, lit. c: «la Corte requerirá de informe de la Agencia, concediéndole un plazo de diez días»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Corte instruye traslado con plazo de diez días no adjetivados.

## Alcance de la regla

La regla se aplica a: Recepción de reclamación judicial de ilegalidad. Estado `Determinada`; carácter `Condicional`. Plazo o momento: diez días; tipo de días no determinado.

## Anclajes y función

- [Art. 43, inc. 01, lit. c](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-letra-c.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen negativo o positivo del régimen sancionador de esta Fuente; el campo vacío no significa ausencia de tipificación.
