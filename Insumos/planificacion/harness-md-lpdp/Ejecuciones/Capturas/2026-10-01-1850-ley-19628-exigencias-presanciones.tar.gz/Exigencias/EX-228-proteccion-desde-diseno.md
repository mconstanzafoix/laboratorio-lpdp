---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-228"
enunciado: "El responsable debe aplicar medidas técnicas y organizativas adecuadas desde el diseño, antes y durante el tratamiento, para proteger principios y derechos del titular."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Aplicar medidas técnicas y organizativas desde el diseño."
condicion_de_aplicacion: "Tratamiento de datos previsto o en curso; consideración de técnica, costos, naturaleza, contexto, fines y riesgos."
plazo: "antes y durante tratamiento"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14 quáter, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quáter/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 14 quáter, inc. 01: «debe aplicar medidas técnicas y organizativas adecuadas desde el diseño»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "estado de la técnica; costos; naturaleza, ámbito, contexto y fines; riesgos"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La adecuación y ponderación de factores es abierta; el deber rige desde la planificación y durante el tratamiento.

## Alcance de la regla

La regla se aplica a: Tratamiento de datos previsto o en curso; consideración de técnica, costos, naturaleza, contexto, fines y riesgos. Estado `Indeterminada`; carácter `Transversal`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 14 quáter, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quáter/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliar el art. 34 ter letra j y demás tipificaciones; el campo vacío no implica ausencia de tipificación.
