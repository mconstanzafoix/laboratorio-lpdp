---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-285"
enunciado: "El titular afectado puede reclamar ante Corte de Apelaciones conforme al art. 43 por denegación injustificada o arbitraria o infracción con perjuicio de cuatro órganos señalados."
destinatario: "Titular"
modalidad: "Derecho del titular"
conducta_exigida: "Reclamar judicialmente contra decisión u operación de órgano indicado."
condicion_de_aplicacion: "Contraloría, Ministerio Público, Banco Central o Servicio Electoral deniega derecho sin justificación o infringe deber/principio causando perjuicio."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 55, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-55/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 55, inc. 02: «podrá reclamar ante la Corte de Apelaciones»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "Contraloría; Ministerio Público; Banco Central; Servicio Electoral"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La arbitrariedad, injustificación y perjuicio requieren valoración; procedimiento del art. 43 ya fue examinado.

## Alcance de la regla

La regla se aplica a: Contraloría, Ministerio Público, Banco Central o Servicio Electoral deniega derecho sin justificación o infringe deber/principio causando perjuicio. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 55, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-55/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
