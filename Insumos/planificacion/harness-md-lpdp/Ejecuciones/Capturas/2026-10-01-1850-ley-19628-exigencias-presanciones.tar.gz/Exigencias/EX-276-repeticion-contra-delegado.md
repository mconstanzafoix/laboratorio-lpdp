---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-276"
enunciado: "El responsable puede ejercer acciones de repetición contra el delegado por infracciones al deber de secreto."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Ejercer repetición contra delegado."
condicion_de_aplicacion: "Responsable asumió consecuencias de infracción de secreto del delegado."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 50, inc. 08, frag. 03, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-08-fragmento-03-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 50, inc. 08, frag. 03, frag. 02: «acciones de repetición que pueda ejercer contra éste»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La norma reserva la acción de regreso tras imputación al responsable.

## Alcance de la regla

La regla se aplica a: Responsable asumió consecuencias de infracción de secreto del delegado. Estado `Determinada`; carácter `Condicional`. No fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 50, inc. 08, frag. 03, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-08-fragmento-03-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
