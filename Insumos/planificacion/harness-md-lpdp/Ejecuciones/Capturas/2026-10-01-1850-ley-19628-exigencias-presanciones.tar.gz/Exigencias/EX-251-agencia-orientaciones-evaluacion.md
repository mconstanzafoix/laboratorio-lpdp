---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-251"
enunciado: "La Agencia debe establecer orientaciones mínimas para evaluación de impacto que incluyan operaciones, finalidad, necesidad, proporcionalidad, riesgos y mitigación."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Establecer orientaciones mínimas de evaluación de impacto."
condicion_de_aplicacion: "Evaluaciones de impacto de tratamiento de datos."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 ter, inc. 03: «también establecerá las orientaciones mínimas para realizar esta evaluación»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "operaciones; finalidad; necesidad y proporcionalidad; riesgos; medidas de mitigación"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Agencia debe concretar método mínimo de evaluación; necesidad y proporcionalidad son conceptos abiertos.

## Alcance de la regla

La regla se aplica a: Evaluaciones de impacto de tratamiento de datos. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 ter, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-03.md): principal: regla expresada.

## Límites del análisis

El vínculo sancionador con art. 34 quáter letra k y demás tipos requiere conciliación individual; `sancion` permanece vacío sin implicar ausencia.
