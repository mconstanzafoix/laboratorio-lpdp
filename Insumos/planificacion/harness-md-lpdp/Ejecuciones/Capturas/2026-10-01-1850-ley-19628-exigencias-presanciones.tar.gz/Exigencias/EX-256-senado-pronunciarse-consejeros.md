---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-256"
enunciado: "El Senado debe pronunciarse sobre la propuesta de consejeros de la Agencia presentada por el Presidente."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Pronunciarse respecto de propuesta de consejeros."
condicion_de_aplicacion: "Recepción de propuesta del Presidente de la República."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 quáter, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 quáter, inc. 02: «el Senado deberá pronunciarse respecto de la propuesta»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Senado es destinatario residual; acuerdo de dos tercios se fija en inciso primero.

## Alcance de la regla

La regla se aplica a: Recepción de propuesta del Presidente de la República. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 30 quáter, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
