---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-185"
enunciado: "La Agencia debe instruir el procedimiento sancionador por infracciones de esta ley."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Instruir procedimiento sancionador."
condicion_de_aplicacion: "Procedimiento administrativo por infracción de ley."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 01, lit. a, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-a.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 42, inc. 01, lit. a: «será instruido por la Agencia»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El texto atribuye en exclusiva la instrucción a la Agencia.

## Alcance de la regla

La regla se aplica a: Procedimiento administrativo por infracción de ley. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 42, inc. 01, lit. a](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-a.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
