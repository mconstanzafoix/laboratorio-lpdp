---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-161"
enunciado: "Durante la suspensión, el responsable debe adoptar medidas necesarias para adecuar su tratamiento a las exigencias de la resolución."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Adoptar medidas de adecuación ordenadas en resolución de suspensión."
condicion_de_aplicacion: "Suspensión accesoria vigente."
plazo: "durante el período de suspensión"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 38, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-38/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 38, inc. 03: «el responsable deberá adoptar las medidas necesarias»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La necesidad de medidas depende de exigencias concretas de la resolución; no se infieren aquí.

## Alcance de la regla

La regla se aplica a: Suspensión accesoria vigente. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: durante el período de suspensión.

## Anclajes y función

- [Art. 38, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-38/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
