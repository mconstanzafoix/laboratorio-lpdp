---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-150"
enunciado: "El Consejo para la Transparencia debe considerar la opinión de la Agencia y expresarla en la motivación de su instrucción general."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Considerar opinión de Agencia y expresar esa consideración en motivación."
condicion_de_aplicacion: "Agencia evacúa informe solicitado por Consejo para la Transparencia."
plazo: "al motivar la instrucción general"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 31, inc. 04, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-31/inciso-04.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 31, inc. 04: «El Consejo para la Transparencia considerará el contenido de la opinión de la Agencia»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Consejo conserva deber de motivación; el efecto de falta de informe remite a Ley 19.880 art. 38 inc. 2, aún no incorporado.

## Alcance de la regla

La regla se aplica a: Agencia evacúa informe solicitado por Consejo para la Transparencia. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: al motivar la instrucción general.

## Anclajes y función

- [Art. 31, inc. 04](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-31/inciso-04.md): principal: regla expresada.

## Límites del análisis

La regla de silencio y prosecución del procedimiento por Ley 19.880 art. 38 inc. 2 no se determina sin esa Fuente; las obligaciones independientes aquí fichadas sí tienen texto suficiente. La calificación de `sancion` queda pendiente.
