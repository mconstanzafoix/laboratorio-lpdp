---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-188"
enunciado: "La Agencia debe designar un funcionario responsable de instruir el procedimiento al abrir el expediente."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Designar funcionario instructor."
condicion_de_aplicacion: "Apertura del expediente sancionador."
plazo: "junto con apertura del expediente"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 01, lit. b, frag. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-b-fragmento-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 42, inc. 01, lit. b, frag. 03: «deberá designar un funcionario responsable de la instrucción»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La designación acompaña la apertura del expediente.

## Alcance de la regla

La regla se aplica a: Apertura del expediente sancionador. Estado `Determinada`; carácter `Condicional`. Plazo o momento: junto con apertura del expediente.

## Anclajes y función

- [Art. 42, inc. 01, lit. b, frag. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-b-fragmento-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
