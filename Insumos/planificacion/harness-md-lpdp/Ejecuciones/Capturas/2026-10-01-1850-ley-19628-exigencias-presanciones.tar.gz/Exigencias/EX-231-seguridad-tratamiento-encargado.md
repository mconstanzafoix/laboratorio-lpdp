---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-231"
enunciado: "El encargado del tratamiento debe aplicar medidas técnicas y organizativas apropiadas al riesgo, incluidas cuando proceda las cuatro clases de medidas enumeradas."
destinatario: "Encargado del tratamiento"
modalidad: "Obligación"
conducta_exigida: "Aplicar medidas técnicas y organizativas apropiadas para nivel de seguridad adecuado al riesgo."
condicion_de_aplicacion: "Tratamiento por cuenta del responsable; consideración de técnica, costos, naturaleza, contexto, fines y riesgos."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 14 quinquies, inc. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quinquies/inciso-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 14 quinquies, inc. 02: «el responsable y el encargado del tratamiento aplicarán medidas técnicas y organizativas apropiadas»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "seudonimización y cifrado; confidencialidad, integridad, disponibilidad y resiliencia; restauración rápida; evaluación regular de eficacia"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El encargado es sujeto expreso; riesgo adecuado y pertinencia de medidas requieren valoración.

## Alcance de la regla

La regla se aplica a: Tratamiento por cuenta del responsable; consideración de técnica, costos, naturaleza, contexto, fines y riesgos. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 14 quinquies, inc. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quinquies/inciso-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliar el art. 34 ter letra j y demás tipificaciones; el campo vacío no implica ausencia de tipificación.
