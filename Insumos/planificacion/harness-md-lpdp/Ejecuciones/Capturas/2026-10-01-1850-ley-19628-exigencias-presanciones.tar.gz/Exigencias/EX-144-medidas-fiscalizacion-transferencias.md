---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-144"
enunciado: "La Agencia puede formular recomendaciones, adoptar medidas conservativas y suspender temporalmente transferencias internacionales en casos calificados."
destinatario: "Agencia"
modalidad: "Permiso condicionado"
conducta_exigida: "Formular recomendaciones, adoptar medidas conservativas o suspender temporalmente el envío de datos."
condicion_de_aplicacion: "Fiscalización de transferencias internacionales; suspensión solo en casos calificados."
plazo: "suspensión temporal; duración no cuantificada"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 29, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-29/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 29, inc. 1: «pudiendo formular recomendaciones, adoptar medidas conservativas y en casos calificados, suspender temporalmente»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "recomendaciones; medidas conservativas; suspensión temporal"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Las tres facultades son modalidades de intervención fiscalizadora; “casos calificados” y medida conservativa requieren valoración.

## Alcance de la regla

La regla se aplica a: Fiscalización de transferencias internacionales; suspensión solo en casos calificados. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: suspensión temporal; duración no cuantificada.

## Anclajes y función

- [Art. 29, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-29/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
