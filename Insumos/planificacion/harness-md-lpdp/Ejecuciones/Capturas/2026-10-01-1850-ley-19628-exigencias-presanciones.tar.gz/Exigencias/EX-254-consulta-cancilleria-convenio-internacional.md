---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-254"
enunciado: "La Agencia debe consultar previamente al Ministerio de Relaciones Exteriores antes de suscribir convenios con entidades públicas internacionales."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Consultar al Ministerio de Relaciones Exteriores."
condicion_de_aplicacion: "Suscripción de convenio con entidad pública internacional."
plazo: "previamente al convenio"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 bis, inc. 01, lit. k, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-bis/inciso-01-letra-k-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 bis, inc. 01, lit. k, frag. 02: «se requerirá consultar previamente al Ministerio de Relaciones Exteriores»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La consulta previa es expresa; su forma según Ley 21.080 art. 35 no se infiere por falta de esa Fuente.

## Alcance de la regla

La regla se aplica a: Suscripción de convenio con entidad pública internacional. Estado `Determinada`; carácter `Condicional`. Plazo o momento: previamente al convenio.

## Anclajes y función

- [Art. 30 bis, inc. 01, lit. k, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-bis/inciso-01-letra-k-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
