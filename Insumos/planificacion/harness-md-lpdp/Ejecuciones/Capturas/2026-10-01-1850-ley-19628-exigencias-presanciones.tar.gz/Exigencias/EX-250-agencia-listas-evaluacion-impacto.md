---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-250"
enunciado: "La Agencia debe establecer y publicar lista orientativa de operaciones que requieren o no evaluación de impacto."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Establecer y publicar lista orientativa de tipos de tratamiento."
condicion_de_aplicacion: "Necesidad de orientar aplicación de evaluación de impacto."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 ter, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 ter, inc. 03: «establecerá y publicará una lista orientativa»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "operaciones que requieren evaluación; operaciones que no la requieren"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La lista orienta y no reemplaza supuesto legal de alto riesgo.

## Alcance de la regla

La regla se aplica a: Necesidad de orientar aplicación de evaluación de impacto. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 ter, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-ter/inciso-03.md): principal: regla expresada.

## Límites del análisis

El vínculo sancionador con art. 34 quáter letra k y demás tipos requiere conciliación individual; `sancion` permanece vacío sin implicar ausencia.
