---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-062"
enunciado: "El responsable debe recabar nuevo consentimiento antes de ceder si el consentimiento inicial no comprendía la cesión."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Recabar consentimiento del titular antes de ceder datos si el consentimiento inicial no comprendía la cesión."
condicion_de_aplicacion: "Consentimiento inicial de recolección sin alcance a la cesión Y cesión proyectada que requiere consentimiento."
plazo: "antes de la cesión"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15/inciso-02.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 15, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15/inciso-01.md, cesión habilitada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 12, inc. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-12/inciso-02.md, requisitos del nuevo consentimiento"
cita_textual_de_respaldo: "Art. 15, inc. 2: «éste debe recabarse antes que se produzca»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso segundo obliga a recabar un nuevo consentimiento antes de la cesión cuando el anterior no la cubría. Se considera nueva operación de tratamiento; esa calificación delimita su validez.

## Alcance de la regla

El consentimiento se recaba antes de ceder y bajo requisitos generales del art. 12. No hay días cuantificados ni delegación. El carácter es `Condicional` por el supuesto de cesión. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 15, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15/inciso-02.md): principal: regla expresada.
- [Art. 15, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15/inciso-01.md): cesión habilitada.
- [Art. 12, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-12/inciso-02.md): requisitos del nuevo consentimiento.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
