---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-162"
enunciado: "Antes de suspender a una entidad supervisada, la Agencia debe poner antecedentes en conocimiento de su autoridad regulatoria."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Comunicar antecedentes a autoridad regulatoria competente."
condicion_de_aplicacion: "Suspensión afectaría entidad sujeta a supervisión de organismo fiscalizador."
plazo: "previamente a suspensión"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 38, inc. 05, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-38/inciso-05.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 38, inc. 05: «la Agencia deberá previamente poner los antecedentes en conocimiento de la autoridad regulatoria»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Comunicación previa busca cautelar derechos de usuarios de entidad supervisada.

## Alcance de la regla

La regla se aplica a: Suspensión afectaría entidad sujeta a supervisión de organismo fiscalizador. Estado `Determinada`; carácter `Condicional`. Plazo o momento: previamente a suspensión.

## Anclajes y función

- [Art. 38, inc. 05](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-38/inciso-05.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
