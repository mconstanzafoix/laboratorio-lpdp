---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-012"
enunciado: "El responsable debe garantizar seguridad adecuada de los datos con medidas apropiadas al tratamiento y a su naturaleza."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Garantizar seguridad adecuada de los datos y adoptar medidas apropiadas al tratamiento y naturaleza de los datos."
condicion_de_aplicacion: "Tratamiento de datos personales."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. f, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-f.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. f: «el responsable debe garantizar estándares adecuados de seguridad»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El deber de garantizar seguridad y la adecuación de sus medidas integran una sola posición protectora. La misma letra menciona tratamiento no autorizado o ilícito, pérdida, filtración, daño accidental y destrucción como riesgos que delimitan el estándar.

## Alcance de la regla

Las medidas deben corresponder al tratamiento y a la naturaleza de los datos. La adecuación del estándar es abierta y requiere valoración; no se fija plazo ni delegación expresa. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. f](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-f.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.
