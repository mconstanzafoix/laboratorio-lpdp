---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-270"
enunciado: "El responsable debe garantizar que otras funciones del delegado no generen conflicto de intereses."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Evitar conflicto de intereses por funciones adicionales del delegado."
condicion_de_aplicacion: "Delegado ejerce otras funciones y cometidos."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 50, inc. 04, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-04-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 50, inc. 04, frag. 02: «El responsable garantizará que dichas funciones y cometidos no den lugar a conflicto de intereses»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El conflicto de intereses es concepto abierto y diferente de autonomía general.

## Alcance de la regla

La regla se aplica a: Delegado ejerce otras funciones y cometidos. Estado `Indeterminada`; carácter `Condicional`. No fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 50, inc. 04, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-50/inciso-04-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
