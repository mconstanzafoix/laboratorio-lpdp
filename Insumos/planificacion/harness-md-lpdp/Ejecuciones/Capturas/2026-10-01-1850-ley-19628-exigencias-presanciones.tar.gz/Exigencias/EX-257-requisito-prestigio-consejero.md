---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-257"
enunciado: "Los candidatos a consejero deben ser personas de reconocido prestigio profesional o académico en protección de datos."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Reunir requisito de prestigio profesional o académico en protección de datos."
condicion_de_aplicacion: "Candidatura a consejero del Consejo Directivo."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 quáter, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 quáter, inc. 03: «deberán ser personas de reconocido prestigio profesional o académico»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "prestigio profesional; prestigio académico"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La valoración de prestigio es abierta; se trata de requisito de elegibilidad.

## Alcance de la regla

La regla se aplica a: Candidatura a consejero del Consejo Directivo. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 30 quáter, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
