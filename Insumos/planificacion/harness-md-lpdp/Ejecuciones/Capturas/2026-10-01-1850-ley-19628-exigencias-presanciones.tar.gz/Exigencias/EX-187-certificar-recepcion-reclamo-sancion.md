---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-187"
enunciado: "La Agencia debe certificar la recepción del reclamo cuando el procedimiento sancionador deriva de una reclamación del titular."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Certificar recepción del reclamo."
condicion_de_aplicacion: "Procedimiento sancionador iniciado a consecuencia de reclamo del titular."
plazo: "al recibir reclamo"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 01, lit. b, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-b-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 42, inc. 01, lit. b, frag. 02: «se deberá certificar la recepción del reclamo»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La certificación fija la fecha relevante para la reclamación por tardanza de la letra l.

## Alcance de la regla

La regla se aplica a: Procedimiento sancionador iniciado a consecuencia de reclamo del titular. Estado `Determinada`; carácter `Condicional`. Plazo o momento: al recibir reclamo.

## Anclajes y función

- [Art. 42, inc. 01, lit. b, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-b-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
