---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-197"
enunciado: "La Agencia que verifica la infracción debe ponderar agravantes y atenuantes e imponer sanción según gravedad en la misma resolución."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Ponderar circunstancias e imponer sanción."
condicion_de_aplicacion: "Agencia considera verificada infracción."
plazo: "en la misma resolución"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 42, inc. 01, lit. j, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-j-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 42, inc. 01, lit. j, frag. 02: «ponderará las circunstancias que agravan o atenúan la responsabilidad»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La ponderación exige valoración de circunstancias y gravedad de la infracción.

## Alcance de la regla

La regla se aplica a: Agencia considera verificada infracción. Estado `Indeterminada`; carácter `Condicional`. Plazo o momento: en la misma resolución.

## Anclajes y función

- [Art. 42, inc. 01, lit. j, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-42/inciso-01-letra-j-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con tipificaciones de esta Fuente; el campo vacío no significa ausencia de tipificación.
