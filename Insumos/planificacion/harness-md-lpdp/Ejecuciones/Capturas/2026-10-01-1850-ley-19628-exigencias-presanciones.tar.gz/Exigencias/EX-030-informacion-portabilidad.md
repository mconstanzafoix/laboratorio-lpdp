---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-030"
enunciado: "El responsable debe informar al titular las medidas y características técnicas necesarias para obtener sus datos mediante portabilidad."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Comunicar al titular las medidas necesarias para obtener sus datos y las características técnicas de la operación de portabilidad."
condicion_de_aplicacion: "Ejercicio del derecho de portabilidad."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 9, inc. 3, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-09/inciso-03.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 9, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-09/inciso-01.md, derecho cuya operación se explica"
cita_textual_de_respaldo: "Art. 9, inc. 3: «El responsable también debe comunicar al titular de manera clara y precisa las medidas necesarias»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La comunicación de medidas y características técnicas es un deber informativo adicional, que puede cumplirse o incumplirse separadamente de poner a disposición la copia.

## Alcance de la regla

La comunicación debe ser clara y precisa y especificar ambas clases de información. La claridad y suficiencia requieren valoración; no hay plazo cuantificado ni delegación. El carácter es `Condicional` por el supuesto de ejercicio o cumplimiento. Se registra `Indeterminada` por las características del texto señaladas.

## Anclajes y función

- [Art. 9, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-09/inciso-03.md): principal: regla expresada.
- [Art. 9, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-09/inciso-01.md): derecho cuya operación se explica.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de los tipos infraccionales de esta Fuente y remisiones pertinentes. El vacío no significa ausencia de tipificación.
