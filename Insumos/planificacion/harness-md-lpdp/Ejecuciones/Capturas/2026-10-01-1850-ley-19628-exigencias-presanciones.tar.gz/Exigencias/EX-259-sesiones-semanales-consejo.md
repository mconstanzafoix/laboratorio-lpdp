---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-259"
enunciado: "El Consejo Directivo debe sesionar ordinariamente al menos una vez por semana y extraordinariamente cuando su presidente cite en los supuestos legales."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Celebrar sesiones ordinarias y extraordinarias."
condicion_de_aplicacion: "Funcionamiento del Consejo Directivo de la Agencia."
plazo: "ordinarias al menos semanalmente"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 30 quáter, inc. 08, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-08-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 30 quáter, inc. 08, frag. 01: «deberá celebrar sesiones ordinarias a lo menos una vez por semana»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "sesiones ordinarias; sesiones extraordinarias"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El consejo es órgano de la Agencia; sesiones extraordinarias responden a convocatoria o requerimiento escrito.

## Alcance de la regla

La regla se aplica a: Funcionamiento del Consejo Directivo de la Agencia. Estado `Determinada`; carácter `Condicional`. Plazo o momento: ordinarias al menos semanalmente.

## Anclajes y función

- [Art. 30 quáter, inc. 08, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-30-quáter/inciso-08-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen individual del régimen pertinente; el campo vacío no significa ausencia de tipificación.
