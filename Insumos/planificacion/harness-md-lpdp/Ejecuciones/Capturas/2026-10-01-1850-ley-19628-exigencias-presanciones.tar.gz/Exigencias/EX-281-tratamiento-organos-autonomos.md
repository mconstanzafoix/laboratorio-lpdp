---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-281"
enunciado: "Los órganos constitucionales y especiales enumerados pueden tratar datos sin consentimiento para sus funciones legales, dentro de competencia y con las reglas especiales aplicables."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Tratar datos personales sin consentimiento en órganos del Título VIII."
condicion_de_aplicacion: "Órgano enumerado, función legal y competencia, ley orgánica y Título IV aplicable con exclusiones expresas."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 54, inc. 01, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-54/inciso-01-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 54, inc. 01, frag. 01: «Es lícito el tratamiento de los datos personales que efectúan el Congreso Nacional»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "Congreso; Poder Judicial; Contraloría; Ministerio Público; Tribunal Constitucional; Banco Central; Servicio Electoral; Justicia Electoral; tribunales especiales"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Las leyes orgánicas de cada órgano son externas y no se afirma habilitación concreta; la regla general de licitud está en esta Fuente.

## Alcance de la regla

La regla se aplica a: Órgano enumerado, función legal y competencia, ley orgánica y Título IV aplicable con exclusiones expresas. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 54, inc. 01, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-54/inciso-01-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
