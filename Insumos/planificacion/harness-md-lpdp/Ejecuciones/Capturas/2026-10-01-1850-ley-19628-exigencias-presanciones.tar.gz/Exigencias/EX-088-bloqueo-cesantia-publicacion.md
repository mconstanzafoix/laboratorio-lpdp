---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-088"
enunciado: "Los responsables que administran bases de datos no pueden publicar ni comunicar las morosidades originadas durante la cesantía del deudor."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "Publicar o comunicar información del artículo 17 originada durante el período de cesantía."
condicion_de_aplicacion: "Información comprendida en el artículo 17, originada durante la cesantía del deudor y sujeta a los límites del inciso séptimo."
plazo: "durante el período de cesantía"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 17, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-17/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 17, inc. 03: «no podrán publicar o comunicar la información referida en el presente artículo»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

Se trata de un límite temporal y causal de la comunicación; incisos 4 a 7 regulan cómo opera el bloqueo.

## Alcance de la regla

La regla se aplica a: Información comprendida en el artículo 17, originada durante la cesantía del deudor y sujeta a los límites del inciso séptimo. Estado `Determinada`; carácter `Condicional`. Plazo o momento: durante el período de cesantía.

## Anclajes y función

- [Art. 17, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-17/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
