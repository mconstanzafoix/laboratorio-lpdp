---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-050"
enunciado: "El titular puede revocar en cualquier momento y sin causa su consentimiento, sin efecto retroactivo."
destinatario: "Titular"
modalidad: "Permiso condicionado"
conducta_exigida: "Revocar en cualquier momento y sin expresar causa el consentimiento dado para tratar sus datos."
condicion_de_aplicacion: "Consentimiento previo otorgado; utilización de medios similares o equivalentes a los empleados para otorgarlo."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 12, inc. 4, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-12/inciso-04.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 12, inc. 4: «El titular puede revocar el consentimiento otorgado en cualquier momento y sin expresión de causa»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso cuarto faculta al titular a retirar el consentimiento sin causa y en cualquier momento. La falta de retroactividad limita el efecto de la misma posición, sin crear una regla adicional.

## Alcance de la regla

La revocación usa medios similares o equivalentes al otorgamiento y no produce efectos retroactivos. No se fija plazo máximo ni delegación. El carácter es `Condicional` por el supuesto habilitante. Se registra `Determinada` por el grado de concreción indicado.

## Anclajes y función

- [Art. 12, inc. 4](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-12/inciso-04.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y remisiones pertinentes; el vacío no significa ausencia de tipificación.
