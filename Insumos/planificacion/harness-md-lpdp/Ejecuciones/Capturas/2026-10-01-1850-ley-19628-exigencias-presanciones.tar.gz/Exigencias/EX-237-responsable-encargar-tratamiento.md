---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-237"
enunciado: "El responsable puede tratar datos directamente o mediante un tercero mandatario o encargado."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Efectuar tratamiento por medio de encargado."
condicion_de_aplicacion: "Tratamiento conforme a esta ley y régimen contractual del art. 15 bis."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 15 bis, inc. 01, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-01-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 15 bis, inc. 01, frag. 01: «puede efectuar el tratamiento de datos en forma directa o a través de un tercero»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "tratamiento directo; por encargado"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El inciso permite externalizar operaciones sin transferir automáticamente la responsabilidad.

## Alcance de la regla

La regla se aplica a: Tratamiento conforme a esta ley y régimen contractual del art. 15 bis. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico.

## Anclajes y función

- [Art. 15 bis, inc. 01, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-15-bis/inciso-01-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual; el campo vacío no significa ausencia de tipificación.
