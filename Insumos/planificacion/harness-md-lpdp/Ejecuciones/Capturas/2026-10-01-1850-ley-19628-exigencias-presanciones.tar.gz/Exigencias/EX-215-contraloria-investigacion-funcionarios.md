---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-215"
enunciado: "La Contraloría debe iniciar investigación sumaria a petición de la Agencia si el procedimiento determina posibles responsabilidades individuales de funcionarios públicos."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Iniciar investigación sumaria o continuar en procedimiento ya iniciado."
condicion_de_aplicacion: "Procedimiento determina responsabilidades individuales y Agencia solicita actuación."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 45, inc. 01, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-45/inciso-01-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 45, inc. 01, frag. 01: «iniciará una investigación sumaria»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Contraloría es destinatario residual Tercero; el fragmento fija dos cauces según exista procedimiento iniciado.

## Alcance de la regla

La regla se aplica a: Procedimiento determina responsabilidades individuales y Agencia solicita actuación. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 45, inc. 01, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-45/inciso-01-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con el régimen de esta Fuente; el campo vacío no significa ausencia de tipificación.
