---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-201"
enunciado: "El reclamante debe interponer el reclamo judicial dentro de quince días hábiles desde la notificación de la resolución impugnada."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Interponer reclamo judicial dentro del plazo legal."
condicion_de_aplicacion: "Impugnación de resolución notificada de Agencia."
plazo: "quince días hábiles desde notificación"
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 43, inc. 01, frag. 02, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-fragmento-02.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 43, inc. 01, frag. 02: «deberá interponerse dentro de los quince días hábiles siguientes»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El plazo se adhiere al derecho del fragmento primero; se ficha como carga temporal procesal.

## Alcance de la regla

La regla se aplica a: Impugnación de resolución notificada de Agencia. Estado `Determinada`; carácter `Condicional`. Plazo o momento: quince días hábiles desde notificación.

## Anclajes y función

- [Art. 43, inc. 01, frag. 02](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-43/inciso-01-fragmento-02.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de examen negativo o positivo del régimen sancionador de esta Fuente; el campo vacío no significa ausencia de tipificación.
