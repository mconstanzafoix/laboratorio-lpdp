---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-016"
enunciado: "Guardar secreto o confidencialidad sobre los datos personales a los que accede."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Guardar secreto o confidencialidad sobre los datos personales a los que accede."
condicion_de_aplicacion: "Acceso a datos personales por el responsable; salvo datos hechos manifiestamente públicos por el titular, sin eximir datos derivados de su organización, clasificación o combinación; subsiste después de terminada la relación."
plazo: "Subsiste después de concluida la relación con el titular; duración final No determinada."
disposicion_de_anclaje: "Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. h, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-h.md, principal; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md, incorporación y contexto de principios; Ley 21.719 modificatoria, vigencia diferida 01-12-2026, Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md, incorporación y contexto de principios; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 bis reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-bis/inciso-01.md, delimitación del secreto o identificación del sujeto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 bis reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-bis/inciso-02.md, delimitación del secreto o identificación del sujeto"
cita_textual_de_respaldo: "Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. h: «El responsable de datos personales y quienes tengan acceso a ellos deberán guardar secreto o confidencialidad»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El texto principal dice «El responsable de datos personales y quienes tengan acceso a ellos deberán guardar secreto o confidencialidad». La letra h menciona expresamente al responsable. Se separa su posición de la de las demás personas con acceso porque el campo destinatario exige un sujeto único. El deber de controles es otra conducta.

## Alcance de la regla

El art. 14 bis reproducido exceptúa datos hechos manifiestamente públicos por el titular, protege los datos resultantes de acciones del responsable sobre datos públicos y no impide comunicaciones o cesiones legales ni el acceso e información de origen exigibles. La confidencialidad continúa tras concluir la relación con el titular. Su alcance concreto depende de los datos y accesos del caso. Es transversal y no fija un término final. La clasificación de la ficha es `Indeterminada` y el carácter es `Transversal` por las razones anteriores.

## Anclajes y función

- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, lit. h: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/letra-h.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, instrucción modificatoria: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 6, art. 3 reproducido de Ley 19.628, inc. 1: [incorporación y contexto de principios](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-06/articulo-reproducido-03/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

- Art. primero, num. 8, art. 14 bis reproducido de Ley 19.628, inc. 1: [delimitación del secreto o sujeto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-bis/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 8, art. 14 bis reproducido de Ley 19.628, inc. 2: [delimitación del secreto o sujeto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-bis/inciso-02.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` permanece vacío hasta comprobar el régimen sancionador pertinente de esta Fuente y sus remisiones expresas; no equivale a `0 No tipificada`.
