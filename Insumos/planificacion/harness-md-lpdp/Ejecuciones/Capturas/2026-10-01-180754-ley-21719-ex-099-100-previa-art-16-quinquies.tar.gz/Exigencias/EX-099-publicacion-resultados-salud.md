---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-099"
enunciado: "Los resultados de estudios e investigaciones con datos de salud o perfil biológico pueden publicarse o difundirse una vez anonimizados los datos que se publiquen."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Publicar o difundir resultados de estudios e investigaciones."
condicion_de_aplicacion: "Resultados de estudio o investigación que use datos de salud o perfil biológico Y anonimización previa de los datos publicados."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 bis reproducido de Ley 19.628, lit. c, frag. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16-bis/letra-c-fragmento-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 bis reproducido de Ley 19.628, lit. c, frag. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16-bis/letra-c-fragmento-03.md, condición de anonimización previa"
cita_textual_de_respaldo: "Art. 16 bis reproducido, letra c frags. 2–3: «pueden ser publicados o difundidos libremente»; «deberán previamente anonimizarse los datos que se publiquen»."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El fragmento segundo de la letra c permite publicar o difundir resultados; el tercero exige anonimización previa de los datos que se publiquen. La condición limita el permiso y además impone una conducta preparatoria autónoma, recogida en EX-100.

## Alcance de la regla

Los resultados deben proceder de estudios o investigaciones con datos de salud o perfil biológico **Y** los datos publicados han de estar anonimizados previamente. Publicar **O** difundir son alternativas de ejercicio. El texto no fija plazo; `Determinada`, carácter `Condicional`.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 bis reproducido de Ley 19.628, lit. c, frag. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16-bis/letra-c-fragmento-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 bis reproducido de Ley 19.628, lit. c, frag. 3: [condición de anonimización previa](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16-bis/letra-c-fragmento-03.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
