---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-100"
enunciado: "Antes de publicar resultados de estudios o investigaciones con datos de salud o perfil biológico, el responsable debe anonimizar los datos que se publiquen."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Anonimizar los datos personales incluidos en la publicación."
condicion_de_aplicacion: "Publicación de resultados de estudio o investigación que utiliza datos de salud o perfil biológico."
plazo: "Previamente a la publicación o difusión; sin cantidad de días."
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 bis reproducido de Ley 19.628, lit. c, frag. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16-bis/letra-c-fragmento-03.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 bis reproducido de Ley 19.628, lit. c, frag. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16-bis/letra-c-fragmento-02.md, publicación que activa anonimización"
cita_textual_de_respaldo: "Art. 16 bis reproducido, letra c frag. 3: «Para ello deberán previamente anonimizarse los datos que se publiquen»."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El fragmento tercero impone anonimización previa a la publicación del fragmento segundo. Puede incumplirse aunque se publique un resultado permitido; se mantiene ficha distinta del permiso.

## Alcance de la regla

Solo se anonimizan los datos que se publiquen, antes de hacerlo. No se afirma obligación de anonimizar todos los datos fuente del estudio. El alcance temporal y objeto son expresos: `Determinada`, carácter `Condicional`.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 bis reproducido de Ley 19.628, lit. c, frag. 3: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16-bis/letra-c-fragmento-03.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 16 bis reproducido de Ley 19.628, lit. c, frag. 2: [publicación que activa anonimización](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-16-bis/letra-c-fragmento-02.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; no implica ausencia de tipificación.
