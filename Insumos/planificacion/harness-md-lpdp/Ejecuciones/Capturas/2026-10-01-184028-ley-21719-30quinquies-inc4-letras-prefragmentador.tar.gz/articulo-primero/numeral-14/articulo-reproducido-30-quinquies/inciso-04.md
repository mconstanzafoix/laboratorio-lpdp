---
identificador: "Art. primero, num. 14, art. 30 quinquies reproducido de Ley 19.628, inc. 4"
fuente: "Ley 21.719 modificatoria, vigencia diferida desde 01-12-2026 (PDF BCN, última modificación impresa Ley 21.806, 05-02-2026)"
localizacion_y_version: "Fuentes-primarias/Ley-21719-2024/Ley-21719_13-DIC-2024.pdf, pág. 33; vigencia diferida desde 01-12-2026"
tipo_de_norma: "Constitutiva"
clasificacion_normativa_deontica: "No aplica — norma no regulativa"
control_ingreso: "PDF primario, columna normativa, pág. 33; literal y localizador cotejados: conforme"
remisiones: "Ninguna remisión expresa identificada en esta unidad"
---

# Art. primero, num. 14, art. 30 quinquies reproducido de Ley 19.628, inc. 4

- **Contexto:** [artículo del nivel inmediato](articulo.md); [instrucción modificatoria](../instruccion.md).

## Texto literal (bloque espejo)

> Adicionalmente, no podrá ser designado consejero:

## Análisis breve
El inciso introduce causales adicionales que impiden el nombramiento de consejero. Las letras siguientes especifican antecedentes penales, dependencia de drogas, sanciones recientes y vínculos empresariales recientes.

## Comprobación
Se cotejó esta unidad contra el PDF primario en la(s) página(s) 33: palabras, puntuación, comillas y localizador coinciden tras normalizar sólo espacios y saltos de maquetación. Se comprobó su posición en la secuencia completa del artículo y su enlace de contexto. No queda duda de cotejo textual en esta unidad.

## Tipo de norma
Constitutiva: «no podrá ser designado consejero» introduce impedimentos de elegibilidad desarrollados en las letras siguientes; su efecto es sobre el nombramiento.

## Clasificación deóntica
No aplica: la unidad es constitutiva de impedimentos de nombramiento; la prohibición recae en la designación bajo el estatuto del cargo.
