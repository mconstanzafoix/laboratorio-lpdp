---
identificador: "Art. primero, num. 14, art. 30 quinquies reproducido de Ley 19.628, lit. d"
fuente: "Ley 21.719 modificatoria, vigencia diferida desde 01-12-2026 (PDF BCN, última modificación impresa Ley 21.806, 05-02-2026)"
localizacion_y_version: "Fuentes-primarias/Ley-21719-2024/Ley-21719_13-DIC-2024.pdf, pág. 33; vigencia diferida desde 01-12-2026"
tipo_de_norma: "Constitutiva"
clasificacion_normativa_deontica: "No aplica — norma no regulativa"
control_ingreso: "PDF primario, columna normativa, pág. 33; literal y localizador cotejados: conforme"
remisiones: "Ninguna remisión expresa identificada en esta unidad"
---

# Art. primero, num. 14, art. 30 quinquies reproducido de Ley 19.628, lit. d

- **Contexto:** [artículo del nivel inmediato](articulo.md); [instrucción modificatoria](../instruccion.md).

## Texto literal (bloque espejo)

> d) Quienes, dentro del último año, hayan sido gerentes, delegados de datos, directores o hayan tenido participación en la propiedad de una empresa cuyo objeto o giro comercial verse sobre el tratamiento de datos personales.

## Análisis breve
La vinculación reciente con una empresa de tratamiento de datos impide el nombramiento: gerencia, delegación de datos, dirección o participación propietaria en el último año. El plazo mira al período anterior a la designación.

## Comprobación
Se cotejó esta unidad contra el PDF primario en la(s) página(s) 33: palabras, puntuación, comillas y localizador coinciden tras normalizar sólo espacios y saltos de maquetación. Se comprobó su posición en la secuencia completa del artículo y su enlace de contexto. No queda duda de cotejo textual en esta unidad.

## Tipo de norma
Constitutiva: esta letra concreta una causal del «no podrá ser designado consejero» del [inciso rector](inciso-04.md). El impedimento de nombramiento está en el inciso introductorio, no como mandato autónomo en la letra.

## Clasificación deóntica
No aplica: el tipo asignado es Constitutiva; se define un impedimento, causal, reemplazo o suplencia del cargo, sin fuerza deóntica local independiente.
