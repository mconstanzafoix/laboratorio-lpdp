---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-219"
enunciado: "Someter al órgano público a medidas de subsanación o prevención indicadas por la Agencia o a programas de cumplimiento o prevención."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Someter al órgano público a medidas de subsanación o prevención indicadas por la Agencia o a programas de cumplimiento o prevención."
condicion_de_aplicacion: "Agencia indica medidas O corresponde programa del art. 49."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 44 reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-44/inciso-02.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 44 reproducido de Ley 19.628, inc. 2: «Asimismo, los órganos públicos deberán someterse a las medidas tendientes a subsanar o prevenir infracciones que indique la Agencia o a los programas de cu…»"
estado_de_determinacion: "Delegada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. primero, num. 14, art. 44 reproducido de Ley 19.628, inc. 2 dice: «Asimismo, los órganos públicos deberán someterse a las medidas tendientes a subsanar o prevenir infracciones que indique la Agencia o a los programas de cumplimiento o de prevención de infracciones del artículo 49.». La Agencia concreta las medidas tendientes a subsanar o prevenir; el programa es la otra vía expresada. La posición corresponde a Tercero y expresa Obligación.

## Alcance de la regla

Supuesto: Agencia indica medidas O corresponde programa del art. 49. Plazo: sin plazo expreso para esta posición. El carácter es Condicional. La Agencia concreta las medidas indicadas expresamente; por eso el contenido se clasifica Delegada. Las alternativas descritas operan con O y los requisitos concurrentes con Y.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 44 reproducido de Ley 19.628, inc. 2: [anclaje principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-44/inciso-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, numeral 14: [instrucción incorporadora](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta conciliar los artículos 33 a 35 y, para órganos públicos, el art. 44; no se presume ausencia de tipificación.
