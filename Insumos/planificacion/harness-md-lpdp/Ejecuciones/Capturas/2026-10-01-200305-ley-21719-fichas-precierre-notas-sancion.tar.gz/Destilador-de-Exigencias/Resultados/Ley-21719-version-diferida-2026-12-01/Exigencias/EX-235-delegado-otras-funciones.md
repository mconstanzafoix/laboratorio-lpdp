---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-235"
enunciado: "El delegado puede desempeñar otras funciones procurando mantener la independencia de su función."
destinatario: "Delegado de protección de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Desempeñar otras funciones y cometidos."
condicion_de_aplicacion: "Se mantiene independencia de la función de protección de datos."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 50 reproducido de Ley 19.628, inc. 4, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-50/inciso-04-fragmento-01.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 50 reproducido de Ley 19.628, inc. 4, frag. 1: «El delegado de protección de datos podrá desempeñar otras funciones y cometidos, procurando mantener la independencia en su función.»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. primero, num. 14, art. 50 reproducido de Ley 19.628, inc. 4, frag. 1 expresa: «El delegado de protección de datos podrá desempeñar otras funciones y cometidos, procurando mantener la independencia en su función.». El mantenimiento de independencia es condición expresa, de valoración contextual. El destinatario se asigna a Delegado de protección de datos por el sujeto del enunciado; la modalidad es Permiso condicionado.

## Alcance de la regla

Supuesto: Se mantiene independencia de la función de protección de datos. Plazo: ninguno expresado. Carácter: Condicional. La aplicación requiere valorar el concepto abierto identificado y se clasifica Indeterminada. No se añade excepción no expresada.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 50 reproducido de Ley 19.628, inc. 4, frag. 1: [anclaje principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-50/inciso-04-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, numeral 14: [instrucción incorporadora](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta cotejo de los artículos sancionadores pertinentes y sus remisiones.
