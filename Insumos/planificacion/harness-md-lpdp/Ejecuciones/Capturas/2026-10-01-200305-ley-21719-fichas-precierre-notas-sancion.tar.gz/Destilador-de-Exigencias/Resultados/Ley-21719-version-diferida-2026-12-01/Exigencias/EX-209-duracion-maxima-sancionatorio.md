---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-209"
enunciado: "Concluir el procedimiento administrativo de infracción de ley dentro de seis meses."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Concluir el procedimiento administrativo de infracción de ley dentro de seis meses."
condicion_de_aplicacion: "Procedimiento administrativo de infracción iniciado."
plazo: "Máximo seis meses; hito inicial no explicitado en esta frase"
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. l, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-42/letra-l-fragmento-01.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. l, frag. 1: «l) El procedimiento administrativo de infracción de ley no podrá superar los seis meses.»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. l, frag. 1 expresa: «l) El procedimiento administrativo de infracción de ley no podrá superar los seis meses.». La posición se atribuye a Agencia y se clasifica como Obligación. El artículo fija máximo de duración, con consecuencia de reclamo tras seis meses desde certificación en letra l fragmento 2.

## Alcance de la regla

Procedimiento administrativo de infracción iniciado. Plazo: Máximo seis meses; hito inicial no explicitado en esta frase. Su carácter es Condicional. La regla requiere valoración de los conceptos o hitos abiertos indicados y se clasifica Indeterminada. No se identifica excepción adicional en esta unidad.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. l, frag. 1: [anclaje principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-42/letra-l-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, instrucción modificatoria del numeral 14: [incorporación del Título VII](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta conciliar esta posición con las tipificaciones de los artículos 33 a 34 quáter; el vacío no equivale a ausencia de sanción.
