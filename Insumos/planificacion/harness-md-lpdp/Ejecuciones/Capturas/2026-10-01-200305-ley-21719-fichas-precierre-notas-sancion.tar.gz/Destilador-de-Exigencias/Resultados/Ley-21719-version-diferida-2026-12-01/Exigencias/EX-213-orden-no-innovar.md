---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-213"
enunciado: "Decretar orden de no innovar sobre ejecución del acto impugnado."
destinatario: "Tercero"
modalidad: "Permiso condicionado"
conducta_exigida: "Decretar orden de no innovar sobre ejecución del acto impugnado."
condicion_de_aplicacion: "Ejecución del acto impugnado produce daño irreparable al recurrente."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 43 reproducido de Ley 19.628, lit. b, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-43/letra-b.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 43 reproducido de Ley 19.628, lit. b: «b) La Corte podrá declarar inadmisible la reclamación si el escrito no cumple con las condiciones señaladas en la letra a) anterior. Asimismo, podrá decretar or…»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. primero, num. 14, art. 43 reproducido de Ley 19.628, lit. b dice: «b) La Corte podrá declarar inadmisible la reclamación si el escrito no cumple con las condiciones señaladas en la letra a) anterior. Asimismo, podrá decretar orden de no innovar cuando la ejecución del acto impugnado le produzca un daño irreparable al recurrente.». El daño irreparable requiere valoración judicial. La posición corresponde a Tercero, en la modalidad Permiso condicionado.

## Alcance de la regla

Se activa bajo: Ejecución del acto impugnado produce daño irreparable al recurrente. Plazo: no se establece uno para esta posición. Su carácter es Condicional. El concepto abierto indicado exige valoración jurídica en el caso. Las condiciones y alternativas se aplican según el texto citado, sin agregar excepciones no escritas.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 43 reproducido de Ley 19.628, lit. b: [anclaje principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-43/letra-b.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, instrucción modificatoria del numeral 14: [incorporación del Título VII](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta cotejo del régimen sancionador; el vacío no significa ausencia de tipificación. La aplicación subsidiaria de los Códigos a aspectos procedimentales no regulados permanece localizada en art. 43 letra h.
