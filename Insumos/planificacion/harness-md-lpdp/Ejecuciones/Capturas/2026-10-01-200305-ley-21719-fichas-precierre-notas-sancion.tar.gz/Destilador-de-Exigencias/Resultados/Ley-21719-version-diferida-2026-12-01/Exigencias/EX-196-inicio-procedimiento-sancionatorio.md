---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-196"
enunciado: "Iniciar procedimiento sancionatorio de oficio o a petición de parte."
destinatario: "Agencia"
modalidad: "Permiso condicionado"
conducta_exigida: "Iniciar procedimiento sancionatorio de oficio o a petición de parte."
condicion_de_aplicacion: "Resultado de fiscalización O reclamación de titular bajo arts. 23 y 41."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. b, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-42/letra-b-fragmento-01.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. b, frag. 1: «b) La Agencia podrá iniciar un procedimiento sancionatorio, de oficio o a petición de parte, como resultado de un proceso de fiscalización o a consecuencia de u…»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. b, frag. 1 expresa: «b) La Agencia podrá iniciar un procedimiento sancionatorio, de oficio o a petición de parte, como resultado de un proceso de fiscalización o a consecuencia de una reclamación presentada por un titular de datos, en virtud del procedimiento establecido en los artículos 23 y 41 de esta ley.». La posición se atribuye a Agencia y se clasifica como Permiso condicionado. La Agencia puede iniciar de oficio o a petición de parte en los supuestos legales.

## Alcance de la regla

Resultado de fiscalización O reclamación de titular bajo arts. 23 y 41. Plazo: el texto no fija uno para esta posición. Su carácter es Condicional. La regla queda determinada por estos elementos expresos. No se identifica excepción adicional en esta unidad.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. b, frag. 1: [anclaje principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-42/letra-b-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, instrucción modificatoria del numeral 14: [incorporación del Título VII](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta conciliar esta posición con las tipificaciones de los artículos 33 a 34 quáter; el vacío no equivale a ausencia de sanción.
