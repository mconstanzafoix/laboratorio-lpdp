---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-215"
enunciado: "Ordenar traer autos en relación al vencer el término de prueba."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Ordenar traer autos en relación al vencer el término de prueba."
condicion_de_aplicacion: "Término de prueba vencido."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 43 reproducido de Ley 19.628, lit. e, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-43/letra-e.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 43 reproducido de Ley 19.628, lit. e: «e) Vencido el término de prueba, se ordenará traer los autos en relación. La vista de esta causa gozará de preferencia para su inclusión en la tabla.»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. primero, num. 14, art. 43 reproducido de Ley 19.628, lit. e dice: «e) Vencido el término de prueba, se ordenará traer los autos en relación. La vista de esta causa gozará de preferencia para su inclusión en la tabla.». El acto de dar estado de relación al proceso se expresa separadamente de la preferencia en tabla. La posición corresponde a Tercero, en la modalidad Obligación.

## Alcance de la regla

Se activa bajo: Término de prueba vencido. Plazo: no se establece uno para esta posición. Su carácter es Condicional. Los componentes esenciales de esta regla están fijados en la Fuente. Las condiciones y alternativas se aplican según el texto citado, sin agregar excepciones no escritas.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 43 reproducido de Ley 19.628, lit. e: [anclaje principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-43/letra-e.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, instrucción modificatoria del numeral 14: [incorporación del Título VII](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta cotejo del régimen sancionador; el vacío no significa ausencia de tipificación. La aplicación subsidiaria de los Códigos a aspectos procedimentales no regulados permanece localizada en art. 43 letra h.
