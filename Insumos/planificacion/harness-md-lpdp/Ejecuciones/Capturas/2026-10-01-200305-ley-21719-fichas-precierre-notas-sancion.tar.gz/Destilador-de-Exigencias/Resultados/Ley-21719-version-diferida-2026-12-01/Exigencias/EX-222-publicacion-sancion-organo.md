---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-222"
enunciado: "Publicar sanciones del art. 44 en el sitio web del órgano o servicio respectivo."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Publicar sanciones del art. 44 en el sitio web del órgano o servicio respectivo."
condicion_de_aplicacion: "Resolución sancionatoria pública queda firme."
plazo: "Cinco días hábiles desde firmeza de la resolución"
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 44 reproducido de Ley 19.628, inc. 9, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-44/inciso-09.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 44 reproducido de Ley 19.628, inc. 9: «Las sanciones previstas en este artículo deberán ser publicadas en el sitio web de la Agencia y del respectivo órgano o servicio dentro del plazo de cinco…»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. primero, num. 14, art. 44 reproducido de Ley 19.628, inc. 9 dice: «Las sanciones previstas en este artículo deberán ser publicadas en el sitio web de la Agencia y del respectivo órgano o servicio dentro del plazo de cinco días hábiles contado desde que la respectiva resolución quede firme.». El órgano o servicio tiene su propia publicación, distinta del sitio de Agencia. La posición corresponde a Tercero y expresa Obligación.

## Alcance de la regla

Supuesto: Resolución sancionatoria pública queda firme. Plazo: Cinco días hábiles desde firmeza de la resolución. El carácter es Condicional. Los componentes de la conducta están expresados en el texto y por ello la regla es Determinada. Las alternativas descritas operan con O y los requisitos concurrentes con Y.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 44 reproducido de Ley 19.628, inc. 9: [anclaje principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-44/inciso-09.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, numeral 14: [instrucción incorporadora](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta conciliar los artículos 33 a 35 y, para órganos públicos, el art. 44; no se presume ausencia de tipificación.
