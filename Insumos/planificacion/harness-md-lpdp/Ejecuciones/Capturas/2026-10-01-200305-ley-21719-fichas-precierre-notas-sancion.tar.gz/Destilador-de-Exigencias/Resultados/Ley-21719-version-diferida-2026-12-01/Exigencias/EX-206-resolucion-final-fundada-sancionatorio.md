---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-206"
enunciado: "Dictar resolución fundada que resuelva todas las cuestiones, alegaciones y defensas, y declare infracción o absolución."
destinatario: "Agencia"
modalidad: "Obligación"
conducta_exigida: "Dictar resolución fundada que resuelva todas las cuestiones, alegaciones y defensas, y declare infracción o absolución."
condicion_de_aplicacion: "Término del procedimiento sancionatorio."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. j, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-42/letra-j-fragmento-01.md, principal"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. j, frag. 1: «j) La resolución que ponga fin al procedimiento sancionatorio debe ser fundada y resolver todas las cuestiones planteadas en el expediente, pronunciándose sobre…»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. j, frag. 1 expresa: «j) La resolución que ponga fin al procedimiento sancionatorio debe ser fundada y resolver todas las cuestiones planteadas en el expediente, pronunciándose sobre cada una de las alegaciones y defensas formuladas por el responsable de datos y contendrá la declaración de haberse configurado el incumplimiento o vulneración de los principios, derechos y obligaciones establecidos en la ley por el responsable o su absolución, según corresponda.». La posición se atribuye a Agencia y se clasifica como Obligación. La resolución final debe tratar todas las cuestiones del expediente.

## Alcance de la regla

Término del procedimiento sancionatorio. Plazo: el texto no fija uno para esta posición. Su carácter es Condicional. La regla queda determinada por estos elementos expresos. No se identifica excepción adicional en esta unidad.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 42 reproducido de Ley 19.628, lit. j, frag. 1: [anclaje principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-42/letra-j-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, instrucción modificatoria del numeral 14: [incorporación del Título VII](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacía hasta conciliar esta posición con las tipificaciones de los artículos 33 a 34 quáter; el vacío no equivale a ausencia de sanción.
