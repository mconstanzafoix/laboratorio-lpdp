---
identificador: "Decreto-662-version-2026-09-09/EX-059"
enunciado: "Ante requerimiento de la Agencia, el delegado debe colaborar y disponer información íntegra y oportuna."
destinatario: "Delegado de protección de datos"
modalidad: "Obligación"
conducta_exigida: "colaborar y disponer información requerida por la Agencia"
condicion_de_aplicacion: "Agencia ejerce atribución del art. 30 bis letra c Ley N° 19.628"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 13, inc. 1, lit. k, frag. 2, PDF primario, pág. 8, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-k-fragmento-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 13, inc. 1, lit. k, frag. 1, PDF primario, pág. 8, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-k-fragmento-1.md, relación de contacto con Agencia"
cita_textual_de_respaldo: "Art. 13, inc. 1, lit. k, frag. 2: disponiendo de manera íntegra y oportuna la información"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

En Art. 13, inc. 1, lit. k, frag. 2 (PDF primario, pág. 8, versión única desde 09-SEP-2026) se lee «disponiendo de manera íntegra y oportuna la información». Este deber tiene un disparador específico y un objeto comprobable, por lo que no se agota en la función general de contacto. El artículo 19 contiene una obligación conexa en la supervisión de modelos certificados; ambas se cotejan transversalmente.

## Alcance de la regla

La información es la que requiera la Agencia en ejercicio de la atribución remitida. No se establece número de días para entregarla. El carácter condicional se sigue de ese supuesto. La determinación es indeterminada porque integridad y oportunidad de la información requieren valorar el requerimiento.

## Anclajes y función

- [Art. 13, inc. 1, lit. k, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-k-fragmento-2.md) — Decreto 662, versión 09-SEP-2026; PDF primario, pág. 8, versión única desde 09-SEP-2026; principal.
- [Art. 13, inc. 1, lit. k, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-k-fragmento-1.md) — Decreto 662, versión 09-SEP-2026; PDF primario, pág. 8, versión única desde 09-SEP-2026; relación de contacto con Agencia.

## Límites del análisis

La calificación de infracción está pendiente de cotejo fundado con la Ley N° 19.628 y las remisiones sancionadoras pertinentes. El campo sancionador vacío no significa ausencia de tipificación.
