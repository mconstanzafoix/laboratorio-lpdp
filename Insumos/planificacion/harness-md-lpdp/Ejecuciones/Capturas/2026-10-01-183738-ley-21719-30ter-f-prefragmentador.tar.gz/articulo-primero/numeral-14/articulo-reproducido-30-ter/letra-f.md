---
identificador: "Art. primero, num. 14, art. 30 ter reproducido de Ley 19.628, lit. f"
fuente: "Ley 21.719 modificatoria, vigencia diferida desde 01-12-2026 (PDF BCN, última modificación impresa Ley 21.806, 05-02-2026)"
localizacion_y_version: "Fuentes-primarias/Ley-21719-2024/Ley-21719_13-DIC-2024.pdf, pág. 32; vigencia diferida desde 01-12-2026"
tipo_de_norma: "Constitutiva"
clasificacion_normativa_deontica: "No aplica — norma no regulativa"
control_ingreso: "PDF primario, columna normativa, pág. 32; literal y localizador cotejados: conforme"
remisiones: "Ninguna remisión expresa identificada en esta unidad"
---

# Art. primero, num. 14, art. 30 ter reproducido de Ley 19.628, lit. f

- **Contexto:** [artículo del nivel inmediato](articulo.md); [instrucción modificatoria](../instruccion.md).

## Texto literal (bloque espejo)

> f) Elaborar, dentro del primer cuatrimestre de cada año, una cuenta pública anual en que se detalle el trabajo efectuado por la Agencia en el año inmediatamente anterior.

## Análisis breve
El Consejo prepara cada año, en sus primeros cuatro meses, una cuenta pública del trabajo del año anterior. El plazo y período de referencia delimitan esta función de rendición institucional.

## Comprobación
Se cotejó esta unidad contra el PDF primario en la(s) página(s) 32: palabras, puntuación, comillas y localizador coinciden tras normalizar sólo espacios y saltos de maquetación. Se comprobó su posición en la secuencia completa del artículo y su enlace de contexto. No queda duda de cotejo textual en esta unidad.

## Tipo de norma
Constitutiva: «Elaborar ... una cuenta pública anual» concreta una función del [inciso rector](inciso-01.md), con plazo propio.

## Clasificación deóntica
No aplica: el tipo asignado es Constitutiva y este campo se reserva a normas regulativas.
