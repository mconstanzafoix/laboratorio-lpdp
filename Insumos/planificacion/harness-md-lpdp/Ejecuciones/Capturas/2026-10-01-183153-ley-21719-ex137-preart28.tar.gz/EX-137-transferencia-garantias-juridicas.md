---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-137"
enunciado: "El responsable puede transferir datos al extranjero mediante cláusulas, normas corporativas vinculantes u otros instrumentos suscritos con el receptor que establezcan garantías adecuadas, si el tratamiento cumple los requisitos legales."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Transferir datos con protección jurídica acordada con el responsable o tercero mandatario receptor."
condicion_de_aplicacion: "Requisitos generales de licitud del tratamiento Y instrumento suscrito entre transmisor y receptor Y garantías adecuadas conforme al art. 28."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 27 reproducido de Ley 19.628, lit. b, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-27/letra-b.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 27 reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-27/inciso-01.md, habilitación y licitud previa; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 2, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-28/inciso-02-fragmento-01.md, contenido de garantías; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 2, frag. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-28/inciso-02-fragmento-02.md, modelo aprobado como vía posible; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 4, frag. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-28/inciso-04-fragmento-01.md, rama corporativa"
cita_textual_de_respaldo: "Art. primero, num. 13, art. 27 reproducido de Ley 19.628, lit. b: «b) Cuando la transferencia de datos quede amparada por cláusulas contractuales, normas corporativas vinculantes, u otros instrumentos jurídicos suscritos entre el responsable que e»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El texto «b) Cuando la transferencia de datos quede amparada por cláusulas contractuales, normas corporativas vinculantes, u otros instrumentos jurídicos suscritos entre el responsable que e» integra la habilitación de transferencia del artículo 27. Su posición corresponde al responsable que efectúa la operación. Esta vía posee condiciones propias, distintas de las demás vías del mismo artículo.

## Alcance de la regla

Requisitos generales de licitud del tratamiento Y instrumento suscrito entre transmisor y receptor Y garantías adecuadas conforme al art. 28. La equivalencia de principios, derechos y garantías y la efectividad de acciones del art. 28 inc. 2 exige valoración; una vía puede usar instrumentos aprobados por Agencia sin que esa aprobación sea necesaria para todos los instrumentos. El carácter es Condicional por los presupuestos expresos de la transferencia. No se fija plazo en esta unidad.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 27 reproducido de Ley 19.628, lit. b: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-27/letra-b.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 27 reproducido de Ley 19.628, inc. 1: [habilitación y licitud previa](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-27/inciso-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 2, frag. 1: [contenido de garantías](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-28/inciso-02-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 2, frag. 2: [modelo aprobado como vía posible](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-28/inciso-02-fragmento-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, art. 28 reproducido de Ley 19.628, inc. 4, frag. 1: [rama corporativa](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/articulo-reproducido-28/inciso-04-fragmento-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 13, instrucción modificatoria: [incorporación del Título V](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-13/instruccion.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y sus remisiones pertinentes; el vacío no supone ausencia de tipificación.
