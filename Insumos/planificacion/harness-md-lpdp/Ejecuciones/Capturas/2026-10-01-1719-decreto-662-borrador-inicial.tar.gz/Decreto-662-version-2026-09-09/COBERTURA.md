# Cobertura de destilación — Decreto supremo N° 662

Cuerpo: Decreto supremo N° 662 y reglamento aprobado; versión única desde 09-SEP-2026.

Entrada: [ARBOL.md](../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/ARBOL.md).

Nivel de autoridad humana: `Reglamentaria`, asignado por MCF el 01-10-2026 en [registro de decisión](../../../Ejecuciones/2026-10-01-orquestador-destilacion-tres-fuentes.md#decisión-humana-de-nivel-de-autoridad--01-10-2026-171217--03). Vigencia/versión separada de autoridad.

Último EX asignado: EX-038

| Artículo | Esperadas | Cerradas | Incompletas | Pendientes | Estado |
| --- | ---: | ---: | ---: | ---: | --- |
| [Acto aprobatorio](Articulos/acto-aprobatorio/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [Artículo 1](Articulos/articulo-01/RESULTADO.md) | 3 | 0 | 0 | 3 | Pendiente |
| [Artículo 2](Articulos/articulo-02/RESULTADO.md) | 2 | 0 | 0 | 2 | Pendiente |
| [Artículo 3](Articulos/articulo-03/RESULTADO.md) | 36 | 0 | 0 | 36 | Pendiente |
| [Artículo 4](Articulos/articulo-04/RESULTADO.md) | 3 | 0 | 0 | 3 | Pendiente |
| [Artículo 5](Articulos/articulo-05/RESULTADO.md) | 3 | 0 | 0 | 3 | Pendiente |
| [Artículo 6](Articulos/articulo-06/RESULTADO.md) | 3 | 0 | 0 | 3 | Pendiente |
| [Artículo 7](Articulos/articulo-07/RESULTADO.md) | 4 | 0 | 0 | 4 | Pendiente |
| [Artículo 8](Articulos/articulo-08/RESULTADO.md) | 6 | 0 | 0 | 6 | Pendiente |
| [Artículo 9](Articulos/articulo-09/RESULTADO.md) | 4 | 0 | 0 | 4 | Pendiente |
| [Artículo 10](Articulos/articulo-10/RESULTADO.md) | 3 | 0 | 0 | 3 | Pendiente |
| [Artículo 11](Articulos/articulo-11/RESULTADO.md) | 4 | 0 | 0 | 4 | Pendiente |
| [Artículo 12](Articulos/articulo-12/RESULTADO.md) | 1 | 0 | 0 | 1 | Pendiente |
| [Artículo 13](Articulos/articulo-13/RESULTADO.md) | 22 | 0 | 0 | 22 | Pendiente |
| [Artículo 14](Articulos/articulo-14/RESULTADO.md) | 2 | 0 | 0 | 2 | Pendiente |
| [Artículo 15](Articulos/articulo-15/RESULTADO.md) | 6 | 0 | 0 | 6 | Pendiente |
| [Artículo 16](Articulos/articulo-16/RESULTADO.md) | 10 | 0 | 0 | 10 | Pendiente |
| [Artículo 17](Articulos/articulo-17/RESULTADO.md) | 5 | 0 | 0 | 5 | Pendiente |
| [Artículo 18](Articulos/articulo-18/RESULTADO.md) | 2 | 0 | 0 | 2 | Pendiente |
| [Artículo 19](Articulos/articulo-19/RESULTADO.md) | 6 | 0 | 0 | 6 | Pendiente |
| [Artículo 20](Articulos/articulo-20/RESULTADO.md) | 6 | 0 | 0 | 6 | Pendiente |

Verificación de cobertura: pendiente de cotejo final contra ARBOL.md y disco.
