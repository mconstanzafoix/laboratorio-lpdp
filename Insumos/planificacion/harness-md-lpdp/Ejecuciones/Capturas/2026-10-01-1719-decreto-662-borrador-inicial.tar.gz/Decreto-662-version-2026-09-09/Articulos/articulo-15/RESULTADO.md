# Resultado de destilación — Artículo 15

Fuente: Decreto supremo N° 662, versión única desde 09-SEP-2026. Estado: Propuesta pendiente de comprobación técnica.

| Disposición | Resultado de destilación | Exigencias originadas | Exigencias apoyadas y función | Motivo breve |
| --- | --- | --- | --- | --- |
| [Art. 15, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-15/inciso-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 15, inc. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-15/inciso-2-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 15, inc. 2, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-15/inciso-2-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 15, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-15/inciso-3.md) | Pendiente | — | — | Sin examinar |
| [Art. 15, inc. 4, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-15/inciso-4-fragmento-01.md) | Pendiente | — | — | Sin examinar |
| [Art. 15, inc. 4, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-15/inciso-4-fragmento-02.md) | Pendiente | — | — | Sin examinar |
