# Resultado de destilación — Artículo 11

Fuente: Decreto supremo N° 662, versión única desde 09-SEP-2026. Estado: Propuesta pendiente de comprobación técnica.

| Disposición | Resultado de destilación | Exigencias originadas | Exigencias apoyadas y función | Motivo breve |
| --- | --- | --- | --- | --- |
| [Art. 11, inc. 1, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-11/inciso-1-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 11, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-11/inciso-1-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 11, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-11/inciso-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 11, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-11/inciso-3.md) | Pendiente | — | — | Sin examinar |
