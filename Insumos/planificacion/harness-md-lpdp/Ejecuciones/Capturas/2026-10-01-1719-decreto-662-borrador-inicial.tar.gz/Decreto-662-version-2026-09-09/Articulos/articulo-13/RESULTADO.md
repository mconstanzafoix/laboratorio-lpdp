# Resultado de destilación — Artículo 13

Fuente: Decreto supremo N° 662, versión única desde 09-SEP-2026. Estado: Propuesta pendiente de comprobación técnica.

| Disposición | Resultado de destilación | Exigencias originadas | Exigencias apoyadas y función | Motivo breve |
| --- | --- | --- | --- | --- |
| [Art. 13, inc. 1, enunciado](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/enunciado.md) | Examinada con Exigencias | — | [Decreto-662-version-2026-09-09/EX-022](../../Exigencias/EX-022-ejercer-atribuciones-legales-y-reglamentarias-respecto-de.md) (introduce funciones del delegado) | Apoya: introduce funciones del delegado. |
| [Art. 13, inc. 1, lit. a, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-a-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. a, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-a-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. b, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-b-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. b, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-b-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. b, frag. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-b-fragmento-3.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. c](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-c.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-d.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. e](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-e.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. f, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-f-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. f, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-f-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. g](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-g.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. h](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-h.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. i, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-i-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. i, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-i-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. j](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-j.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. j, párr. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-j-parrafo-2-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. j, párr. 2, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-j-parrafo-2-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. k, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-k-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. 1, lit. k, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/letra-k-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. final, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/inciso-final-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 13, inc. final, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/inciso-final-fragmento-2.md) | Pendiente | — | — | Sin examinar |
