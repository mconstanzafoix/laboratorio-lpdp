# Resultado de destilación — Artículo 16

Fuente: Decreto supremo N° 662, versión única desde 09-SEP-2026. Estado: Propuesta pendiente de comprobación técnica.

| Disposición | Resultado de destilación | Exigencias originadas | Exigencias apoyadas y función | Motivo breve |
| --- | --- | --- | --- | --- |
| [Art. 16, inc. 1, enunciado](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/enunciado.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 1, lit. a](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/letra-a.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/letra-b.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 1, lit. c](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/letra-c.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/letra-d.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 1, lit. e, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/letra-e-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 1, lit. e, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/letra-e-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/inciso-2-fragmento-1.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 2, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/inciso-2-fragmento-2.md) | Pendiente | — | — | Sin examinar |
| [Art. 16, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-16/inciso-3.md) | Pendiente | — | — | Sin examinar |
