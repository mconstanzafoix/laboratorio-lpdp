# Resultado de destilación — Artículo 6

Fuente: Decreto supremo N° 662, versión única desde 09-SEP-2026. Estado: Propuesta pendiente de comprobación técnica.

| Disposición | Resultado de destilación | Exigencias originadas | Exigencias apoyadas y función | Motivo breve |
| --- | --- | --- | --- | --- |
| [Art. 6, inc. 1, frag. 1.1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-1-fragmento-01.md) | Examinada con Exigencias | [Decreto-662-version-2026-09-09/EX-020](../../Exigencias/EX-020-designar-un-delegado-de-proteccion-de-datos.md) | — | Origina la regla descrita. |
| [Art. 6, inc. 1, frag. 1.2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-1-fragmento-02.md) | Examinada con Exigencias | [Decreto-662-version-2026-09-09/EX-021](../../Exigencias/EX-021-designar-delegado-de-proteccion-de-datos.md) | — | Origina la regla descrita. |
| [Art. 6, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-2.md) | Examinada con Exigencias | [Decreto-662-version-2026-09-09/EX-022](../../Exigencias/EX-022-ejercer-atribuciones-legales-y-reglamentarias-respecto-de.md) | — | Origina la regla descrita. |
