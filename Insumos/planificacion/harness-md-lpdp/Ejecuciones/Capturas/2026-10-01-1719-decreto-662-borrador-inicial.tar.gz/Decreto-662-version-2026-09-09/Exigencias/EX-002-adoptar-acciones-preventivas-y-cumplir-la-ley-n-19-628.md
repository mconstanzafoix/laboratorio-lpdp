---
identificador: "Decreto-662-version-2026-09-09/EX-002"
enunciado: "Todos los responsables deben prevenir infracciones y cumplir la Ley N° 19.628 aunque adopten un programa."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "adoptar acciones preventivas y cumplir la Ley N° 19.628"
condicion_de_aplicacion: "Con o sin adopción de programa"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 1, inc. 3, PDF primario, pág. 2, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-01/inciso-3.md, principal"
cita_textual_de_respaldo: "Art. 1, inc. 3: La adopción e implementación de un programa de cumplimiento no obstará al deber de todos los responsables de datos de adoptar acciones destinadas a prevenir la comisión de las infracciones establecidas en la ley N° 19.628 y, en…"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 1, inc. 3, PDF primario, pág. 2, versión única desde 09-SEP-2026, expresa «La adopción e implementación de un programa de cumplimiento no obstará al deber de todos los responsables de datos de adoptar acciones destinadas a prevenir la comisión de las infracciones establecidas en la ley N° 19.628 y, en…». La posición se atribuye a Responsable de datos y se formula como obligación: adoptar acciones preventivas y cumplir la Ley N° 19.628. El programa no sustituye esta obligación general.

## Alcance de la regla

Supuesto y condiciones: Con o sin adopción de programa. No se fija plazo expreso en esta regla. El carácter es transversal según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque la expresión acciones destinadas a prevenir requiere concreción según el tratamiento.

## Anclajes y función

- [Art. 1, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-01/inciso-3.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 2, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
