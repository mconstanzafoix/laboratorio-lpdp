---
identificador: "Decreto-662-version-2026-09-09/EX-011"
enunciado: "El programa debe contemplar mecanismos de reporte externo y de autodenuncia en los supuestos legales pertinentes."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "contemplar mecanismos de reporte a autoridad o titulares y de autodenuncia"
condicion_de_aplicacion: "Si adopta programa; reporte a autoridad O titulares según corresponda"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. g, párr. 2, frag. 1, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-parrafo-2-fragmento-1.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. g, párr. 2, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-parrafo-2-fragmento-2.md, delegación de mecanismo por Instrucción General"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. g, párr. 2, frag. 1: Asimismo, el programa deberá contemplar los mecanismos de reporte a la autoridad de protección de datos o a los titulares de datos, en su caso, para dar cumplimiento al deber establecido en el artículo 14 sexies de la ley N°…"
estado_de_determinacion: "Delegada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. g, párr. 2, frag. 1, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «Asimismo, el programa deberá contemplar los mecanismos de reporte a la autoridad de protección de datos o a los titulares de datos, en su caso, para dar cumplimiento al deber establecido en el artículo 14 sexies de la ley N°…». La posición se atribuye a Responsable de datos y se formula como obligación: contemplar mecanismos de reporte a autoridad o titulares y de autodenuncia. La obligación recae en el contenido del programa; los deberes sustantivos de comunicar de la Ley N° 19.628 son contexto y no se duplican aquí.

## Alcance de la regla

Supuesto y condiciones: Si adopta programa; reporte a autoridad O titulares según corresponda. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Delegada se justifica porque el art. 3 letra g autoriza expresamente a la Agencia a fijar por Instrucción General el mecanismo de esas comunicaciones.

## Anclajes y función

- [Art. 3, inc. 1, lit. g, párr. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-parrafo-2-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. g, párr. 2, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-parrafo-2-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; delegación de mecanismo por Instrucción General.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
