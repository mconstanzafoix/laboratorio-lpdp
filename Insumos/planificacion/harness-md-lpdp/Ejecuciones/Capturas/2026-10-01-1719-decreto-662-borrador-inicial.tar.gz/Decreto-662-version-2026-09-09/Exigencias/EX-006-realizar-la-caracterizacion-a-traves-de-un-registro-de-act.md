---
identificador: "Decreto-662-version-2026-09-09/EX-006"
enunciado: "El responsable puede realizar la caracterización mediante un registro de actividades de tratamiento."
destinatario: "Responsable de datos"
modalidad: "Permiso"
conducta_exigida: "realizar la caracterización a través de un registro de actividades"
condicion_de_aplicacion: "Si caracteriza las actividades de tratamiento"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, párr. final, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-parrafo-final.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, frag. 1, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-fragmento-1.md, objeto de la caracterización"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. d, párr. final: Esta caracterización podrá realizarse a través de un registro de actividades de tratamiento."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. d, párr. final, PDF primario, pág. 3, versión única desde 09-SEP-2026, expresa «Esta caracterización podrá realizarse a través de un registro de actividades de tratamiento.». La posición se atribuye a Responsable de datos y se formula como permiso: realizar la caracterización a través de un registro de actividades. El registro es una vía permitida para cumplir la caracterización; no sustituye la información mínima.

## Alcance de la regla

Supuesto y condiciones: Si caracteriza las actividades de tratamiento. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 3, inc. 1, lit. d, párr. final](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-parrafo-final.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. d, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; objeto de la caracterización.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
