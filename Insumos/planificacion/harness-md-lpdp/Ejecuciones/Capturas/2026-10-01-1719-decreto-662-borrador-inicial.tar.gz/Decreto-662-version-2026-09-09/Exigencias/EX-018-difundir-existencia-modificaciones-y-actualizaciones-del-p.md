---
identificador: "Decreto-662-version-2026-09-09/EX-018"
enunciado: "El responsable debe difundir la existencia y las modificaciones del programa a trabajadores, empleados y prestadores."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "difundir existencia, modificaciones y actualizaciones del programa"
condicion_de_aplicacion: "Programa adoptado; modificaciones o actualizaciones cuando existan"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 5, inc. 1, frag. 1, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-05/inciso-1-fragmento-1.md, principal; Decreto 662, versión 09-SEP-2026, Art. 5, inc. 1, frag. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-05/inciso-1-fragmento-2.md, extiende difusión a modificaciones"
cita_textual_de_respaldo: "Art. 5, inc. 1, frag. 1: El responsable deberá difundir la existencia del programa de cumplimiento entre los trabajadores, empleados y prestadores de servicios de la entidad."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 5, inc. 1, frag. 1, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «El responsable deberá difundir la existencia del programa de cumplimiento entre los trabajadores, empleados y prestadores de servicios de la entidad.». La posición se atribuye a Responsable de datos y se formula como obligación: difundir existencia, modificaciones y actualizaciones del programa. La segunda frase extiende la misma obligación de difusión, sin crear un destinatario ni medio distinto.

## Alcance de la regla

Supuesto y condiciones: Programa adoptado; modificaciones o actualizaciones cuando existan. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 5, inc. 1, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-05/inciso-1-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.
- [Art. 5, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-05/inciso-1-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; extiende difusión a modificaciones.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
