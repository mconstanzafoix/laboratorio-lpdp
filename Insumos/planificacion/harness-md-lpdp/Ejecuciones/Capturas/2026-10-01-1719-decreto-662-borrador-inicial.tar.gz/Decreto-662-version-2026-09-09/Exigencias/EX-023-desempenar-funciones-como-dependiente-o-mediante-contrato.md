---
identificador: "Decreto-662-version-2026-09-09/EX-023"
enunciado: "El delegado puede actuar como dependiente o mediante contrato de prestación de servicios."
destinatario: "Delegado de protección de datos"
modalidad: "Permiso"
conducta_exigida: "desempeñar funciones como dependiente o mediante contrato de servicios"
condicion_de_aplicacion: ""
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 7, inc. 1, frag. 1, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-07/inciso-1-fragmento-1.md, principal"
cita_textual_de_respaldo: "Art. 7, inc. 1, frag. 1: El delegado de protección de datos podrá tener la calidad de dependiente del responsable del tratamiento, o desempeñar sus funciones en el marco de un contrato de prestación de servicios con una persona natural o jurídica."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 7, inc. 1, frag. 1, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «El delegado de protección de datos podrá tener la calidad de dependiente del responsable del tratamiento, o desempeñar sus funciones en el marco de un contrato de prestación de servicios con una persona natural o jurídica.». La posición se atribuye a Delegado de protección de datos y se formula como permiso: desempeñar funciones como dependiente o mediante contrato de servicios. Las alternativas son formas de vinculación permitidas, no deberes acumulativos.

## Alcance de la regla

Supuesto y condiciones: el supuesto descrito por la Disposición principal, sin requisito especial adicional expreso. No se fija plazo expreso en esta regla. El carácter es transversal según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 7, inc. 1, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-07/inciso-1-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
