---
identificador: "Decreto-662-version-2026-09-09/EX-020"
enunciado: "El responsable puede designar un delegado de protección de datos."
destinatario: "Responsable de datos"
modalidad: "Permiso"
conducta_exigida: "designar un delegado de protección de datos"
condicion_de_aplicacion: ""
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 6, inc. 1, frag. 1.1, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-1-fragmento-01.md, principal"
cita_textual_de_respaldo: "Art. 6, inc. 1, frag. 1.1: El responsable de datos podrá designar un delegado de protección de datos personales,"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 6, inc. 1, frag. 1.1, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «El responsable de datos podrá designar un delegado de protección de datos personales,». La posición se atribuye a Responsable de datos y se formula como permiso: designar un delegado de protección de datos. La regla general de designación se lee con la obligación específica de la hoja siguiente.

## Alcance de la regla

Supuesto y condiciones: el supuesto descrito por la Disposición principal, sin requisito especial adicional expreso. No se fija plazo expreso en esta regla. El carácter es transversal según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 6, inc. 1, frag. 1.1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-1-fragmento-01.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
