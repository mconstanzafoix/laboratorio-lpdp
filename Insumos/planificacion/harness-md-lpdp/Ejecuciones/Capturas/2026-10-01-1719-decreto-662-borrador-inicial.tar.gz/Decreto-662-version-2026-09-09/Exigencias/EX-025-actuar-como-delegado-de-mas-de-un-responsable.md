---
identificador: "Decreto-662-version-2026-09-09/EX-025"
enunciado: "Una persona natural puede ser delegado de varios responsables si cumple los requisitos legales y reglamentarios."
destinatario: "Delegado de protección de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "actuar como delegado de más de un responsable"
condicion_de_aplicacion: "Cumple requisitos de Ley N° 19.628 Y de este reglamento"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 7, inc. 1, frag. 3, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-07/inciso-1-fragmento-3.md, principal"
cita_textual_de_respaldo: "Art. 7, inc. 1, frag. 3: Una misma persona natural podrá actuar como delegado de protección de datos de más de un responsable, siempre que cumpla con los requisitos que establece la ley N° 19.628 y este reglamento."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 7, inc. 1, frag. 3, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «Una misma persona natural podrá actuar como delegado de protección de datos de más de un responsable, siempre que cumpla con los requisitos que establece la ley N° 19.628 y este reglamento.». La posición se atribuye a Delegado de protección de datos y se formula como permiso condicionado: actuar como delegado de más de un responsable. La multiplicidad de mandantes depende del cumplimiento de requisitos; el detalle de remisiones legales queda como contexto.

## Alcance de la regla

Supuesto y condiciones: Cumple requisitos de Ley N° 19.628 Y de este reglamento. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 7, inc. 1, frag. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-07/inciso-1-fragmento-3.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
