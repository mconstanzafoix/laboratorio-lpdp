---
identificador: "Decreto-662-version-2026-09-09/EX-031"
enunciado: "Entidades vinculadas pueden designar un delegado único si comparten estándares y este es accesible en condiciones similares."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "designar un delegado único para entidades vinculadas"
condicion_de_aplicacion: "Mismo grupo empresarial O empresas relacionadas O mismo controlador; Y estándares y políticas comunes Y accesibilidad similar"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 8, inc. 4, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-4.md, principal"
cita_textual_de_respaldo: "Art. 8, inc. 4: Las sociedades o entidades que pertenezcan a un mismo grupo empresarial, empresas relacionadas o sujetas a un mismo controlador en los términos previstos en la Ley de Mercado de Valores, podrán designar un único delegado de…"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "mismo grupo empresarial; empresas relacionadas; mismo controlador"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 8, inc. 4, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «Las sociedades o entidades que pertenezcan a un mismo grupo empresarial, empresas relacionadas o sujetas a un mismo controlador en los términos previstos en la Ley de Mercado de Valores, podrán designar un único delegado de…». La posición se atribuye a Responsable de datos y se formula como permiso condicionado: designar un delegado único para entidades vinculadas. Las categorías de vínculo son alternativas; las condiciones operativas son acumulativas.

## Alcance de la regla

Supuesto y condiciones: Mismo grupo empresarial O empresas relacionadas O mismo controlador; Y estándares y políticas comunes Y accesibilidad similar. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque accesibilidad en condiciones similares requiere apreciación de hechos.

## Anclajes y función

- [Art. 8, inc. 4](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-4.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
