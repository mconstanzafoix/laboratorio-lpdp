---
identificador: "Decreto-662-version-2026-09-09/EX-021"
enunciado: "La designación de delegado es obligatoria en la adopción y certificación del programa de cumplimiento."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "designar delegado de protección de datos"
condicion_de_aplicacion: "Adopción Y certificación de programa de cumplimiento"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 6, inc. 1, frag. 1.2, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-1-fragmento-02.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. b, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-b.md, componente obligatorio del programa"
cita_textual_de_respaldo: "Art. 6, inc. 1, frag. 1.2: designación que será obligatoria en el marco de la adopción y certificación de un programa de cumplimiento."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 6, inc. 1, frag. 1.2, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «designación que será obligatoria en el marco de la adopción y certificación de un programa de cumplimiento.». La posición se atribuye a Responsable de datos y se formula como obligación: designar delegado de protección de datos. El deber tiene un supuesto específico y no elimina el permiso general de designar delegado.

## Alcance de la regla

Supuesto y condiciones: Adopción Y certificación de programa de cumplimiento. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 6, inc. 1, frag. 1.2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-1-fragmento-02.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-b.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; componente obligatorio del programa.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
