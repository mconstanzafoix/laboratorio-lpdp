---
identificador: "Decreto-662-version-2026-09-09/EX-019"
enunciado: "El responsable solo puede publicitar la certificación mediante referencia directa al Registro Nacional de Sanciones y Cumplimiento."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "publicitar o informar certificación por referencia directa, pura y simple al Registro"
condicion_de_aplicacion: "Programa certificado Y referencia directa, pura y simple al Registro"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 5, inc. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-05/inciso-2.md, principal"
cita_textual_de_respaldo: "Art. 5, inc. 2: El responsable solo podrá publicitar e informar que su programa de cumplimiento está certificado mediante la referencia directa, pura y simple al Registro Nacional de Sanciones y Cumplimiento que administrará la Agencia de…"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 5, inc. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «El responsable solo podrá publicitar e informar que su programa de cumplimiento está certificado mediante la referencia directa, pura y simple al Registro Nacional de Sanciones y Cumplimiento que administrará la Agencia de…». La posición se atribuye a Responsable de datos y se formula como permiso condicionado: publicitar o informar certificación por referencia directa, pura y simple al Registro. La limitación de la forma publicitaria acompaña la habilitación para anunciar la certificación.

## Alcance de la regla

Supuesto y condiciones: Programa certificado Y referencia directa, pura y simple al Registro. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 5, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-05/inciso-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
