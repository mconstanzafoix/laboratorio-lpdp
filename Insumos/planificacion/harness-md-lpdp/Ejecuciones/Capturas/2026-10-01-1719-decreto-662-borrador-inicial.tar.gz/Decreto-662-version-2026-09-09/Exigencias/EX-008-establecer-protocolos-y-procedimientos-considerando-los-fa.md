---
identificador: "Decreto-662-version-2026-09-09/EX-008"
enunciado: "Los protocolos deben fijarse considerando operaciones, datos, riesgos, tamaño y capacidad económica."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "establecer protocolos y procedimientos considerando los factores expresos"
condicion_de_aplicacion: "Si establece protocolos del programa"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. f, párr. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-f-parrafo-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. f, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-f.md, define protocolos específicos"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. f, párr. 2: Dichos protocolos, reglas y procedimientos específicos deberán establecerse teniendo especialmente en cuenta las operaciones de tratamiento que el responsable realice, la cantidad y el tipo de datos personales que trate y los…"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. f, párr. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «Dichos protocolos, reglas y procedimientos específicos deberán establecerse teniendo especialmente en cuenta las operaciones de tratamiento que el responsable realice, la cantidad y el tipo de datos personales que trate y los…». La posición se atribuye a Responsable de datos y se formula como obligación: establecer protocolos y procedimientos considerando los factores expresos. Esta frase determina cómo configurar el componente del programa previsto en la letra f).

## Alcance de la regla

Supuesto y condiciones: Si establece protocolos del programa. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque tener especialmente en cuenta y ponderar riesgos y capacidad exige valoración.

## Anclajes y función

- [Art. 3, inc. 1, lit. f, párr. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-f-parrafo-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. f](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-f.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; define protocolos específicos.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
