---
identificador: "Decreto-662-version-2026-09-09/EX-007"
enunciado: "El responsable debe identificar las actividades de mayor riesgo e incorporarlas en una matriz que considere la graduación de sanciones."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "determinar actividades de mayor riesgo e incorporarlas en matriz de riesgos"
condicion_de_aplicacion: "A partir de actividades o procesos de tratamiento identificados"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. e, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-e-fragmento-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. e, frag. 1, PDF primario, pág. 3,4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-e-fragmento-1.md, identifica actividades de riesgo; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. e, frag. 3, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-e-fragmento-3.md, criterio de desarrollo de matriz"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. e, frag. 2: A partir de las actividades o procesos de tratamiento identificadas, el responsable deberá determinar aquellas que presentan un mayor riesgo de incurrir en infracciones, incorporándolas en la respectiva matriz de riesgos."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. e, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «A partir de las actividades o procesos de tratamiento identificadas, el responsable deberá determinar aquellas que presentan un mayor riesgo de incurrir en infracciones, incorporándolas en la respectiva matriz de riesgos.». La posición se atribuye a Responsable de datos y se formula como obligación: determinar actividades de mayor riesgo e incorporarlas en matriz de riesgos. La determinación y la matriz son etapas de la misma posición de gestión del riesgo.

## Alcance de la regla

Supuesto y condiciones: A partir de actividades o procesos de tratamiento identificados. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque mayor riesgo requiere valoración concreta de actividades y sanciones.

## Anclajes y función

- [Art. 3, inc. 1, lit. e, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-e-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. e, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-e-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3,4, versión única desde 09-SEP-2026; identifica actividades de riesgo.
- [Art. 3, inc. 1, lit. e, frag. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-e-fragmento-3.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; criterio de desarrollo de matriz.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
