---
identificador: "Decreto-662-version-2026-09-09/EX-012"
enunciado: "El programa de un organismo público debe indicar las sanciones legales aplicables a sus funcionarios o dependientes."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "indicar sanciones legales aplicables a funcionarios o dependientes"
condicion_de_aplicacion: "Responsable es organismo público Y adopta programa"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. h, párr. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-h-parrafo-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. h, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-h.md, componente de sanciones internas"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. h, párr. 2: En el caso de los organismos públicos, el programa deberá indicar las sanciones que la ley declara aplicables a los funcionarios o dependientes de dicho organismo."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. h, párr. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «En el caso de los organismos públicos, el programa deberá indicar las sanciones que la ley declara aplicables a los funcionarios o dependientes de dicho organismo.». La posición se atribuye a Responsable de datos y se formula como obligación: indicar sanciones legales aplicables a funcionarios o dependientes. Este deber específico no crea sanciones nuevas; identifica las previstas por la ley.

## Alcance de la regla

Supuesto y condiciones: Responsable es organismo público Y adopta programa. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 3, inc. 1, lit. h, párr. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-h-parrafo-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. h](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-h.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; componente de sanciones internas.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
