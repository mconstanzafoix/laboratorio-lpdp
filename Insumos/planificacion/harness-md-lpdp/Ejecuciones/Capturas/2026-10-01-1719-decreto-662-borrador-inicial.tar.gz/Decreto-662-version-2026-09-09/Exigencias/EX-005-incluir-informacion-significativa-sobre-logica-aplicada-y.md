---
identificador: "Decreto-662-version-2026-09-09/EX-005"
enunciado: "Si realiza decisiones automatizadas o perfiles, el responsable debe incluir información significativa de lógica y consecuencias previstas."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "incluir información significativa sobre lógica aplicada y consecuencias previstas para el titular"
condicion_de_aplicacion: "Realiza decisiones automatizadas, incluida elaboración de perfiles"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. xi, frag. 2, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-xi-fragmento-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. xi, frag. 1, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-xi-fragmento-1.md, identifica operaciones automatizadas"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. d, num. xi, frag. 2: Si el responsable realizare estas operaciones, deberá incluir información significativa sobre la lógica aplicada, así como las consecuencias previstas de dicho tratamiento para el titular."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. d, num. xi, frag. 2, PDF primario, pág. 3, versión única desde 09-SEP-2026, expresa «Si el responsable realizare estas operaciones, deberá incluir información significativa sobre la lógica aplicada, así como las consecuencias previstas de dicho tratamiento para el titular.». La posición se atribuye a Responsable de datos y se formula como obligación: incluir información significativa sobre lógica aplicada y consecuencias previstas para el titular. La obligación añade información específica al dato general sobre existencia de tales operaciones.

## Alcance de la regla

Supuesto y condiciones: Realiza decisiones automatizadas, incluida elaboración de perfiles. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque información significativa es un concepto abierto que exige valoración del caso.

## Anclajes y función

- [Art. 3, inc. 1, lit. d, num. xi, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-xi-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. d, num. xi, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-xi-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; identifica operaciones automatizadas.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
