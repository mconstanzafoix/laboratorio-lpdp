---
identificador: "Decreto-662-version-2026-09-09/EX-016"
enunciado: "Cuando corresponda, la regulación interna debe incorporarse como obligación en el reglamento interno laboral."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "incorporar regulación del programa en el reglamento interno laboral"
condicion_de_aplicacion: "Implementa programa Y corresponde reglamento interno de arts. 153 y siguientes del Código del Trabajo"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 4, inc. 1, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-04/inciso-1-fragmento-2.md, principal"
cita_textual_de_respaldo: "Art. 4, inc. 1, frag. 2: En los casos que corresponda, dicha regulación interna deberá ser incorporada como una obligación en el reglamento interno del que tratan los artículos 153 y siguientes del Código del Trabajo."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 4, inc. 1, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «En los casos que corresponda, dicha regulación interna deberá ser incorporada como una obligación en el reglamento interno del que tratan los artículos 153 y siguientes del Código del Trabajo.». La posición se atribuye a Responsable de datos y se formula como obligación: incorporar regulación del programa en el reglamento interno laboral. Es un soporte documental diferente de los contratos de la frase anterior.

## Alcance de la regla

Supuesto y condiciones: Implementa programa Y corresponde reglamento interno de arts. 153 y siguientes del Código del Trabajo. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 4, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-04/inciso-1-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
