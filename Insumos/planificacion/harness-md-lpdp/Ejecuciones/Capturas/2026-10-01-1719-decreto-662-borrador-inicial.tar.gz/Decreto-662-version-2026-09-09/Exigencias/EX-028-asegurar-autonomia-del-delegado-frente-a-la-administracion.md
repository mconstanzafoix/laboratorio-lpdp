---
identificador: "Decreto-662-version-2026-09-09/EX-028"
enunciado: "El delegado debe contar con autonomía frente a la administración en las materias de la ley."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "asegurar autonomía del delegado frente a la administración"
condicion_de_aplicacion: "Delegado designado Y materias relacionadas con la ley"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 8, inc. 2, frag. 1, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-2-fragmento-1.md, principal; Decreto 662, versión 09-SEP-2026, Art. 9, inc. 3, frag. 1, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-3-fragmento-1.md, garantía frente a conflictos de interés"
cita_textual_de_respaldo: "Art. 8, inc. 2, frag. 1: El delegado de protección de datos deberá contar con autonomía respecto de la administración, en las materias relacionadas con esta ley."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 8, inc. 2, frag. 1, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «El delegado de protección de datos deberá contar con autonomía respecto de la administración, en las materias relacionadas con esta ley.». La posición se atribuye a Responsable de datos y se formula como obligación: asegurar autonomía del delegado frente a la administración. Aunque el texto predica la autonomía del delegado, el responsable que lo designa debe hacerla posible dentro de su estructura.

## Alcance de la regla

Supuesto y condiciones: Delegado designado Y materias relacionadas con la ley. No se fija plazo expreso en esta regla. El carácter es transversal según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque el grado de autonomía efectiva requiere valoración organizativa.

## Anclajes y función

- [Art. 8, inc. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-2-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.
- [Art. 9, inc. 3, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-3-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; garantía frente a conflictos de interés.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
