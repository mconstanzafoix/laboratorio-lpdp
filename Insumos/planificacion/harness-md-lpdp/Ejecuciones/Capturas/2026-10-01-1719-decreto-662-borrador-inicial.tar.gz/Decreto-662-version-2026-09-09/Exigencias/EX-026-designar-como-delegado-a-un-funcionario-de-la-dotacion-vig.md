---
identificador: "Decreto-662-version-2026-09-09/EX-026"
enunciado: "El órgano público que establezca delegado debe designar a un funcionario de su dotación vigente."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "designar como delegado a un funcionario de la dotación vigente"
condicion_de_aplicacion: "Responsable es órgano público Y establece encargado de prevención o delegado"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 7, inc. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-07/inciso-2.md, principal"
cita_textual_de_respaldo: "Art. 7, inc. 2: Los órganos públicos que establezcan un encargado de prevención o delegado de protección de datos personales deberán designar para ello a un funcionario de la dotación vigente del respectivo organismo."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 7, inc. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «Los órganos públicos que establezcan un encargado de prevención o delegado de protección de datos personales deberán designar para ello a un funcionario de la dotación vigente del respectivo organismo.». La posición se atribuye a Responsable de datos y se formula como obligación: designar como delegado a un funcionario de la dotación vigente. Es una restricción específica de la forma de designación en órganos públicos.

## Alcance de la regla

Supuesto y condiciones: Responsable es órgano público Y establece encargado de prevención o delegado. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 7, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-07/inciso-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
