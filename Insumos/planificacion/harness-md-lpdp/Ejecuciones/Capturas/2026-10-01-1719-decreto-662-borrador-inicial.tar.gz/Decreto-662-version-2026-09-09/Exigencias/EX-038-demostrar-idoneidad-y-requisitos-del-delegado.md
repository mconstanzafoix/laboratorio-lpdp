---
identificador: "Decreto-662-version-2026-09-09/EX-038"
enunciado: "En la certificación, el responsable debe poder demostrar idoneidad y cumplimiento de requisitos del delegado."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "demostrar idoneidad y requisitos del delegado"
condicion_de_aplicacion: "Solicita certificación del modelo"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 10, inc. 3, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-10/inciso-3.md, principal; Decreto 662, versión 09-SEP-2026, Art. 10, inc. 1, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-10/inciso-1.md, criterios de idoneidad"
cita_textual_de_respaldo: "Art. 10, inc. 3: El responsable que lo designe deberá ser capaz de demostrar la idoneidad del delegado para el ejercicio de sus funciones y el cumplimiento de los requisitos que la ley N° 19.628 y este reglamento establecen, en el marco del…"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 10, inc. 3, PDF primario, pág. 6, versión única desde 09-SEP-2026, expresa «El responsable que lo designe deberá ser capaz de demostrar la idoneidad del delegado para el ejercicio de sus funciones y el cumplimiento de los requisitos que la ley N° 19.628 y este reglamento establecen, en el marco del…». La posición se atribuye a Responsable de datos y se formula como obligación: demostrar idoneidad y requisitos del delegado. La carga de demostración recae en quien designa, no en el delegado por ese solo hecho.

## Alcance de la regla

Supuesto y condiciones: Solicita certificación del modelo. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque la suficiencia de la demostración depende de los antecedentes y requisitos aplicables.

## Anclajes y función

- [Art. 10, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-10/inciso-3.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; principal.
- [Art. 10, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-10/inciso-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; criterios de idoneidad.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
