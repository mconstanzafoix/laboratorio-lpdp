---
identificador: "Decreto-662-version-2026-09-09/EX-027"
enunciado: "El delegado debe ser designado por la máxima autoridad directiva o administrativa del responsable."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "designar delegado mediante la máxima autoridad directiva o administrativa"
condicion_de_aplicacion: "Cuando se designa delegado"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 8, inc. 1, frag. 1, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-1-fragmento-1.md, principal; Decreto 662, versión 09-SEP-2026, Art. 8, inc. 1, frag. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-1-fragmento-2.md, define máxima autoridad"
cita_textual_de_respaldo: "Art. 8, inc. 1, frag. 1: El delegado de protección de datos deberá ser designado por la máxima autoridad directiva o administrativa del responsable de datos."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 8, inc. 1, frag. 1, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «El delegado de protección de datos deberá ser designado por la máxima autoridad directiva o administrativa del responsable de datos.». La posición se atribuye a Responsable de datos y se formula como obligación: designar delegado mediante la máxima autoridad directiva o administrativa. El fragmento siguiente determina quién cuenta como autoridad según la entidad.

## Alcance de la regla

Supuesto y condiciones: Cuando se designa delegado. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 8, inc. 1, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-1-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.
- [Art. 8, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-1-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; define máxima autoridad.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
