---
identificador: "Decreto-662-version-2026-09-09/EX-022"
enunciado: "El delegado designado en el marco del programa debe ejercer las atribuciones legales y reglamentarias sobre todas las operaciones del responsable."
destinatario: "Delegado de protección de datos"
modalidad: "Obligación"
conducta_exigida: "ejercer atribuciones legales y reglamentarias respecto de todas las operaciones de tratamiento"
condicion_de_aplicacion: "Designación en marco de adopción y certificación de programa"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 6, inc. 1, frag. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 13, inc. 1, enunciado, PDF primario, pág. 7, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/enunciado.md, introduce funciones del delegado"
cita_textual_de_respaldo: "Art. 6, inc. 1, frag. 2: En este caso, el delegado deberá ejercer las atribuciones que establece el artículo 50 de la ley y el presente reglamento, respecto de todas las operaciones de tratamiento de datos que realice el responsable que lo designe, de…"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 6, inc. 1, frag. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «En este caso, el delegado deberá ejercer las atribuciones que establece el artículo 50 de la ley y el presente reglamento, respecto de todas las operaciones de tratamiento de datos que realice el responsable que lo designe, de…». La posición se atribuye a Delegado de protección de datos y se formula como obligación: ejercer atribuciones legales y reglamentarias respecto de todas las operaciones de tratamiento. Las funciones específicas del artículo 13 se examinan por separado por su conducta y objeto.

## Alcance de la regla

Supuesto y condiciones: Designación en marco de adopción y certificación de programa. No se fija plazo expreso en esta regla. El carácter es transversal según el ámbito de aplicación indicado. El estado Determinada se justifica porque la regla fija el ámbito de todas las operaciones, y las funciones reglamentarias se detallan en el artículo 13.

## Anclajes y función

- [Art. 6, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-06/inciso-1-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.
- [Art. 13, inc. 1, enunciado](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-13/enunciado.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 7, versión única desde 09-SEP-2026; introduce funciones del delegado.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
