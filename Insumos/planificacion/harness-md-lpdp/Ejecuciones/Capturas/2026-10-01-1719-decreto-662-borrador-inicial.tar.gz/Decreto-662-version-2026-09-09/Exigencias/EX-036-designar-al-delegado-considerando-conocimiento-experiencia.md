---
identificador: "Decreto-662-version-2026-09-09/EX-036"
enunciado: "La designación del delegado debe considerar conocimientos especializados, experiencia y habilidades profesionales."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "designar al delegado considerando conocimiento, experiencia y habilidades"
condicion_de_aplicacion: "Cuando designa delegado"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 10, inc. 1, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-10/inciso-1.md, principal"
cita_textual_de_respaldo: "Art. 10, inc. 1: El delegado de protección de datos deberá ser designado considerando sus conocimientos especializados en la regulación aplicable a la protección de datos personales, su experiencia en la materia, y sus habilidades profesionales…"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 10, inc. 1, PDF primario, pág. 6, versión única desde 09-SEP-2026, expresa «El delegado de protección de datos deberá ser designado considerando sus conocimientos especializados en la regulación aplicable a la protección de datos personales, su experiencia en la materia, y sus habilidades profesionales…». La posición se atribuye a Responsable de datos y se formula como obligación: designar al delegado considerando conocimiento, experiencia y habilidades. Los tres criterios son acumulativos para la selección.

## Alcance de la regla

Supuesto y condiciones: Cuando designa delegado. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque la idoneidad de conocimientos, experiencia y habilidades requiere apreciación profesional.

## Anclajes y función

- [Art. 10, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-10/inciso-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
