---
identificador: "Decreto-662-version-2026-09-09/EX-013"
enunciado: "El mecanismo interno de denuncia debe permitir solicitar y asegurar reserva de identidad del denunciante."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "asegurar posibilidad de solicitud y reserva de identidad del denunciante"
condicion_de_aplicacion: "Si adopta mecanismos de denuncia interna"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. i, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-i-fragmento-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. i, frag. 1, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-i-fragmento-1.md, mecanismo de denuncia ante delegado"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. i, frag. 2: Dichos mecanismos deberán asegurar la posibilidad de que el denunciante solicite y se asegure la reserva de su identidad."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. i, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «Dichos mecanismos deberán asegurar la posibilidad de que el denunciante solicite y se asegure la reserva de su identidad.». La posición se atribuye a Responsable de datos y se formula como obligación: asegurar posibilidad de solicitud y reserva de identidad del denunciante. La reserva es una garantía adicional a la existencia del canal.

## Alcance de la regla

Supuesto y condiciones: Si adopta mecanismos de denuncia interna. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque la forma de asegurar efectivamente la reserva depende de las características del canal.

## Anclajes y función

- [Art. 3, inc. 1, lit. i, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-i-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. i, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-i-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; mecanismo de denuncia ante delegado.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
