---
identificador: "Decreto-662-version-2026-09-09/EX-032"
enunciado: "El responsable debe disponer medios, facultades y recursos materiales suficientes para las funciones del delegado."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "proveer medios, facultades y recursos materiales suficientes al delegado"
condicion_de_aplicacion: "Delegado designado"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 9, inc. 1, PDF primario, pág. 5,6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-1.md, principal"
cita_textual_de_respaldo: "Art. 9, inc. 1: El responsable del tratamiento de datos deberá disponer los medios y facultades suficientes para el desempeño de las funciones del delegado, lo que incluye la provisión de los recursos materiales necesarios para realizar…"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 9, inc. 1, PDF primario, pág. 5,6, versión única desde 09-SEP-2026, expresa «El responsable del tratamiento de datos deberá disponer los medios y facultades suficientes para el desempeño de las funciones del delegado, lo que incluye la provisión de los recursos materiales necesarios para realizar…». La posición se atribuye a Responsable de datos y se formula como obligación: proveer medios, facultades y recursos materiales suficientes al delegado. Los factores nombrados orientan la suficiencia; no son permisos para omitir recursos.

## Alcance de la regla

Supuesto y condiciones: Delegado designado. No se fija plazo expreso en esta regla. El carácter es transversal según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque suficiencia y adecuación dependen de tamaño, capacidad, operaciones, datos y riesgos.

## Anclajes y función

- [Art. 9, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5,6, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
