---
identificador: "Decreto-662-version-2026-09-09/EX-034"
enunciado: "El responsable debe garantizar que otras funciones del delegado no generen conflicto de intereses ni afecten su independencia."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "garantizar ausencia de conflictos de interés e independencia del delegado"
condicion_de_aplicacion: "Delegado desempeña otras funciones o cometidos"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 9, inc. 3, frag. 1, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-3-fragmento-1.md, principal; Decreto 662, versión 09-SEP-2026, Art. 9, inc. 2, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-2.md, supuesto de otras funciones"
cita_textual_de_respaldo: "Art. 9, inc. 3, frag. 1: Asimismo, el responsable garantizará que dichas funciones y cometidos no den lugar a conflicto de intereses con aquellas que deba realizar en su labor de delegado y que no afecten la independencia en su función, sea que el…"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 9, inc. 3, frag. 1, PDF primario, pág. 6, versión única desde 09-SEP-2026, expresa «Asimismo, el responsable garantizará que dichas funciones y cometidos no den lugar a conflicto de intereses con aquellas que deba realizar en su labor de delegado y que no afecten la independencia en su función, sea que el…». La posición se atribuye a Responsable de datos y se formula como obligación: garantizar ausencia de conflictos de interés e independencia del delegado. El deber persiste tanto con vínculo dependiente como con prestación de servicios.

## Alcance de la regla

Supuesto y condiciones: Delegado desempeña otras funciones o cometidos. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque conflicto e independencia requieren valoración de funciones efectivas.

## Anclajes y función

- [Art. 9, inc. 3, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-3-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; principal.
- [Art. 9, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; supuesto de otras funciones.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
