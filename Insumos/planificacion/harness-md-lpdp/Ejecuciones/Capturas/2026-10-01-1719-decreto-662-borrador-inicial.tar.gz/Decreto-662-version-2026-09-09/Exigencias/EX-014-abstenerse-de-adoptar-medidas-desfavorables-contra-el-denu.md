---
identificador: "Decreto-662-version-2026-09-09/EX-014"
enunciado: "No se puede imponer al denunciante una medida desfavorable por causa de su denuncia."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "abstenerse de adoptar medidas desfavorables contra el denunciante por su denuncia"
condicion_de_aplicacion: "Denuncia de infracciones ante delegado Y causalidad con medida desfavorable"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. i, frag. 3, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-i-fragmento-3.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. i, frag. 1, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-i-fragmento-1.md, identifica denuncia protegida"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. i, frag. 3: El denunciante no podrá ser objeto de ninguna medida desfavorable en su contra a causa de su denuncia."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. i, frag. 3, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «El denunciante no podrá ser objeto de ninguna medida desfavorable en su contra a causa de su denuncia.». La posición se atribuye a Responsable de datos y se formula como prohibición: abstenerse de adoptar medidas desfavorables contra el denunciante por su denuncia. La protección frente a represalias es autónoma de la reserva de identidad.

## Alcance de la regla

Supuesto y condiciones: Denuncia de infracciones ante delegado Y causalidad con medida desfavorable. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque medida desfavorable y causalidad requieren valoración en la situación concreta.

## Anclajes y función

- [Art. 3, inc. 1, lit. i, frag. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-i-fragmento-3.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. i, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-i-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; identifica denuncia protegida.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
