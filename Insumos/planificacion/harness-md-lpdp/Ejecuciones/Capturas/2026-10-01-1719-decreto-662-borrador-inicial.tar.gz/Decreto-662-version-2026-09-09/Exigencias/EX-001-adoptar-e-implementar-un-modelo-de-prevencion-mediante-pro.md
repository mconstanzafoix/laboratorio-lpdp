---
identificador: "Decreto-662-version-2026-09-09/EX-001"
enunciado: "Los responsables pueden adoptar e implementar voluntariamente un modelo mediante un programa de cumplimiento conforme a la ley y al reglamento."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "adoptar e implementar un modelo de prevención mediante programa de cumplimiento"
condicion_de_aplicacion: "Conforme a la Ley N° 19.628 Y este reglamento"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 1, inc. 2, PDF primario, pág. 2, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-01/inciso-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 1, inc. 1, PDF primario, pág. 2, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-01/inciso-1.md, delimita objeto; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, enunciado, frag. 1, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/enunciado-fragmento-1.md, define programa"
cita_textual_de_respaldo: "Art. 1, inc. 2: Los responsables de datos, sean personas naturales o jurídicas, públicas o privadas, podrán adoptar e implementar, voluntariamente, un modelo de prevención de infracciones consistente en la adopción de un programa de…"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 1, inc. 2, PDF primario, pág. 2, versión única desde 09-SEP-2026, expresa «Los responsables de datos, sean personas naturales o jurídicas, públicas o privadas, podrán adoptar e implementar, voluntariamente, un modelo de prevención de infracciones consistente en la adopción de un programa de…». La posición se atribuye a Responsable de datos y se formula como permiso condicionado: adoptar e implementar un modelo de prevención mediante programa de cumplimiento. El permiso es autónomo del deber general de prevención del inciso siguiente.

## Alcance de la regla

Supuesto y condiciones: Conforme a la Ley N° 19.628 Y este reglamento. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque el decreto fija el acto permitido y remite al marco normativo aplicable.

## Anclajes y función

- [Art. 1, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-01/inciso-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 2, versión única desde 09-SEP-2026; principal.
- [Art. 1, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-01/inciso-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 2, versión única desde 09-SEP-2026; delimita objeto.
- [Art. 3, inc. 1, enunciado, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/enunciado-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; define programa.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
