---
identificador: "Decreto-662-version-2026-09-09/EX-037"
enunciado: "El delegado debe mantener conocimientos actualizados de normas, decisiones de la Agencia y jurisprudencia relevante."
destinatario: "Delegado de protección de datos"
modalidad: "Obligación"
conducta_exigida: "mantener actualizados conocimientos normativos y jurisprudenciales"
condicion_de_aplicacion: "Durante el ejercicio de la función"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 10, inc. 2, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-10/inciso-2.md, principal"
cita_textual_de_respaldo: "Art. 10, inc. 2: El delegado deberá contar siempre con conocimientos actualizados respecto de las normas aplicables, las decisiones y normas dictadas por la Agencia, y la jurisprudencia relevante en la materia."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 10, inc. 2, PDF primario, pág. 6, versión única desde 09-SEP-2026, expresa «El delegado deberá contar siempre con conocimientos actualizados respecto de las normas aplicables, las decisiones y normas dictadas por la Agencia, y la jurisprudencia relevante en la materia.». La posición se atribuye a Delegado de protección de datos y se formula como obligación: mantener actualizados conocimientos normativos y jurisprudenciales. La actualización es continua y distinta de la idoneidad inicial de selección.

## Alcance de la regla

Supuesto y condiciones: Durante el ejercicio de la función. No se fija plazo expreso en esta regla. El carácter es transversal según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque actualización y relevancia requieren valoración temporal y material.

## Anclajes y función

- [Art. 10, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-10/inciso-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
