---
identificador: "Decreto-662-version-2026-09-09/EX-024"
enunciado: "Si el servicio lo presta una persona jurídica, el contrato debe individualizar a la persona natural delegada."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "individualizar en el contrato a la persona natural que actuará como delegado"
condicion_de_aplicacion: "Prestador del servicio de delegado es persona jurídica"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 7, inc. 1, frag. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-07/inciso-1-fragmento-2.md, principal"
cita_textual_de_respaldo: "Art. 7, inc. 1, frag. 2: En el caso en que sea una persona jurídica la que preste el servicio, el contrato deberá individualizar a la persona natural que actuará como delegado."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 7, inc. 1, frag. 2, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «En el caso en que sea una persona jurídica la que preste el servicio, el contrato deberá individualizar a la persona natural que actuará como delegado.». La posición se atribuye a Responsable de datos y se formula como obligación: individualizar en el contrato a la persona natural que actuará como delegado. El contrato es el soporte exigido; el deber de asegurar la identificación corresponde al responsable que lo celebra.

## Alcance de la regla

Supuesto y condiciones: Prestador del servicio de delegado es persona jurídica. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 7, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-07/inciso-1-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
