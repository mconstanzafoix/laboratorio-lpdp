---
identificador: "Decreto-662-version-2026-09-09/EX-030"
enunciado: "En micro, pequeñas y medianas empresas, el dueño o máxima autoridad puede asumir tareas de delegado."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "asumir personalmente tareas de delegado"
condicion_de_aplicacion: "Responsable es micro, pequeña O mediana empresa Y quien asume es dueño O máxima autoridad"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 8, inc. 3, PDF primario, pág. 5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-3.md, principal"
cita_textual_de_respaldo: "Art. 8, inc. 3: En las micro, pequeñas y medianas empresas, el dueño o sus máximas autoridades podrán asumir personalmente las tareas de delegado de protección de datos."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 8, inc. 3, PDF primario, pág. 5, versión única desde 09-SEP-2026, expresa «En las micro, pequeñas y medianas empresas, el dueño o sus máximas autoridades podrán asumir personalmente las tareas de delegado de protección de datos.». La posición se atribuye a Responsable de datos y se formula como permiso condicionado: asumir personalmente tareas de delegado. La facultad se circunscribe a las categorías empresariales nombradas.

## Alcance de la regla

Supuesto y condiciones: Responsable es micro, pequeña O mediana empresa Y quien asume es dueño O máxima autoridad. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 8, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-08/inciso-3.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 5, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
