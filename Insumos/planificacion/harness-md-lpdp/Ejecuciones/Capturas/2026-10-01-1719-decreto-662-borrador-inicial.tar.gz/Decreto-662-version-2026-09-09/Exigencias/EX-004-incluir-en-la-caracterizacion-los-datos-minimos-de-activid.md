---
identificador: "Decreto-662-version-2026-09-09/EX-004"
enunciado: "La caracterización de actividades de tratamiento debe contener al menos los datos de los numerales i a xi."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "incluir en la caracterización los datos mínimos de actividades de tratamiento"
condicion_de_aplicacion: "Si incorpora la caracterización al programa"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, frag. 2, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-fragmento-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. i, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-i.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. ii, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-ii.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. iii, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-iii.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. iv, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-iv.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. v, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-v.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. vi, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-vi.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. vii, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-vii.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. viii, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-viii.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. ix, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-ix.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. x, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-x.md, dato mínimo de caracterización; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. d, num. xi, frag. 1, PDF primario, pág. 3, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-xi-fragmento-1.md, dato mínimo de caracterización"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. d, frag. 2: La caracterización de actividades de tratamiento deberá contener, a lo menos, la siguiente información:"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. d, frag. 2, PDF primario, pág. 3, versión única desde 09-SEP-2026, expresa «La caracterización de actividades de tratamiento deberá contener, a lo menos, la siguiente información:». La posición se atribuye a Responsable de datos y se formula como obligación: incluir en la caracterización los datos mínimos de actividades de tratamiento. Los once numerales son componentes acumulativos del contenido mínimo, no once conductas autónomas.

## Alcance de la regla

Supuesto y condiciones: Si incorpora la caracterización al programa. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los once numerales fijan la información mínima, aunque algunos remitan al marco legal para su interpretación.

## Anclajes y función

- [Art. 3, inc. 1, lit. d, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. d, num. i](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-i.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. ii](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-ii.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. iii](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-iii.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. iv](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-iv.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. v](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-v.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. vi](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-vi.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. vii](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-vii.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. viii](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-viii.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. ix](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-ix.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. x](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-x.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.
- [Art. 3, inc. 1, lit. d, num. xi, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-d-numeral-xi-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 3, versión única desde 09-SEP-2026; dato mínimo de caracterización.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
