---
identificador: "Decreto-662-version-2026-09-09/EX-015"
enunciado: "La regulación interna del programa debe incorporarse como obligación expresa en los contratos pertinentes."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "incorporar regulación interna del programa como obligación en contratos de trabajo o servicios"
condicion_de_aplicacion: "Implementa programa Y regulación interna derivada del programa"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 4, inc. 1, frag. 1, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-04/inciso-1-fragmento-1.md, principal"
cita_textual_de_respaldo: "Art. 4, inc. 1, frag. 1: La regulación interna a que dé lugar la implementación del programa, en su caso, deberá ser incorporada expresamente como una obligación en los contratos de trabajo o de prestación de servicios de todos los trabajadores,…"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 4, inc. 1, frag. 1, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «La regulación interna a que dé lugar la implementación del programa, en su caso, deberá ser incorporada expresamente como una obligación en los contratos de trabajo o de prestación de servicios de todos los trabajadores,…». La posición se atribuye a Responsable de datos y se formula como obligación: incorporar regulación interna del programa como obligación en contratos de trabajo o servicios. Abarca trabajadores, empleados, prestadores y máximos cargos nombrados en el texto.

## Alcance de la regla

Supuesto y condiciones: Implementa programa Y regulación interna derivada del programa. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 4, inc. 1, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-04/inciso-1-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
