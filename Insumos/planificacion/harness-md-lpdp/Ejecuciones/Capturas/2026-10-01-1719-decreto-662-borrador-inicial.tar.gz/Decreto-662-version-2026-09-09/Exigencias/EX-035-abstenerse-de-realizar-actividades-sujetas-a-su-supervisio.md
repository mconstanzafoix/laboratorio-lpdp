---
identificador: "Decreto-662-version-2026-09-09/EX-035"
enunciado: "El delegado no puede realizar actividades sujetas a su supervisión o asesoría, salvo el alcance legal referido para MIPYME."
destinatario: "Delegado de protección de datos"
modalidad: "Prohibición"
conducta_exigida: "abstenerse de realizar actividades sujetas a su supervisión, pronunciamiento o asesoría"
condicion_de_aplicacion: "Actividad bajo supervisión O pronunciamiento O asesoría del propio delegado; salvedad art. 50 inc. 3 Ley N° 19.628"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 9, inc. 3, frag. 2, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-3-fragmento-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 9, inc. 2, PDF primario, pág. 6, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-2.md, permiso de otras funciones"
cita_textual_de_respaldo: "Art. 9, inc. 3, frag. 2: El delegado no podrá realizar actividades que estén sujetas a su supervisión o sobre las cuales deba pronunciarse o asesorar en su función de delegado, sin perjuicio de lo dispuesto en el inciso tercero del artículo 50 de la ley…"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 9, inc. 3, frag. 2, PDF primario, pág. 6, versión única desde 09-SEP-2026, expresa «El delegado no podrá realizar actividades que estén sujetas a su supervisión o sobre las cuales deba pronunciarse o asesorar en su función de delegado, sin perjuicio de lo dispuesto en el inciso tercero del artículo 50 de la ley…». La posición se atribuye a Delegado de protección de datos y se formula como prohibición: abstenerse de realizar actividades sujetas a su supervisión, pronunciamiento o asesoría. La salvedad legal está expresamente remitida y su alcance debe cotejarse antes de cerrar una aplicación concreta.

## Alcance de la regla

Supuesto y condiciones: Actividad bajo supervisión O pronunciamiento O asesoría del propio delegado; salvedad art. 50 inc. 3 Ley N° 19.628. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque determinar si una actividad queda sometida a supervisión o asesoría requiere valoración funcional.

## Anclajes y función

- [Art. 9, inc. 3, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-3-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; principal.
- [Art. 9, inc. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-09/inciso-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 6, versión única desde 09-SEP-2026; permiso de otras funciones.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
