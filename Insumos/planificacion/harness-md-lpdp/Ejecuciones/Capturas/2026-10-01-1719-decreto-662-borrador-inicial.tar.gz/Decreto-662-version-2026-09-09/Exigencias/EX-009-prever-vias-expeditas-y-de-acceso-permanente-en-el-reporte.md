---
identificador: "Decreto-662-version-2026-09-09/EX-009"
enunciado: "Los mecanismos de reporte interno deben ofrecer vías expeditas y de acceso permanente."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "prever vías expeditas y de acceso permanente en el reporte interno"
condicion_de_aplicacion: "Si dispone mecanismos de reporte interno en el programa"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. g, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-fragmento-2.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. g, frag. 1, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-fragmento-1.md, define mecanismo interno"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. g, frag. 2: Dichos mecanismos deberán prever vías expeditas y de acceso permanente para los miembros de la organización del responsable."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. g, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «Dichos mecanismos deberán prever vías expeditas y de acceso permanente para los miembros de la organización del responsable.». La posición se atribuye a Responsable de datos y se formula como obligación: prever vías expeditas y de acceso permanente en el reporte interno. El deber califica la accesibilidad del mecanismo, además de su inclusión en el programa.

## Alcance de la regla

Supuesto y condiciones: Si dispone mecanismos de reporte interno en el programa. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Indeterminada se justifica porque expeditas requiere valoración de funcionamiento concreto.

## Anclajes y función

- [Art. 3, inc. 1, lit. g, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. g, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; define mecanismo interno.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
