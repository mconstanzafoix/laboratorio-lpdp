---
identificador: "Decreto-662-version-2026-09-09/EX-017"
enunciado: "En caso de incorporación al reglamento interno, el responsable debe cumplir las medidas de publicidad del artículo 156 del Código del Trabajo."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "cumplir medidas de publicidad del reglamento interno"
condicion_de_aplicacion: "Regulación incorporada al reglamento interno laboral"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 4, inc. 1, frag. 3, PDF primario, pág. 4,5, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-04/inciso-1-fragmento-3.md, principal; Decreto 662, versión 09-SEP-2026, Art. 4, inc. 1, frag. 2, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-04/inciso-1-fragmento-2.md, supuesto del reglamento interno"
cita_textual_de_respaldo: "Art. 4, inc. 1, frag. 3: En este último caso, el responsable deberá dar cumplimiento a las medidas de publicidad establecidas en el artículo 156 del mismo Código."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 4, inc. 1, frag. 3, PDF primario, pág. 4,5, versión única desde 09-SEP-2026, expresa «En este último caso, el responsable deberá dar cumplimiento a las medidas de publicidad establecidas en el artículo 156 del mismo Código.». La posición se atribuye a Responsable de datos y se formula como obligación: cumplir medidas de publicidad del reglamento interno. La remisión laboral determina las medidas concretas; el decreto expresa la obligación de observarlas.

## Alcance de la regla

Supuesto y condiciones: Regulación incorporada al reglamento interno laboral. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 4, inc. 1, frag. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-04/inciso-1-fragmento-3.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4,5, versión única desde 09-SEP-2026; principal.
- [Art. 4, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-04/inciso-1-fragmento-2.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; supuesto del reglamento interno.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
