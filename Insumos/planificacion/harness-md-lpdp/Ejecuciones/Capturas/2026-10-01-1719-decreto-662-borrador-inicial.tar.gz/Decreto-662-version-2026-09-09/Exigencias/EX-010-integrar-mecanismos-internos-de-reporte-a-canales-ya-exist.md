---
identificador: "Decreto-662-version-2026-09-09/EX-010"
enunciado: "Los mecanismos internos de reporte pueden integrarse a canales existentes si cumplen la ley y el reglamento."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "integrar mecanismos internos de reporte a canales ya existentes"
condicion_de_aplicacion: "Canal existente Y cumplimiento de Ley N° 19.628 Y este reglamento"
plazo: ""
disposicion_de_anclaje: "Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. g, frag. 3, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-fragmento-3.md, principal; Decreto 662, versión 09-SEP-2026, Art. 3, inc. 1, lit. g, frag. 1, PDF primario, pág. 4, versión única desde 09-SEP-2026, Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-fragmento-1.md, identifica mecanismo de reporte"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. g, frag. 3: Los mecanismos de reporte interno podrán integrarse a canales existentes en la organización respecto de la denuncia a infracciones relativas a otras materias, siempre que éstos cumplan con lo establecido en la ley N° 19.628 y en…"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El Art. 3, inc. 1, lit. g, frag. 3, PDF primario, pág. 4, versión única desde 09-SEP-2026, expresa «Los mecanismos de reporte interno podrán integrarse a canales existentes en la organización respecto de la denuncia a infracciones relativas a otras materias, siempre que éstos cumplan con lo establecido en la ley N° 19.628 y en…». La posición se atribuye a Responsable de datos y se formula como permiso condicionado: integrar mecanismos internos de reporte a canales ya existentes. Se autoriza una forma de organización del canal, sin dispensar sus exigencias de acceso.

## Alcance de la regla

Supuesto y condiciones: Canal existente Y cumplimiento de Ley N° 19.628 Y este reglamento. No se fija plazo expreso en esta regla. El carácter es condicional según el ámbito de aplicación indicado. El estado Determinada se justifica porque los componentes necesarios de esta posición quedan fijados por el texto aquí citado.

## Anclajes y función

- [Art. 3, inc. 1, lit. g, frag. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-fragmento-3.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; principal.
- [Art. 3, inc. 1, lit. g, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Decreto-662-version-2026-09-09/articulo-03/letra-g-fragmento-1.md) — Decreto 662, versión 09-SEP-2026, PDF primario, pág. 4, versión única desde 09-SEP-2026; identifica mecanismo de reporte.

## Límites del análisis

La calificación sancionadora queda pendiente de cotejo fundado con el régimen de la Ley N° 19.628 y las remisiones pertinentes. El campo vacío no equivale a 0 No tipificada. Las normas externas citadas se identifican como contexto; no se presentan como anclajes no comprobados.
