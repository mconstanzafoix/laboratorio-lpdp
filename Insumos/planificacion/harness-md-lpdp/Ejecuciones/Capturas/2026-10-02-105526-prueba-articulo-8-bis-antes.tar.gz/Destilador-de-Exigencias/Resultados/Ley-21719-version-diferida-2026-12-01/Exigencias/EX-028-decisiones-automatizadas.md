---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-028"
enunciado: "Oponerse y no ser objeto de decisiones basadas en tratamiento automatizado que produzcan efectos jurídicos o afecten significativamente al titular."
destinatario: "Titular"
modalidad: "Derecho del titular"
conducta_exigida: "Oponerse y no ser objeto de decisiones basadas en tratamiento automatizado que produzcan efectos jurídicos o afecten significativamente al titular."
condicion_de_aplicacion: "Decisión automatizada con efectos jurídicos O afectación significativa; salvo contrato necesario O consentimiento previo expreso O habilitación legal con salvaguardas."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-01.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-02.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, lit. a, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/letra-a.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, lit. b, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/letra-b.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, lit. c, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/letra-c.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 12 reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-12/inciso-02.md, condición, excepción o contexto; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 7, instrucción modificatoria, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md, incorporación"
cita_textual_de_respaldo: "Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 1: «tiene derecho a oponerse y a no ser objeto de decisiones basadas en el tratamiento automatizado»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "EXCEPCIONES: a) Cuando la decisión sea necesaria para la celebración o ejecución de un contrato entre el titular y el responsable.; b) Cuando exista consentimiento previo y expreso del titular en la forma prescrita en el artículo 12.; c) Cuando lo señale la ley, en la medida en que ésta disponga el empleo de salvaguardas a los derechos y libertades del titular."
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La Disposición principal dice «tiene derecho a oponerse y a no ser objeto de decisiones basadas en el tratamiento automatizado». El inciso reconoce al titular dos aspectos de una misma protección frente a decisiones automatizadas. Las letras a a c son excepciones alternativas; se mantienen como condiciones de la misma regla.

## Alcance de la regla

La afectación significativa y la necesidad contractual exigen valoración. La forma del consentimiento de la letra b se contrasta con el artículo 12 reproducido; no hay plazo expreso. El estado de determinación es `Indeterminada` y el carácter `Condicional` por el alcance descrito.

## Anclajes y función

- Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 1: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-01.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, inc. 2: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/inciso-02.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, lit. a: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/letra-a.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, lit. b: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/letra-b.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, art. 8 bis reproducido de Ley 19.628, lit. c: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/articulo-reproducido-08-bis/letra-c.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 8, art. 12 reproducido de Ley 19.628, inc. 2: [condición, excepción o contexto](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-12/inciso-02.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.
- Art. primero, num. 7, instrucción modificatoria: [incorporación](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-07/instruccion.md); Ley 21.719 modificatoria, versión diferida 01-12-2026.

## Límites del análisis

`sancion` permanece vacía: cotejados los artículos 33 a 35 y el régimen especial del artículo 44 de esta Fuente, la ficha no documenta un vínculo individual suficiente con una tipificación concreta para asignar grado y multa. El vacío no equivale a `0 No tipificada`.
