---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-012"
enunciado: "El responsable debe garantizar seguridad adecuada de los datos con medidas apropiadas al tratamiento y a su naturaleza."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Garantizar seguridad adecuada de los datos y adoptar medidas apropiadas al tratamiento y naturaleza de los datos."
condicion_de_aplicacion: "Tratamiento de datos personales."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. f, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-f.md, principal: regla expresada; Art. 14 quinquies, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quinquies/inciso-01.md, desarrollo operativo del principio; Art. 34 ter, inc. 1, lit. j, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-j.md, tipificación grave; Art. 35, inc. 1, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md, sanción base; Art. 44, inc. 3, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-44/inciso-03-fragmento-01.md, régimen público cuando corresponda"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. f: «el responsable debe garantizar estándares adecuados de seguridad»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: "2 Grave"
---

## Fundamento textual e interpretación

El deber de garantizar seguridad y la adecuación de sus medidas integran una sola posición protectora. La misma letra menciona tratamiento no autorizado o ilícito, pérdida, filtración, daño accidental y destrucción como riesgos que delimitan el estándar.

## Alcance de la regla

Las medidas deben corresponder al tratamiento y a la naturaleza de los datos. El art. 14 quinquies, inc. 1 ordena adoptar las medidas necesarias para resguardar este mismo principio, considerando técnica, costos, contexto, fines y riesgos; precisa confidencialidad, integridad, disponibilidad y resiliencia. La adecuación del estándar es abierta y requiere valoración; no se fija plazo ni delegación expresa. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. f](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-f.md): principal: regla expresada.

- [Art. 14 quinquies, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-14-quinquies/inciso-01.md): desarrolla operativamente el principio de seguridad.
- [Art. 34 ter, inc. 1, lit. j](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-j.md): tipifica vulnerar obligaciones de seguridad del art. 14 quinquies.
- [Art. 35, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md): sanción base.
- [Art. 44, inc. 3, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-44/inciso-03-fragmento-01.md): régimen de órganos públicos cuando corresponda.

## Sanción

El art. 14 quinquies, inc. 1 obliga al responsable a adoptar medidas para resguardar el mismo principio de seguridad del art. 3, inc. 1, letra f. La vulneración de esa obligación operativa se tipifica expresamente como `2 Grave` en el art. 34 ter, inc. 1, letra j. El art. 35, inc. 1, letra b prevé multa general de hasta 10.000 unidades tributarias mensuales; para un órgano público el art. 44, inc. 3, frag. 1 remite a la tipificación y fija multa de 20 % a 50 % de la remuneración mensual del jefe superior. La aplicación al caso exige valorar qué medidas correspondían al riesgo; no se presupone una infracción o sanción concreta.
