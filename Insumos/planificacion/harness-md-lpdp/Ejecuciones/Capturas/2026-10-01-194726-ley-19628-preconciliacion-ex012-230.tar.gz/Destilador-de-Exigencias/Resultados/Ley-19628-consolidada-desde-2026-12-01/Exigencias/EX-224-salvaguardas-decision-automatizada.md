---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-224"
enunciado: "El responsable debe adoptar medidas para garantizar derechos del titular frente a toda decisión automatizada, incluidos información, explicación, intervención humana, expresión del punto de vista y revisión."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Adoptar medidas necesarias para asegurar derechos y libertades en decisiones automatizadas."
condicion_de_aplicacion: "Cualquier decisión basada en tratamiento automatizado, incluso supuestos exceptuados del inciso segundo."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 8 bis, inc. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08-bis/inciso-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 8 bis, inc. 03: «deberá adoptar las medidas necesarias para asegurar los derechos y libertades del titular»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "información y transparencia; explicación; intervención humana; expresión del punto de vista; revisión de la decisión"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El deber opera incluso cuando se aplica excepción al derecho de no ser objeto de decisión; suficiencia de medidas requiere valoración.

## Alcance de la regla

La regla se aplica a: Cualquier decisión basada en tratamiento automatizado, incluso supuestos exceptuados del inciso segundo. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 8 bis, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08-bis/inciso-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional individual; el campo vacío no significa ausencia de tipificación.

**Conciliación sancionadora individual (01-10-2026):** Para la regla anclada en [Art. 8 bis, inc. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08-bis/inciso-03.md), El deber de salvaguardas frente a decisiones automatizadas se cotejó con [Art. 34 ter, inc. 1, lit. e](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-e.md) cuando su incumplimiento impida u obstaculice un derecho ejercido, y con [Art. 34 bis, inc. 1, lit. f](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-bis/inciso-01-letra-f.md) para otros incumplimientos no calificados en grados superiores. Falta distinguir la falta de salvaguarda de la obstrucción concreta; `sancion` queda vacía.
