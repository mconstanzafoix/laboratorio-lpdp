---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-223"
enunciado: "El titular puede oponerse y no ser objeto de decisiones automatizadas, incluida elaboración de perfiles, que le produzcan efectos jurídicos o afecten significativamente."
destinatario: "Titular"
modalidad: "Derecho del titular"
conducta_exigida: "Oponerse a decisión basada en tratamiento automatizado y no ser objeto de ella."
condicion_de_aplicacion: "Decisión automatizada con efectos jurídicos o afectación significativa; excepciones del inciso segundo."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 8 bis, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08-bis/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 8 bis, inc. 01: «tiene derecho a oponerse y a no ser objeto de decisiones basadas en el tratamiento automatizado»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "efectos jurídicos; afectación significativa"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La afectación significativa exige valoración; las excepciones contractuales, consentidas y legales están en inciso segundo.

## Alcance de la regla

La regla se aplica a: Decisión automatizada con efectos jurídicos o afectación significativa; excepciones del inciso segundo. Estado `Indeterminada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 8 bis, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08-bis/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional individual; el campo vacío no significa ausencia de tipificación.

**Conciliación sancionadora individual (01-10-2026):** En [Art. 8 bis, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-08-bis/inciso-01.md), la posición pertenece al titular: «Oponerse a decisión basada en tratamiento automatizado y no ser objeto de ella». Se cotejó con [Art. 34 ter, inc. 1, lit. e](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-e.md) y [Art. 34, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34/inciso-01.md); estos tipos describen infracciones del responsable, no el ejercicio u obligación del titular como tal. Falta identificar una conducta correlativa del responsable y su tipo antes de asignar grado a esta ficha. `sancion` permanece vacío.
