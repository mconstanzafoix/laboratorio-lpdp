---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-024"
enunciado: "El responsable no puede volver a tratar datos sin rectificar después de efectuada su rectificación."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "Volver a tratar datos sin rectificar después de efectuada la rectificación."
condicion_de_aplicacion: "Rectificación efectuada respecto de los datos."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 6, inc. 3, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-06/inciso-03.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 6, inc. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-06/inciso-01.md, derecho cuya ejecución activa la prohibición"
cita_textual_de_respaldo: "Art. 6, inc. 3: «no se podrán volver a tratar los datos sin rectificar»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La tercera frase prohíbe un tratamiento posterior de la versión no corregida del dato. Puede infringirse aunque la rectificación se haya comunicado, por lo que es autónoma frente al deber del inciso segundo.

## Alcance de la regla

La prohibición se activa una vez efectuada la rectificación y se refiere a los datos sin corregir. No hay plazo numérico ni delegación expresa. El carácter es `Condicional` por el supuesto de activación. Se registra `Determinada` por las características del texto indicadas.

## Anclajes y función

- [Art. 6, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-06/inciso-03.md): principal: regla expresada.
- [Art. 6, inc. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-06/inciso-01.md): derecho cuya ejecución activa la prohibición.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones expresas relevantes; el campo vacío no significa ausencia de tipificación.

**Conciliación sancionadora individual (01-10-2026):** En [Art. 6, inc. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-06/inciso-03.md), la conducta prohibida se refiere a «Volver a tratar datos sin rectificar después de efectuada la rectificación». Se cotejó con [Art. 34 ter, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-d.md). Tratar datos no rectificados puede integrar la letra d si produce tratamiento inexacto o desactualizado; también puede obstaculizar rectificación conforme a la letra e. La prohibición no resuelve sola la concurrencia de esos elementos. `sancion` permanece vacío.
