---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-109"
enunciado: "El órgano público receptor no puede utilizar los datos recibidos para fines distintos del tratamiento específico de la comunicación o cesión."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "Usar los datos recibidos para otros fines."
condicion_de_aplicacion: "Recepción de datos desde otro órgano público para un tratamiento específico."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 22, inc. 01, frag. 03, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-22/inciso-01-fragmento-03.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 22, inc. 01, frag. 03: «el órgano público receptor no los podrá utilizar para otros fines»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La finalidad específica del fragmento segundo cierra el uso permitido del receptor.

## Alcance de la regla

La regla se aplica a: Recepción de datos desde otro órgano público para un tratamiento específico. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 22, inc. 01, frag. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-22/inciso-01-fragmento-03.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.

**Conciliación sancionadora individual (01-10-2026):** En [Art. 22, inc. 01, frag. 03](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-22/inciso-01-fragmento-03.md), la conducta prohibida se refiere a «Usar los datos recibidos para otros fines». Se cotejó con [Art. 34 ter, inc. 1, lit. a](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-a.md). El uso para finalidad distinta o tras expirar la habilitación puede integrar la letra a, mientras el art. 34 quáter, letra b exige malicia adicional. Falta calificar la conducta específica y su elemento subjetivo sin presumirlos. `sancion` permanece vacío.
