---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-220"
enunciado: "El responsable puede adoptar voluntariamente un modelo de prevención de infracciones basado en un programa de cumplimiento."
destinatario: "Responsable de datos"
modalidad: "Permiso condicionado"
conducta_exigida: "Adoptar modelo de prevención de infracciones."
condicion_de_aplicacion: "Responsable opta voluntariamente por programa de cumplimiento con contenido mínimo legal."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 49, inc. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-49/inciso-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 49, inc. 01: «podrán voluntariamente adoptar un modelo de prevención de infracciones»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La adopción es voluntaria y activa requisitos del programa en inciso segundo.

## Alcance de la regla

La regla se aplica a: Responsable opta voluntariamente por programa de cumplimiento con contenido mínimo legal. Estado `Determinada`; carácter `Condicional`. El texto no fija plazo numérico para esta conducta.

## Anclajes y función

- [Art. 49, inc. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-49/inciso-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente de conciliación individual con el régimen de esta Fuente; el campo vacío no significa ausencia de tipificación.
