---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-126"
enunciado: "Se prohíbe tratar masivamente los datos personales contenidos en registros electrónicos públicos de infracciones."
destinatario: "Responsable de datos"
modalidad: "Prohibición"
conducta_exigida: "Tratar masivamente datos de registros electrónicos de infracciones."
condicion_de_aplicacion: "Registros electrónicos de infracciones penales, civiles, administrativas o disciplinarias llevados por organismos públicos."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 25, inc. 05, frag. 01, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-25/inciso-05-fragmento-01.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 25, inc. 05, frag. 01: «Se prohíbe el tratamiento masivo de los datos personales»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: "penales; civiles; administrativas; disciplinarias"
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

La prohibición expresa recae sobre tratamiento masivo de registros públicos de infracciones.

## Alcance de la regla

La regla se aplica a: Registros electrónicos de infracciones penales, civiles, administrativas o disciplinarias llevados por organismos públicos. Estado `Determinada`; carácter `Condicional`. El texto no fija un plazo cuantificado para esta conducta.

## Anclajes y función

- [Art. 25, inc. 05, frag. 01](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-25/inciso-05-fragmento-01.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del régimen infraccional de esta Fuente; el campo vacío no significa ausencia de tipificación.
