---
identificador: "Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 1, frag. 2"
fuente: "Ley 21.719 modificatoria, vigencia diferida desde 01-12-2026 (PDF BCN, última modificación impresa Ley 21.806, 05-02-2026)"
localizacion_y_version: "Fuentes-primarias/Ley-21719-2024/Ley-21719_13-DIC-2024.pdf, pág. 34; Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 1, frag. 2; vigencia diferida desde 01-12-2026"
tipo_de_norma: "Constitutiva"
clasificacion_normativa_deontica: "No aplica — norma no regulativa"
control_ingreso: "Cotejo por extracción de columna normativa pdfplumber, pág. 34; coincidencia textual exacta del fragmento en bloque madre y localizador cotejado: conforme"
remisiones: "Ninguna remisión expresa en este fragmento"
---

# Art. primero, num. 14, art. 30 sexies reproducido de Ley 19.628, inc. 1, frag. 2

- **Contexto:** [unidad madre](inciso-01.md); [fragmento anterior](inciso-01-fragmento-01.md); [fragmento siguiente](inciso-01-fragmento-03.md).

## Texto literal (bloque espejo)

> La Corte Suprema conocerá del asunto en pleno especialmente convocado al efecto

## Análisis breve

Fija que la Corte Suprema conozca del asunto en un pleno convocado especialmente.

## Comprobación

El fragmento y su localizador se cotejaron con la página 34 del PDF primario. La concatenación literal de las hojas de la [unidad madre](inciso-01.md), separadas por un espacio, reconstruye byte a byte el bloque íntegro anterior. Se contrastaron las condiciones, excepciones y remisiones con el artículo completo. No queda duda textual en esta hoja.

## Tipo de norma

Constitutiva: «conocerá» configura la figura, el efecto o la atribución jurídica descrita. Fija que la Corte Suprema conozca del asunto en un pleno convocado especialmente.

## Clasificación deóntica

No aplica — norma no regulativa: este fragmento establece una figura, efecto o atribución jurídica.
