# Registro de retiros técnicos

- 01-10-2026 17:53:03 -03: la reserva `Ley-19628-consolidada-desde-2026-12-01/EX-106` fue retirada de `Exigencias/` por duplicar el deber ya registrado en `EX-005`. La captura original se conserva en esta carpeta con su nombre, sin reutilizar el número. El artículo 13, inciso 2, conserva su enlace de apoyo a `EX-005`. Esta corrección técnica no es visado jurídico.
- 01-10-2026 17:58:06 -03: capturas estables de EX-108, EX-110, EX-112 y EX-113 antes de añadir la delegación reglamentaria expresa del art. 26, inc. 1. Los archivos activos mantienen el mismo identificador y nombre; se releyeron tras la actualización.
- 01-10-2026 17:58:06 -03: captura estable de EX-127 antes de corregir destinatario del órgano público receptor a `Responsable de datos`; texto original preservado y ficha activa releída.
- 01-10-2026 18:04:26 -03: captura de EX-093 antes de corregir `caracter` a `Condicional`, valor admitido por el contrato; ficha activa releída.
- 01-10-2026 18:05:43 -03: capturas de resultados de arts. 34 ter y 34 quáter antes de corregir vínculos sancionadores: minimización EX-008, secreto EX-016–018, seguridad EX-012. Archivos activos releyeron sus filas.
- 01-10-2026 18:16:21 -03: reconstrucción textual del estado previo de EX-211 a partir de la sustitución literal usada al actualizarla tras leer art. 49. La reconstrucción se realizó después de la edición, no es una captura previa; se conserva separada de la ficha activa.
- 01-10-2026 18:20:47 -03: captura previa de EX-227 antes de añadir al campo de anclajes la delegación de art. 14 septies inc. 2 ya explicada en el cuerpo. Ficha activa releída.
