---
identificador: "Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 4"
fuente: "Ley 21.719 modificatoria, vigencia diferida desde 01-12-2026 (PDF BCN, última modificación impresa Ley 21.806, 05-02-2026)"
localizacion_y_version: "Fuentes-primarias/Ley-21719-2024/Ley-21719_13-DIC-2024.pdf, pág. 32; vigencia diferida desde 01-12-2026"
tipo_de_norma: "Constitutiva"
clasificacion_normativa_deontica: "No aplica — norma no regulativa"
control_ingreso: "PDF primario, columna normativa, pág. 32; literal y localizador cotejados: conforme"
remisiones: "Ninguna remisión expresa identificada en esta unidad"
---

# Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 4

- **Contexto:** [artículo del nivel inmediato](articulo.md); [instrucción modificatoria](../instruccion.md).

## Texto literal (bloque espejo)

> El Consejo Directivo de la Agencia designará a su presidente y vicepresidente, de entre sus miembros, de conformidad con lo establecido en los estatutos de la Agencia. Los cargos de presidente y vicepresidente durarán tres años o el tiempo que les reste como consejeros en cada caso.

## Análisis breve
El propio Consejo elige presidente y vicepresidente entre sus miembros conforme a sus estatutos. Ambos cargos duran tres años como máximo, o menos si antes termina la calidad de consejero.

## Comprobación
Se cotejó esta unidad contra el PDF primario en la(s) página(s) 32: palabras, puntuación, comillas y localizador coinciden tras normalizar sólo espacios y saltos de maquetación. Se comprobó su posición en la secuencia completa del artículo y su enlace de contexto. No queda duda de cotejo textual en esta unidad.

## Tipo de norma
Constitutiva: «designará a su presidente y vicepresidente» y «durarán tres años» estructuran la integración de cargos y sus períodos.

## Clasificación deóntica
No aplica: el tipo asignado es Constitutiva y este campo se reserva a normas regulativas.
