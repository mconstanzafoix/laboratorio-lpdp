---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-068"
enunciado: "Al dejar una persona la entidad, el responsable debe anonimizar o suprimir sus datos tratados bajo esa habilitación."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Anonimizar o suprimir los datos del integrante que deja de pertenecer a la entidad."
condicion_de_aplicacion: "Pérdida de calidad de integrante de persona jurídica que trató sus datos bajo art. 16 inc. 2 letra b."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16, inc. 2, lit. b, párr. 3, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16/inciso-02-letra-b-parrafo-03.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16, inc. 2, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16/inciso-02-letra-b.md, entidad habilitada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 34 ter, inc. 1, lit. h, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-h.md, tipificación sancionadora; Ley 19.628 consolidada desde 01-DIC-2026, Art. 35, inc. 1, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md, multa base del grado"
cita_textual_de_respaldo: "Art. 16, inc. 2, lit. b, párr. 3: «sus datos deberán ser anonimizados o suprimidos»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: "2 Grave"
---

## Fundamento textual e interpretación

El párrafo tercero impone una acción posterior cuando cesa la pertenencia del integrante. Anonimizar y suprimir son alternativas de cumplimiento de un mismo deber.

## Alcance de la regla

La condición es el término de pertenencia. No hay plazo cuantificado ni delegación. El carácter es `Condicional` por el supuesto expreso. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 16, inc. 2, lit. b, párr. 3](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16/inciso-02-letra-b-parrafo-03.md): principal: regla expresada.
- [Art. 16, inc. 2, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16/inciso-02-letra-b.md): entidad habilitada.

- [Art. 34 ter, inc. 1, lit. h](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-h.md): tipifica la conducta infractora de esta ficha.
- [Art. 35, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md): fija la multa base para el grado 2 Grave.

## Sanción

Conservar y tratar datos de quien dejó de ser asociado sin anonimizar ni suprimir incumple el requisito especial de la entidad sin fines de lucro respecto de datos de asociados. La calificación normativa es `2 Grave`. El art. 35 inc. 1 lit. b fija multa base de hasta 10.000 UTM. La reincidencia y, para grados grave o gravísima, el régimen de grandes empresas se sujetan a los supuestos expresos del art. 35 incs. 3–4; para órganos públicos rige el art. 44 inc. 3. No se determina infracción ni monto aplicado a un caso.
