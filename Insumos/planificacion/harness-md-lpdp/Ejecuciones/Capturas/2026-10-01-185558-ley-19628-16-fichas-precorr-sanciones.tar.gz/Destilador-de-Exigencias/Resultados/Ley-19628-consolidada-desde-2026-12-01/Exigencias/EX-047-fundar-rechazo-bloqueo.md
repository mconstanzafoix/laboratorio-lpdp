---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-047"
enunciado: "El responsable debe fundar la respuesta que rechaza una solicitud de bloqueo temporal."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Fundar la respuesta que rechaza el bloqueo temporal."
condicion_de_aplicacion: "Rechazo de solicitud fundada de bloqueo temporal."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 11, inc. 6, frag. 4, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-06-fragmento-04.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 34 ter, inc. 1, lit. f, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-f.md, tipificación sancionadora; Ley 19.628 consolidada desde 01-DIC-2026, Art. 35, inc. 1, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md, multa base del grado"
cita_textual_de_respaldo: "Art. 11, inc. 6, frag. 4: «En caso de rechazo el responsable deberá fundar su respuesta»"
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: "2 Grave"
---

## Fundamento textual e interpretación

El fragmento cuarto contiene dos conductas: fundamentar rechazo y comunicar electrónicamente la decisión a la Agencia. Esta ficha recoge la fundamentación de la respuesta al titular.

## Alcance de la regla

La obligación se activa si se rechaza el bloqueo. No se fija plazo distinto al de responder el requerimiento dentro de dos días hábiles, registrado en otra ficha. El carácter es `Condicional` por el supuesto expreso. Se registra `Determinada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 11, inc. 6, frag. 4](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-11/inciso-06-fragmento-04.md): principal: regla expresada.

- [Art. 34 ter, inc. 1, lit. f](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-f.md): tipifica la conducta infractora de esta ficha.
- [Art. 35, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md): fija la multa base para el grado 2 Grave.

## Sanción

Denegar sin causa justificada una solicitud fundada de bloqueo temporal coincide con el tipo específico de la letra f. La calificación normativa es `2 Grave`. El art. 35 inc. 1 lit. b fija multa base de hasta 10.000 UTM. La reincidencia y, para grados grave o gravísima, el régimen de grandes empresas se sujetan a los supuestos expresos del art. 35 incs. 3–4; para órganos públicos rige el art. 44 inc. 3. No se determina infracción ni monto aplicado a un caso.
