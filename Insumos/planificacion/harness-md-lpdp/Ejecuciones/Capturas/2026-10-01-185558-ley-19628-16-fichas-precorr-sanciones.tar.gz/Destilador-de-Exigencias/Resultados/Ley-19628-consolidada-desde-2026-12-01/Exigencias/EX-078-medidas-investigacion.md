---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-078"
enunciado: "El responsable debe adoptar medidas de calidad y seguridad para asegurar el uso exclusivo de datos en investigaciones de interés público."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Adoptar medidas de calidad y seguridad necesarias para uso exclusivo de datos en fines históricos, estadísticos, científicos o de investigación."
condicion_de_aplicacion: "Tratamiento de datos exclusivamente para esos fines de interés público."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quinquies, inc. 2, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quinquies/inciso-02-fragmento-01.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quinquies, inc. 1, frag. 1, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quinquies/inciso-01-fragmento-01.md, presunción de interés legítimo; Ley 19.628 consolidada desde 01-DIC-2026, Art. 16 quinquies, inc. 1, frag. 2, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quinquies/inciso-01-fragmento-02.md, fines de interés público; Ley 19.628 consolidada desde 01-DIC-2026, Art. 34 ter, inc. 1, lit. l, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-l.md, tipificación sancionadora; Ley 19.628 consolidada desde 01-DIC-2026, Art. 35, inc. 1, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md, multa base del grado"
cita_textual_de_respaldo: "Art. 16 quinquies, inc. 2, frag. 1: «deberán adoptar y acreditar que han cumplido con todas las medidas de calidad y seguridad necesarias»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: "2 Grave"
---

## Fundamento textual e interpretación

El primer fragmento exige medidas de calidad y seguridad para asegurar uso exclusivo en las finalidades indicadas. La acreditación de cumplimiento, en la misma frase, se registra separadamente por su objeto probatorio.

## Alcance de la regla

La necesidad y suficiencia de medidas dependen de datos y tratamiento, por lo que hay valoración. No se fija plazo ni delegación. El carácter es `Condicional` por el supuesto de finalidad. Se registra `Indeterminada` por el grado de precisión indicado.

## Anclajes y función

- [Art. 16 quinquies, inc. 2, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quinquies/inciso-02-fragmento-01.md): principal: regla expresada.
- [Art. 16 quinquies, inc. 1, frag. 1](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quinquies/inciso-01-fragmento-01.md): presunción de interés legítimo.
- [Art. 16 quinquies, inc. 1, frag. 2](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-16-quinquies/inciso-01-fragmento-02.md): fines de interés público.

- [Art. 34 ter, inc. 1, lit. l](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-l.md): tipifica la conducta infractora de esta ficha.
- [Art. 35, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md): fija la multa base para el grado 2 Grave.

## Sanción

Adoptar medidas de calidad y seguridad insuficientes o no idóneas para los fines históricos, estadísticos, científicos o de investigación de interés público es el supuesto específico de la letra l. La calificación normativa es `2 Grave`. El art. 35 inc. 1 lit. b fija multa base de hasta 10.000 UTM. La reincidencia y, para grados grave o gravísima, el régimen de grandes empresas se sujetan a los supuestos expresos del art. 35 incs. 3–4; para órganos públicos rige el art. 44 inc. 3. No se determina infracción ni monto aplicado a un caso.
