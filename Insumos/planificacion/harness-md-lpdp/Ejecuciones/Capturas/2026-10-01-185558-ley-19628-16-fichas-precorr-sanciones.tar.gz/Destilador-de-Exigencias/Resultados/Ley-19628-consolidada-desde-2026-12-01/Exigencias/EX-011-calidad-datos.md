---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-011"
enunciado: "El responsable debe mantener datos personales exactos, completos, actuales y pertinentes respecto de su proveniencia y fines."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Mantener los datos personales exactos, completos, actuales y pertinentes respecto de su proveniencia y fines."
condicion_de_aplicacion: "Tratamiento de datos personales."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. d, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-d.md, principal: regla expresada; Ley 19.628 consolidada desde 01-DIC-2026, Art. 34 ter, inc. 1, lit. d, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-d.md, tipificación sancionadora; Ley 19.628 consolidada desde 01-DIC-2026, Art. 35, inc. 1, lit. b, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md, multa base del grado"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. d: «Los datos personales deben ser exactos, completos, actuales y pertinentes»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: "2 Grave"
---

## Fundamento textual e interpretación

La letra d exige cuatro cualidades de los datos tratados que se evalúan en relación con su origen y fin. Son componentes acumulativos de una sola posición de calidad, no cuatro Exigencias independientes.

## Alcance de la regla

Exactitud, completitud, actualidad y pertinencia deben concurrir durante el tratamiento. La pertinencia y la actualidad requieren valoración contextual; no hay plazo cuantificado ni delegación. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-d.md): principal: regla expresada.

- [Art. 34 ter, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-d.md): tipifica la conducta infractora de esta ficha.
- [Art. 35, inc. 1, lit. b](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-35/inciso-01-letra-b.md): fija la multa base para el grado 2 Grave.

## Sanción

Tratar datos inexactos, incompletos o desactualizados en relación con los fines infringe la calidad exigida; el tipo exceptúa la actualización que corresponda al titular por ley o contrato. La calificación normativa es `2 Grave`. El art. 35 inc. 1 lit. b fija multa base de hasta 10.000 UTM. La reincidencia y, para grados grave o gravísima, el régimen de grandes empresas se sujetan a los supuestos expresos del art. 35 incs. 3–4; para órganos públicos rige el art. 44 inc. 3. No se determina infracción ni monto aplicado a un caso.
