---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-066"
enunciado: "El responsable debe configurar por defecto el tratamiento para incluir solo datos personales específicos y estrictamente necesarios."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Aplicar medidas técnicas y organizativas que limiten por defecto el tratamiento a datos específicos y estrictamente necesarios."
condicion_de_aplicacion: "Tratamiento de datos personales por el responsable; evaluación de cantidad de datos, extensión del tratamiento, conservación y accesibilidad."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quater reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quater/inciso-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quater reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quater/inciso-01.md, contexto de protección desde el diseño, con clasificación de ingreso en revisión"
cita_textual_de_respaldo: "Art. 14 quáter reproducido, inc. 2: «deberá aplicar medidas técnicas y organizativas para garantizar que, por defecto, sólo sean objeto de tratamiento los datos personales específicos y estrictamente necesarios»."
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: "número de datos recogidos; extensión del tratamiento; plazo de conservación; accesibilidad"
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

El inciso segundo atribuye al responsable un deber de configurar la protección por defecto. «Deberá aplicar» expresa obligación; la selección estricta de datos es el objeto propio de esta regla y se evalúa separadamente del deber de seguridad. El inciso primero del mismo artículo permanece con examen incompleto por la clasificación recibida y se menciona solo como contexto, sin usarlo para fundar esta ficha.

## Alcance de la regla

Se aplican medidas técnicas y organizativas al tratamiento del responsable, considerando cantidad de datos, extensión, conservación y accesibilidad. «Estrictamente necesarios» exige valoración para cada actividad; por ello la determinación es `Indeterminada`. No hay plazo expreso y la configuración por defecto es transversal.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quater reproducido de Ley 19.628, inc. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quater/inciso-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 8, art. 14 quater reproducido de Ley 19.628, inc. 1: [contexto de protección desde el diseño, con clasificación de ingreso en revisión](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-08/articulo-reproducido-14-quater/inciso-01.md).

## Límites del análisis

`sancion` queda vacío hasta cotejar el régimen sancionador de esta Fuente y las remisiones pertinentes; no implica ausencia de tipificación.
