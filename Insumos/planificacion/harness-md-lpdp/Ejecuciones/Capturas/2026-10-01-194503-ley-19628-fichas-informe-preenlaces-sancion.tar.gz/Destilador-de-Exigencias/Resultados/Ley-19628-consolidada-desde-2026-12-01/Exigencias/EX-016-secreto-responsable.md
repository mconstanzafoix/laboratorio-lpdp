---
identificador: "Ley-19628-consolidada-desde-2026-12-01/EX-016"
enunciado: "El responsable debe guardar secreto o confidencialidad sobre los datos personales a los que accede."
destinatario: "Responsable de datos"
modalidad: "Obligación"
conducta_exigida: "Guardar secreto o confidencialidad sobre los datos personales a los que accede."
condicion_de_aplicacion: "Acceso a datos personales en la relación con el titular, incluso después de concluida esta."
plazo: ""
disposicion_de_anclaje: "Ley 19.628 consolidada desde 01-DIC-2026, Art. 3, inc. 1, lit. h, ../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-h.md, principal: regla expresada"
cita_textual_de_respaldo: "Art. 3, inc. 1, lit. h: «El responsable de datos personales y quienes tengan acceso a ellos deberán guardar secreto o confidencialidad»"
estado_de_determinacion: "Indeterminada"
enumeracion_contenida: ""
caracter: "Transversal"
sancion: ""
---

## Fundamento textual e interpretación

La primera frase incluye expresamente al responsable y a otras personas con acceso. Esta ficha registra la posición del responsable; otra ficha registra el mismo deber para los otros sujetos porque el campo de destinatario admite un solo valor.

## Alcance de la regla

El deber subsiste tras la conclusión de la relación con el titular, según la última frase de la letra. El alcance concreto del secreto depende del acceso y del contexto; no hay plazo terminal ni delegación. El carácter es `Transversal` porque la regla atraviesa los tratamientos comprendidos. La determinación es `Indeterminada` por la valoración indicada.

## Anclajes y función

- [Art. 3, inc. 1, lit. h](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-h.md): principal: regla expresada.

## Límites del análisis

La calificación de `sancion` queda pendiente del examen de las infracciones de esta Fuente y sus remisiones pertinentes. El vacío no equivale a `0 No tipificada`.

**Conciliación sancionadora individual (01-10-2026):** En [Art. 3, inc. 1, lit. h](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-03/inciso-01-letra-h.md), la conducta exigida es «Guardar secreto o confidencialidad sobre los datos personales a los que accede». Se cotejó con [Art. 34 ter, inc. 1, lit. i](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-ter/inciso-01-letra-i.md). También se coteja [Art. 34 quáter, inc. 1, lit. d](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-19628-consolidada-desde-2026-12-01/articulo-34-quáter/inciso-01-letra-d.md) cuando el dato sea sensible o de menores. La letra i requiere vulneración efectiva del deber de secreto del art. 14 bis; las categorías sensibles o de infracciones pueden desplazarla al art. 34 quáter, letra d. El anclaje principal es el principio del art. 3, letra h; falta determinar su correspondencia con el deber específico del art. 14 bis y la categoría de datos efectivamente vulnerada. Por ello `sancion` permanece vacío; la eventual calificación puede variar según esos elementos.
