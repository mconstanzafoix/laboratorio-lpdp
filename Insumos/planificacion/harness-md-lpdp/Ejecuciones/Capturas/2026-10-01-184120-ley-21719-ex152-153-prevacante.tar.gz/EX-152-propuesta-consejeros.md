---
identificador: "Ley-21719-version-diferida-2026-12-01/EX-152"
enunciado: "El Presidente de la República debe proponer la nómina correspondiente para designar consejeros de la Agencia."
destinatario: "Tercero"
modalidad: "Obligación"
conducta_exigida: "Proponer al Senado la nómina de consejeros que corresponda."
condicion_de_aplicacion: "Proceso de designación de miembros del Consejo Directivo."
plazo: ""
disposicion_de_anclaje: "Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 2, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-02.md, principal; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 1, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-01.md, contexto o condición; Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 3, Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-03.md, contexto o condición"
cita_textual_de_respaldo: "Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 2: «Para efectos de su designación, el Presidente de la República hará la proposición de la nómina que corresponda y el Senado deberá pronunciarse respecto de la propuesta.»."
estado_de_determinacion: "Determinada"
enumeracion_contenida: ""
caracter: "Condicional"
sancion: ""
---

## Fundamento textual e interpretación

El texto principal expresa «Para efectos de su designación, el Presidente de la República hará la proposición de la nómina que corresponda y el Senado deberá pronunciarse respecto de la propuesta.». El sujeto específico es Presidente de la República; se codifica `Tercero` porque no es uno de los otros cinco destinatarios cerrados de este producto. Esta ficha aísla la conducta proponer al senado la nómina de consejeros que corresponda. de las restantes posiciones del artículo.

## Alcance de la regla

Proceso de designación de miembros del Consejo Directivo. El proponente y acto están fijados; la valoración de elegibilidad se apoya en inc. 3. El carácter es Condicional. No se expresa plazo cuantitativo para esta conducta.

## Anclajes y función

- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 2: [principal](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-02.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 1: [contexto o condición](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-01.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, art. 30 quater reproducido de Ley 19.628, inc. 3: [contexto o condición](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/articulo-reproducido-30-quater/inciso-03.md).
- Ley 21.719 modificatoria, versión diferida 01-12-2026, Art. primero, num. 14, instrucción modificatoria: [incorporación del Título VI](../../../../Fragmentador-de-Fuentes/Fuentes/Ley-21719-version-diferida-2026-12-01/articulo-primero/numeral-14/instruccion.md).

## Límites del análisis

`sancion` queda vacío hasta revisar el régimen sancionador aplicable de esta Fuente y sus remisiones; el vacío no equivale a no tipificada.
