# 02 — Gobernanza, fuentes únicas de verdad y context engineering

**Estado:** contenido previo visado por MCF; ajustes de gobierno solicitados el 01-10-2026 incorporados para revisión de su redacción, sin atribuirles un visado posterior. **Última revisión:** 01-10-2026. El historial anterior vive en `/Users/mcfoix/Desktop/Gestion del Caos/Minutas de decision/`. *(El 30-09-2026 este paquete se trasladó a `Laboratorio LPDP/Insumos/planificacion/documentos-canonicos/` — única ubicación vigente del canon.)*
**Propósito:** que este sistema pueda traspasarse a fuentes únicas de verdad y documentos canónicos sin pudrirse: contratos de traspaso efectivos, trazabilidad, divulgación progresiva, gates humanas, política de retención y defensas explícitas contra AI slop, artifact sprawl, filename versioning, documentation drift, context rot, prompt sprawl, provenance gap y deuda técnica generada por IA.

---

## 1. Mapa de fuentes únicas de verdad (SSOT)

Cada tipo de conocimiento tiene **una** fuente canónica y una sola. Todo lo demás es copia derivada, vista o caché — y se nombra como tal.

| Conocimiento | Fuente única de verdad | Derivados permitidos (no canónicos) |
|---|---|---|
| Reglas de gobierno del sistema | `planificacion/harness-md-lpdp/AGENTS.md` | referencias desde otros documentos |
| Contratos de agentes | `planificacion/harness-md-lpdp/<Nombre-del-Agente>/PROMPT.md` (uno por agente) + el `AGENTS.md` de la raíz del harness | otras carpetas de prompts son antecedentes o copias no despachables; no se sincronizan en dos direcciones |
| Arquitectura del sistema | `planificacion/documentos-canonicos/00-Sistema-LPDP.md`; esquema de propiedades en `01-Bases-de-Datos-y-Propiedades.md` | exportaciones fechadas de solo lectura; ninguno de estos archivos se sustituye por un nombre de arquitectura inexistente |
| Estado de implementación | las bases de Notion | informes y registros |
| Prompts vigentes para ejecución | `AGENTS.md` + el `PROMPT.md` del rol en `planificacion/harness-md-lpdp/` | `MEMORY.md` se carga solo si existe; perfiles de corrida solo cuando aplican |
| Qué ha pasado en el harness | `planificacion/harness-md-lpdp/Ejecuciones/*.md` y productos persistidos | resúmenes enlazados; la Bitácora conserva su función cuando se trabaje en el espacio de datos |
| Texto normativo primario | `planificacion/harness-md-lpdp/Fuentes-primarias/<cuerpo-y-versión>/*.pdf` (con SHA-256 en el `FUENTE.md` de la Fuente fragmentada) | mirrors oficiales documentados |
| Fragmentos y resultados de agentes | `planificacion/harness-md-lpdp/Fragmentador-de-Fuentes/Fuentes/<fuente-y-version>/…` y `planificacion/harness-md-lpdp/Destilador-de-Exigencias/Resultados/<fuente-y-version>/…` | fichas de datos derivadas cuando se implementen; Exigencias de Fuentes distintas no comparten carpeta |

**Regla de traspaso:** mover conocimiento de una fuente a otra exige un **contrato de traspaso**: qué campo/bit viaja, de qué fuente a cuál, quién escribe, quién comprueba, y qué queda deprecado. Un traspaso sin deprecación explícita crea dos verdades. La decisión del 01-10-2026 fija el harness como fuente vigente de prompts; `workspace-lpdp/` deja de ser fuente de despacho, sin borrar su historia.

## 2. Prohibiciones absolutas de higiene documental

1. **Prohibido versionar con sufijos** (`doc-v2-final-FINAL2.md`). Un archivo canónico tiene **un solo nombre estable**; la versión vive dentro (frontmatter) y la historia vive en el registro. Los respaldos antes de un cambio material viven en `registros/` con fecha, nunca junto al canónico con un nombre competidor.
2. **Prohibido duplicar contenido canónico del sistema.** Otro documento de arquitectura puede *referenciar* (`ver X, §N`), nunca copiar una regla de gobierno para crear dos fuentes de instrucción. Esta prohibición no elimina el texto literal presente en **dos cuerpos normativos primarios distintos**: la ley modificatoria puede reproducir lo que aparece en la consolidada, y cada transcripción conserva su propia identidad, versión y procedencia. Esa coincidencia se coteja; no se borra por parecer duplicada.
3. **Prohibido el consenso por silencio.** Un documento propuesto no se vuelve canónico por ausencia de objeción: requiere visado humano con nombre y fecha (misma regla que los estados jurídicos).
4. **Prohibido retrofechar** o «regularizar» registros. Fechas reales; si la hora original no se registró, se escribe literalmente eso.
5. **Prohibido declarar hecho lo propuesto.** «No presentes una propuesta como resultado ya ejecutado.»

## 3. Estructura del espacio de trabajo

El mapa vigente de los documentos canónicos y de la carpeta de agentes vive una sola vez: en el `README.md` de este nivel y en el `INDICE.md` de la carpeta de agentes. No se duplica aquí (prohibición 2 de §2): el árbol ASCII que esta sección contenía se retiró el 30-09-2026 por divergencia con el disco (minuta 12 en `/Users/mcfoix/Desktop/Gestion del Caos/Minutas de decision/Minutas-de-decision-2026-09-30.md`).

**Nota:** el espacio de trabajo de ejecución es
`planificacion/harness-md-lpdp/`, declarado en el `README.md` del paquete.
El Orquestador queda **separado** de AGENTS.md, en `Orquestador/PROMPT.md` — la
regla «un agente = una carpeta» no tiene excepciones.

Reglas del árbol:

- **Divulgación progresiva:** cada carpeta explica su contenido en su propio `INDICE.md`/README de ≤ 1 pantalla, con enlaces — nadie (humano ni IA) necesita cargar todo el sistema para trabajar en una carpeta. Un agente recibe en su encargo solo lo que su tarea requiere.
- **Un `INDICE.md` desactualizado es un defecto reportable**, no un adorno. Su árbol y verificación deben reflejar las carpetas y prompts realmente despachables.
- **Artifact sprawl:** todo archivo nuevo debe tener (a) un dueño-agente o humano, (b) un destino canónico en el árbol, (c) un motivo registrado en la ejecución que lo creó. Un archivo sin las tres cosas es un huérfano y se reporta.

### 3.1 Método del árbol anotado

Regla de context engineering adoptada como estándar canónico de documentación, aprobada por MCF el 25-09-2026:

1. **Todo índice o documento que organiza otros archivos lleva un árbol ASCII anotado**: el mapa completo antes del detalle, con una anotación corta por entrada (rol o función, no resumen). Un agente o persona que aterrice en la carpeta entiende el esqueleto sin abrir nada más. Es el mismo principio del `ARBOL.md` del Fragmentador aplicado a la propia documentación.
2. **Cada árbol declara el orden de lectura por rol**: quién carga qué y — igual de importante — qué **no** debe cargar. Esto opera la divulgación progresiva (§8) y es la defensa concreta contra el context rot.
3. **Artefacto visual de la regla «índice desactualizado = defecto reportable»**: el árbol cierra con una **línea de verificación** mecánica — `Verificación del índice: N entradas listadas — última comprobación DD-MM-AAAA contra disco`. La comprobación es contar entradas del árbol contra el disco (listar la carpeta y comparar); si difieren, el índice está roto y cualquiera (humano o agente) puede reportarlo sin juicio de valor. Quien agrega, renombra o elimina un archivo actualiza el árbol y la fecha en la misma operación.
4. **Dónde está implementado:** el `README.md` de los documentos canónicos (árbol del paquete + orden de lectura por rol) y el `INDICE.md` de la carpeta de agentes (árbol de prompts + regla de lectura acotada).
5. **Alcance canónico:** esta regla aplica a todo espacio de trabajo futuro del Laboratorio (el árbol de ejecución de §3 y cualquier carpeta nueva con más de 3 archivos).

## 4. AGENTS.md consolidado — reglas de gobierno

> El texto vigente vive en el `AGENTS.md` de la carpeta de agentes — un solo archivo de arranque, por decisión de MCF (25-09-2026), que fusiona las reglas de gobierno (Parte I) con el contrato común inyectable (Parte II). Ante cualquier diferencia, manda ese archivo. Su contenido no se duplica aquí (prohibición 2 de §2): la cita del texto fundacional que esta sección contenía se retiró el 30-09-2026 al diverger del vigente (minuta 12 en `/Users/mcfoix/Desktop/Gestion del Caos/Minutas de decision/Minutas-de-decision-2026-09-30.md`).

## 5. Cómo usar SKILL.md y MEMORY.md (y cómo no)

El sistema distingue tres tipos de instrucción persistente:

| Pieza | Qué contiene | Cuándo se carga | Quién la edita |
|---|---|---|---|
| **AGENTS.md** | Reglas de gobierno del sistema (lo de §4) | Siempre, al inicio de toda sesión en el espacio | Humano + Agente de Arquitectura, con visado |
| **PROMPT.md por agente** | Contrato específico del rol | Solo cuando ese agente es despachado | Agente de Arquitectura propone, humano visa, el archivo queda con fecha y motivo en su línea de Estado |
| **SKILL.md** (opcional) | Procedimientos reutilizables **transversales a roles** (p. ej. «cómo cotejar un literal contra un PDF con SHA-256», «cómo transcribir un fragmento a una ficha Notion») | Solo cuando la tarea activa el procedimiento | Agente de Arquitectura, con registro |
| **MEMORY.md** (opcional por agente) | Punteros operativos que cambian una decisión futura y no se recuperan fácilmente desde productos y `Ejecuciones/` | Solo si existe, después del PROMPT.md | El propio agente propone; Orquestador verifica que no duplique canon ni registro |

Reglas anti-rot para estas piezas:

- **SKILL.md no es un cajón de sastre**: si una regla aplica a un solo agente, va en su PROMPT.md; si aplica a todos, va en el contrato común. Un skill que duplica un contrato es prompt sprawl.
- **MEMORY.md tiene política de retención**: cada entrada lleva fecha; las entradas superadas se marcan `superada el DD-MM-AAAA por <qué>` (no se borran); entradas > 90 días sin uso se revisan o se archivan a `registros/`. La memoria nunca contradice al canon: si lo hace, el canon manda y la memoria se corrige.
- **Todo lo durable que un agente necesita saber debe vivir en archivos o en Notion, no en la conversación** (esa es la defensa central contra el context rot: el sistema se reconstruye desde sus artefactos).

### 5.1 Diseño de MEMORY.md

1. **No se crea por rutina.** Si una necesidad repetida justifica un `MEMORY.md`, vive junto al `PROMPT.md` de ese rol y solo ese rol la carga. El Orquestador recupera trabajos en curso desde `Ejecuciones/` y productos; su memoria tampoco es obligatoria.
2. **Orden de arranque de sesión** (fijado también en el contrato común): `AGENTS.md` → `PROMPT.md` del agente → `MEMORY.md`, si existe → perfil aplicable, si existe → encargo.
3. **Regla de escritura**: solo se anota lo que **cambia una decisión futura**; entrada = línea fechada + una frase + enlace al artefacto durable; lo que ya está en el canon o en una base se enlaza, no se copia; prohibido párrafos narrativos.
4. **Jerarquía**: canon > precedentes visados > memoria operativa. La memoria nunca es fuente de verdad: es un puntero fechado a las fuentes.
5. **Criterio de escala** (declarado para evitar sobre-ingeniería): no se usan embeddings, curación automática ni resúmenes de sesión — con decenas de entradas, un archivo legible con retención fechada da más trazabilidad que cualquier mecanismo. Si el volumen crece, el siguiente escalón son índices de memoria por tema, a decidir cuando duela.
6. En el harness vigente no se requiere ningún `MEMORY.md` para arrancar. Los archivos de memoria de otras carpetas conservan su carácter de antecedente, no de instrucción despachable.

### 5.2 Criterios de redacción de prompts

Reglas obligatorias al escribir o revisar el `PROMPT.md` de cualquier agente. Quien edita prompts (Agente de Arquitectura propone, humano visa) las aplica; se estrenaron en la revisión del Fragmentador de Fuentes del 25-09-2026.

1. **Fronteras negativas sin nombres de rol.** Un prompt delimita el alcance diciendo qué **no** es trabajo del agente («no extraes Exigencias», «la extracción pertenece a una etapa posterior»), **sin nombrar al agente que sí lo hace**. Nombrar roles de contenido acopla los prompts (si el otro cambia, este queda obsoleto sin aviso) e infla el contexto con información que no cambia la conducta.
2. **Excepción Orquestador.** Es el único rol nombrable, porque no es una etapa de contenido sino la **interfaz** de todo agente: de él recibe el encargo y a él le devuelve. Nombrarlo no acopla ni sesga.
3. **Sin conceptos de decisión ajenos que puedan sesgar el juicio.** Un agente productor no conoce objetos de decisión del sistema que no opera (p. ej. la Escalada no se menciona en prompts de producción: el agente registra hallazgos; qué se hace con ellos «no es su materia»).
4. **Propiedades ajenas: prohibido completarlas y deben quedar vacías.** No basta «no las escribas»: se declara explícitamente que quedan vacías, para que el completismo no las rellene.
5. **Autosuficiencia.** Todo término usado como instrucción se define en el propio prompt (bloque «Términos de este prompt» o glosa en línea en su primer uso). Las referencias cruzadas internas van **por nombre de campo, nunca por número**. Todo ejemplo lleva disclaimer («sólo muestra el formato: no atribuye…»).
6. **Sin vocabulario de etapas ajenas.** Si el agente no actúa sobre un concepto (p. ej. la Modalidad en fragmentación), no se menciona: nombrarlo es contexto muerto que confunde.

## 6. Cadena de custodia y proveniencia (anti provenance gap)

Todo dato del sistema puede responder «¿de dónde saliste?»:

1. **Exigencia → Disposición → Fuente/versión → documento primario (SHA-256).** La clave de Exigencia es `<fuente-y-version>/EX-NNN`; `EX-NNN` aislado es solo local. Cada ficha tiene al menos un anclaje principal de su Fuente. Sin esta cadena, la Exigencia no existe como dato válido.

   > **¿Qué es SHA-256, en palabras simples?** Es una **huella digital de un archivo**: una función matemática que convierte cualquier archivo en un código único de 64 caracteres (p. ej. `3e32f910…`). Si cambia aunque sea una coma del PDF, la huella cambia por completo. Sirve para dos cosas: (a) **demostrar que el texto con el que se trabajó es exactamente ese documento oficial y no otro parecido**, y (b) **detectar** si el archivo cambió después. La regla del sistema: cada PDF primario en `Fuentes-primarias/` tiene su huella registrada en su `FUENTE.md`, y cada cotejo de literales declara contra qué huella se hizo. Lo que la huella **no** hace: permitir reconstruir el archivo si se pierde — por eso la política de retención (§7) exige conservar copias, no solo huellas.
2. **Resultado de agente → prompt usado (ruta, fecha real y huella o versión comprobable en `Ejecuciones/`) → encargo → comprobación técnica del Orquestador → decisión humana, solo cuando corresponde.** La comprobación técnica no equivale a visado jurídico.
3. **Documento canónico → propuesta fechada → visado humano → registro del cambio.** Las correcciones se hacen por **fe de erratas trazable** (práctica heredada del análisis comparativo), nunca por reescritura silenciosa.
4. **Fragmento de archivo → `FUENTE.md` con hash → cotejo mecánico** (el harness ya demuestra el patrón: «147.567 caracteres normalizados, coincidencia exacta»).

**Comprobación de proveniencia al cerrar cada etapa:** Orquestador verifica que cada objeto nuevo tiene su cadena completa; un objeto con cadena rota queda `pendiente con responsable`, nunca se «completa» por decoro.

## 7. Política de retención

| Qué | Política |
|---|---|
| Registros históricos (Bitácora, Ejecuciones) | **No se borran ni se fusionan retrospectivamente.** |
| Versiones anteriores de un objeto corregido | Se conservan como **contenido estable** (captura/exportación fechada). Una huella detecta cambios pero no permite reconstruir: no basta. |
| Decisiones humanas | Permanentes, con fundamento, incluida la opción no elegida. |
| Fichas de decisiones negativas (`No sostenida`, `Descartado`) | Permanentes: «son la evidencia de que se consideró y se descartó». |
| ~~N.º de ingreso~~ | Eliminada del esquema el 25-09-2026 (decisión de MCF): la identidad inmutable la da el Identificador canónico, que **no se reasigna ni se reutiliza** — esa es la regla de retención que queda en su lugar. |
| Respaldos pre-cambio | En `registros/` con fecha, antes de cada reorganización. |
| Artefactos temporales de verificación (`tmp/`) | Conservables mientras la comprobación que sustentan siga citada; luego se archivan, no se borran en caliente. |

## 8. Divulgación progresiva y manejo de contexto (context engineering)

- **El encargo es la unidad de contexto**: el agente recibe contrato común + contrato específico + `MEMORY.md` si existe + perfil si aplica + encargo concreto, y nada más. «No entregues solo enlaces ni supongas que el ejecutor hereda tu contexto.»
- **Contextos separados donde el rol lo exige**: el Auditor preserva su mapa desde primario e identidades/literales antes de leer análisis y resultados de los productores; después examina esos razonamientos como objeto de auditoría. El Detector de concordancias preserva su pase ciego antes de ver el mapa interpretativo de Investigar, Agrupaciones e Ítems; el Relator conserva su contraste independiente antes de conocer el mapa del Detector.
- **Lectura escalonada**: índice primero (AGENTS.md → INDICE.md → ARBOL.md/COBERTURA.md), detalle después. Nadie lee 1.583 archivos para encargar una corrección de uno.
- **Checkpoints**: cada trabajo significativo deja un punto desde el cual reanudar consultando el estado persistido, «sin depender de recordar esta conversación».
- **Conciliación al reanudar**: Orquestador compara estado persistido vs. real antes de continuar (la concurrencia técnica real queda declarada como límite, no simulada).

## 9. Catálogo de anti-patrones y su defensa concreta en este sistema

| Anti-patrón | Defensa del sistema |
|---|---|
| **AI slop** (contenido plausible sin anclaje) | Regla dura de anclaje; cita textual obligatoria; «no inventes un campo para llenarlo»; auditoría con contexto separado |
| **Artifact sprawl** | Árbol canónico (§3); todo archivo con dueño, destino y motivo registrado; huérfanos reportables |
| **Filename versioning** | Prohibición absoluta (§2.1); los cambios quedan en la línea de Estado del archivo y en las minutas de decisión |
| **Documentation drift / doc rot** | SSOT por tipo de conocimiento (§1); referencias en vez de copias; INDICE desactualizado = defecto; Agente del Manual vigila el Manual, Agente de Arquitectura la coherencia estructural |
| **Context rot** | Todo lo durable vive en archivos/Notion; encargos autónomos; checkpoints; conciliación al reanudar |
| **Prompt sprawl** | Un PROMPT.md por agente, una versión vigente; el contrato común se mantiene una vez y se inyecta; skills solo transversales |
| **Provenance gap** | Cadena de custodia de §4 verificada al cerrar cada etapa; Bitácora con relación a versión de prompt |
| **Deuda técnica generada por IA** | Clasificación de cambios (presentación/visibilidad/funcional/incierta) con aceptación del Agente de Arquitectura; fe de erratas; registro de decisiones operativas con motivo en cada ejecución |

## 10. Proceso de promoción a canónico

1. Propuesta fechada (archivo nuevo o edición) →
2. Revisión humana →
3. Visado con nombre y fecha (go/no-go o con fundamento, según contenido) →
4. Agente de Arquitectura actualiza versiones (`p`/`i`/`v`, sin cruzar contadores), regenera exportaciones y manifiesto con huellas →
5. Agente del Manual actualiza el Manual →
6. Orquestador registra el cambio en Bitácora →
7. Lo superado se marca `superado el DD-MM-AAAA por <qué>`, nunca se borra en caliente.

## 11. Registro de riesgos operativos

Los riesgos identificados en la Propuesta-Spec v6, actualizados al estado del sistema consolidado. Cuando la mitigación ya existe en el diseño, se dice dónde vive; cuando sigue abierta, se dice qué falta.

| # | Riesgo | Prob. | Impacto | Mitigación y su estado |
|---|---|---|---|---|
| 1 | El sistema absorbe el tiempo de la implementación real | Alta | Crítico | Dos carriles: ningún entregable legal espera al sistema. **Sigue siendo disciplina de gestión, no del diseño.** |
| 2 | Un agente mal calibrado modifica en masa cientos de entradas | Media | Alto | Respaldo externo antes de cada corrida masiva; probar sobre vista filtrada de pocos registros antes de escalar. Regla vigente en testeo (`/Users/mcfoix/Desktop/Gestion del Caos/informes/05-Reglas-de-Testeo-y-Corridas.md`). |
| 3 | Falso negativo: una Exigencia relevante nunca se destila | Media | Crítico | **Mitigación de diseño:** `ARBOL.md` del Fragmentador se coteja con el texto primario; desde ese árbol el Destilador crea `RESULTADO.md` por artículo o, si la estructura real declarada en el árbol lo requiere, por subíndice de unidad, con una fila única por Disposición, y `COBERTURA.md` agrega el avance de la Fuente. Se distingue «no examinada» de «examinada sin Exigencias». El Auditor de anclaje revisa independientemente posibles omisiones; su funcionamiento sobre una destilación completa todavía no se ha comprobado. |
| 4 | Contaminación por derecho comparado | Media | Alto | **Mitigado:** regla dura de anclaje — una Exigencia nunca se funda en fuente extranjera; el comparado solo orienta. Es punto de checklist del Auditor. |
| 5 | Sesgo de automatización (aceptar lo que la IA propone sin revisar) | Alta con el tiempo | Alto | Procedencia del prompt, distinción entre comprobación técnica y decisión jurídica, y espacio humano vacío cuando corresponde. La calibración periódica con errores sembrados sigue **pendiente de implementar**. |
| 6 | Costo de créditos con agentes por lotes | Media | Medio | Medir consumo en calibración antes de escalar. Abierto. |
| 7 | El sistema audita texto, no práctica | Alta | Alto | El estándar de evidencia de ejecución (inspirado en el art. 14 quinquies: **existencia y funcionamiento**, no solo documento) se aplica a todo Subítem — ver el consolidado, sección de enrutamiento de validación. El Orquestador exige la forma de la evidencia; la declaración `Verificado` es humana. |
| 8 | La complejidad del sistema se vuelve barrera de uso | Alta | Alto | La capa de lectura (Qué es / Por qué importa / Qué implica hacerlo, en lenguaje llano para no técnicos) es la mitigación de diseño; los árboles ASCII anotados con orden de lectura por rol (§3.1 de este documento) la complementan. |
| 9 | Rotación del equipo antes de que llegue el DPO | Media | Alto | Escaladas con fundamento documentado (incluida la opción no elegida): el conocimiento de las decisiones no depende de personas. **Mitigado por diseño.** |
| 10 | Numeración o identidad de unidades incorrecta | Media | Alto | **Mitigación de diseño:** identidad = cuerpo + versión + identificador declarado + ruta comprobable en `ARBOL.md`; cotejo con texto primario y posterior auditoría de anclaje. Los esquemas numéricos simples no cubren intercalados, transitorios o instrucciones modificatorias; la comprobación completa sigue pendiente. |
| 11 | Una Exigencia `Delegada` se implementa como definitiva | Media | Medio | **Mitigado en el dato:** el campo Estado de determinación (Determinada / Delegada / Indeterminada, sin valor por defecto) hace visible la condición. La futura vigilancia dará prioridad a las Exigencias `Delegada` relacionadas con el pronunciamiento, sin excluir otras potencialmente afectadas; queda **diseñada pero no implementada** — ver el consolidado, sección de cambio normativo. |
| 12 | Fuente cargada y nunca destilada | Media | Alto | **Mitigación diseñada:** advertencias por condición en el home del Dominio y en la vista correspondiente (consolidado, ciclo de Fuente); todavía se debe comprobar que se generen y desaparezcan con el estado real. |
